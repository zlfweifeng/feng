const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();

// 中间件配置
app.use(cors());
app.use(express.json());

// 确保反馈文件夹存在
const feedbackDir = path.join(__dirname, 'feedback');
if (!fs.existsSync(feedbackDir)) {
    fs.mkdirSync(feedbackDir);
    console.log('Created feedback directory:', feedbackDir);
}

// 添加日志中间件
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// 处理反馈提交的路由
app.post('/api/feedback', (req, res) => {
    console.log('Received feedback:', req.body);
    
    try {
        const { title, content, contact, type } = req.body;
        
        // 验证输入
        if (!title || !content || !type) {
            return res.status(400).json({ 
                success: false, 
                message: '缺少必要的字段' 
            });
        }
        
        // 生成反馈内容
        const timestamp = new Date().toLocaleString();
        const feedbackContent = `
时间：${timestamp}
类型：${type === 'suggestion' ? '建议' : 'BUG反馈'}
标题：${title}
内容：${content}
联系方式：${contact || '未提供'}
------------------------
`;

        // 生成文件名
        const fileName = `feedback_${type}_${Date.now()}.txt`;
        const filePath = path.join(feedbackDir, fileName);

        // 写入文件
        fs.writeFileSync(filePath, feedbackContent, 'utf8');
        console.log('Feedback saved to:', filePath);

        res.json({ 
            success: true, 
            message: '反馈提交成功！',
            fileName: fileName
        });
    } catch (error) {
        console.error('Error saving feedback:', error);
        res.status(500).json({ 
            success: false, 
            message: '反馈提交失败，请稍后重试',
            error: error.message 
        });
    }
});

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({ 
        success: false, 
        message: '服务器错误',
        error: err.message 
    });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`
服务器启动成功！
运行在: http://localhost:${PORT}
反馈文件保存在: ${feedbackDir}
    `);
});

// 优雅关闭
process.on('SIGTERM', () => {
    console.log('收到 SIGTERM 信号，正在关闭服务器...');
    server.close(() => {
        console.log('服务器已关闭');
        process.exit(0);
    });
}); 