#!/bin/bash
echo "正在启动反馈服务器..."
npm install
npm start 