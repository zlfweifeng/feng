class EquipmentSystem {
    constructor() {
        // 装备槽位配置
        this.EQUIPMENT_SLOTS = {
            WEAPON: { name: '武器', icon: '⚔️' },
            HEAD: { name: '头部', icon: '👒' },
            BODY: { name: '衣服', icon: '👕' },
            HANDS: { name: '手部', icon: '🧤' },
            LEGS: { name: '裤子', icon: '👖' },
            FEET: { name: '鞋子', icon: '👞' }
        };
    }

    // 装备物品
    equipItem(player, item, slotType) {
        if (!player.inventory) return false;
        
        try {
            // 先移除所有提示框
            this.removeAllTooltips();

            // 检查物品是否适合该槽位
            if (item.type !== slotType) {
                gameManager.showFloatingTip('该物品不能装备在此位置！', 'error');
                return false;
            }

            // 检查等级需求
            if (item.levelReq && player.level < item.levelReq) {
                gameManager.showFloatingTip(`需要等级 ${item.levelReq}！`, 'error');
                return false;
            }

            // 获取当前装备的物品
            const currentEquipped = player.inventory.equipped[slotType];

            // 如果槽位已有装备，先卸下
            if (currentEquipped) {
                this.unequipItem(player, slotType);
            }

            // 从背包移除物品
            const itemIndex = player.inventory.items.findIndex(i => i.id === item.id);
            if (itemIndex === -1) return false;
            player.inventory.items.splice(itemIndex, 1);

            // 装备物品
            player.inventory.equipped[slotType] = item;

            // 应用装备属性加成
            this.applyEquipmentStats(player, item, true);

            // 更新显示
            this.updateEquipmentDisplay(player);
            inventorySystem.updateInventoryDisplay(player);
            this.updatePlayerStats(player);

            // 显示成功提示
            gameManager.showFloatingTip(`成功装备 ${item.name}！`, 'success');

            // 保存角色数据
            saveCharacter(player);

            return true;
        } catch (error) {
            console.error('装备物品时出错:', error);
            gameManager.showFloatingTip('装备失败！', 'error');
            return false;
        }
    }

    // 卸下装备
    unequipItem(player, slotType) {
        if (!player.inventory || !player.inventory.equipped[slotType]) return false;

        try {
            const item = player.inventory.equipped[slotType];

            // 检查背包是否已满
            if (player.inventory.items.length >= player.inventory.maxSlots) {
                gameManager.showFloatingTip('背包已满，无法卸下装备！', 'error');
                return false;
            }

            // 移除装备属性加成
            this.applyEquipmentStats(player, item, false);

            // 将物品移回背包
            player.inventory.items.push(item);
            delete player.inventory.equipped[slotType];

            // 移除所有提示框
            this.removeAllTooltips();

            // 更新显示
            this.updateEquipmentDisplay(player);
            inventorySystem.updateInventoryDisplay(player);
            this.updatePlayerStats(player);

            // 显示成功提示
            gameManager.showFloatingTip(`已卸下 ${item.name}`, 'success');

            // 保存角色数据
            saveCharacter(player);

            return true;
        } catch (error) {
            console.error('卸下装备时出错:', error);
            gameManager.showFloatingTip('卸下装备失败！', 'error');
            return false;
        }
    }

    // 使用道具
    useItem(player, item) {
        if (!item.effect) return false;

        try {
            switch (item.effect.type) {
                case 'heal':
                    // 恢复生命值
                    const maxHealAmount = player.stats.maxHp - player.stats.hp;
                    const healAmount = Math.min(item.effect.value, maxHealAmount);
                    player.stats.hp += healAmount;
                    gameManager.showFloatingTip(`恢复 ${healAmount} 点生命值！`, 'success');
                    break;

                case 'restore_mp':
                    // 恢复法力值
                    const maxMpAmount = player.stats.maxMp - player.stats.mp;
                    const mpAmount = Math.min(item.effect.value, maxMpAmount);
                    player.stats.mp += mpAmount;
                    gameManager.showFloatingTip(`恢复 ${mpAmount} 点法力值！`, 'success');
                    break;

                case 'buff_attack':
                case 'buff_defense':
                case 'buff_speed':
                    // 添加buff效果
                    this.applyBuff(player, item.effect);
                    break;

                default:
                    console.warn('未知的道具效果类型:', item.effect.type);
                    return false;
            }

            // 移除已使用的道具
            const itemIndex = player.inventory.items.findIndex(i => i.id === item.id);
            if (itemIndex !== -1) {
                if (item.count && item.count > 1) {
                    item.count--;
                } else {
                    player.inventory.items.splice(itemIndex, 1);
                }
            }

            // 更新显示
            inventorySystem.updateInventoryDisplay(player);
            gameManager.updatePlayerInfo();

            // 保存角色数据
            saveCharacter(player);

            return true;
        } catch (error) {
            console.error('使用道具时出错:', error);
            gameManager.showFloatingTip('使用道具失败！', 'error');
            return false;
        }
    }

    // 应用装备属性加成
    applyEquipmentStats(player, item, isEquipping) {
        if (!item.stats) return;

        const multiplier = isEquipping ? 1 : -1;
        
        // 遍历装备属性
        Object.entries(item.stats).forEach(([stat, value]) => {
            switch (stat) {
                case 'attack':
                    player.stats.attack += value * multiplier;
                    break;
                case 'defense':
                    player.stats.defense += value * multiplier;
                    break;
                case 'hp':
                case 'maxHp':
                    const hpValue = Number(value.toFixed(1));
                    player.stats.maxHp += hpValue * multiplier;
                    if (isEquipping) {
                        player.stats.hp += hpValue;
                    }
                    player.stats.hp = Math.min(player.stats.hp, player.stats.maxHp);
                    break;
                case 'mp':
                case 'maxMp':
                    const mpValue = Number(value.toFixed(1));
                    player.stats.maxMp += mpValue * multiplier;
                    if (isEquipping) {
                        player.stats.mp += mpValue;
                    }
                    player.stats.mp = Math.min(player.stats.mp, player.stats.maxMp);
                    break;
                case 'speed':
                    player.stats.speed += value * multiplier;
                    break;
                case 'critRate':
                    player.stats.crit += value * multiplier;
                    break;
                case 'critDamage':
                    player.stats.critDmg += value * multiplier;
                    break;
                case 'dodge':
                    player.stats.dodge += value * multiplier;
                    break;
                case 'lifeSteal':
                    player.stats.drain += value * multiplier;
                    break;
                case 'mpRegen':
                    player.stats.mpRegen += value * multiplier;
                    break;
                case 'skillDamage':
                    player.stats.skillDamage += value * multiplier;
                    break;
                case 'cooldownReduction':
                    player.stats.cooldownReduction += value * multiplier;
                    break;
            }
        });

        // 重新计算玩家属性
        player.stats = player.calculateStats();
        
        // 更新玩家属性显示
        this.updatePlayerStats(player);
    }

    // 应用buff效果
    applyBuff(player, effect) {
        const buffId = `${effect.type}_${Date.now()}`;
        
        // 创建buff对象
        const buff = {
            id: buffId,
            type: effect.type,
            value: effect.value,
            duration: effect.duration,
            startTime: Date.now()
        };

        // 添加到玩家的buff列表
        if (!player.status) player.status = { buffs: [] };
        player.status.buffs.push(buff);

        // 应用buff效果
        switch (effect.type) {
            case 'buff_attack':
                player.stats.attack += effect.value;
                break;
            case 'buff_defense':
                player.stats.defense += effect.value;
                break;
            case 'buff_speed':
                player.stats.speed += effect.value;
                break;
        }

        // 设置buff结束时的定时器
        setTimeout(() => {
            this.removeBuff(player, buffId);
        }, effect.duration * 1000);

        gameManager.showFloatingTip(`获得${this.getBuffName(effect.type)}效果！`, 'success');
    }

    // 移除buff效果
    removeBuff(player, buffId) {
        const buffIndex = player.status.buffs.findIndex(b => b.id === buffId);
        if (buffIndex === -1) return;

        const buff = player.status.buffs[buffIndex];
        
        // 移除buff效果
        switch (buff.type) {
            case 'buff_attack':
                player.stats.attack -= buff.value;
                break;
            case 'buff_defense':
                player.stats.defense -= buff.value;
                break;
            case 'buff_speed':
                player.stats.speed -= buff.value;
                break;
        }

        // 从buff列表中移除
        player.status.buffs.splice(buffIndex, 1);
        
        gameManager.showFloatingTip(`${this.getBuffName(buff.type)}效果已结束`, 'info');
        
        // 更新显示
        gameManager.updatePlayerInfo();
        saveCharacter(player);
    }

    // 获取buff名称
    getBuffName(buffType) {
        const buffNames = {
            buff_attack: '攻击提升',
            buff_defense: '防御提升',
            buff_speed: '速度提升'
        };
        return buffNames[buffType] || buffType;
    }

    // 更新装备显示
    updateEquipmentDisplay(player) {
        const equipmentSection = document.querySelector('.equipment-section');
        if (!equipmentSection) return;

        // 先移除所有提示框
        this.removeAllTooltips();

        // 更新装备槽位显示
        Object.entries(this.EQUIPMENT_SLOTS).forEach(([slotType, config]) => {
            const slot = equipmentSection.querySelector(`[data-slot="${slotType}"]`);
            if (!slot) return;

            const equippedItem = player.inventory?.equipped?.[slotType];
            
            if (equippedItem) {
                // 显示已装备的物品
                const qualityConfig = itemGenerator.QUALITY_CONFIG[equippedItem.quality];
                slot.innerHTML = `
                    <div class="equipped-item" style="border-color: ${qualityConfig.color}">
                        <div class="item-icon" style="color: ${qualityConfig.color}">${equippedItem.icon}</div>
                        <div class="item-name" style="color: ${qualityConfig.color}">${equippedItem.name}</div>
                        <div class="quality-badge" style="background: ${qualityConfig.color}">${qualityConfig.name}</div>
                    </div>
                `;
                
                // 添加点击卸下装备的事件
                slot.onclick = () => this.unequipItem(player, slotType);

                // 添加鼠标悬停事件
                slot.onmouseenter = () => {
                    this.addEquipmentTooltip(slot, equippedItem);
                };

                slot.onmouseleave = () => {
                    this.removeAllTooltips();
                };
            } else {
                // 显示空槽位
                slot.innerHTML = `
                    <div class="empty-slot">
                        <div class="slot-icon">${config.icon}</div>
                        <div class="slot-name">${config.name}</div>
                    </div>
                `;
                // 清除所有事件监听
                slot.onclick = null;
                slot.onmouseenter = null;
                slot.onmouseleave = null;
            }
        });

        // 更新玩家属性显示
        gameManager.updatePlayerInfo();
    }

    // 添加装备提示框
    addEquipmentTooltip(element, item) {
        // 确保元素存在
        if (!element || !item) return;

        // 先移除所有提示框
        this.removeAllTooltips();
        
        const tooltip = document.createElement('div');
        tooltip.className = 'equipment-tooltip';
        tooltip.id = 'current-equipment-tooltip';
        
        const qualityConfig = itemGenerator.QUALITY_CONFIG[item.quality];
        
        tooltip.innerHTML = `
            <div class="tooltip-header">
                <span class="tooltip-name" style="color: ${qualityConfig.color}">${item.name}</span>
                <span class="tooltip-quality" style="color: ${qualityConfig.color}">${item.icon}</span>
            </div>
            <div class="tooltip-quality-badge" style="background: ${qualityConfig.color}">${qualityConfig.name}</div>
            <div class="tooltip-type">${this.EQUIPMENT_SLOTS[item.type].name}</div>
            ${item.levelReq ? `<div class="level-req">需要等级: ${item.levelReq}</div>` : ''}
            <div class="tooltip-stats">
                ${Object.entries(item.stats).map(([stat, value]) => `
                    <div class="stat-line">
                        <span class="stat-name">${itemGenerator.STAT_POOL[stat].name}</span>
                        <span class="stat-value">+${value}${itemGenerator.STAT_POOL[stat].format === 'percentage' ? '%' : ''}</span>
                    </div>
                `).join('')}
            </div>
            <div class="tooltip-action">
                <span class="action-icon">🔄</span>
                点击卸下装备
            </div>
        `;

        // 添加提示框到 DOM
        document.body.appendChild(tooltip);

        // 更新位置处理函数
        const updatePosition = (e) => {
            const x = e.clientX;
            const y = e.clientY;
            
            // 获取提示框尺寸
            const tooltipRect = tooltip.getBoundingClientRect();
            
            // 计算位置，避免超出视窗
            let left = x + 15;
            let top = y;
            
            if (left + tooltipRect.width > window.innerWidth) {
                left = x - tooltipRect.width - 15;
            }
            
            if (top + tooltipRect.height > window.innerHeight) {
                top = window.innerHeight - tooltipRect.height;
            }
            
            tooltip.style.left = `${left}px`;
            tooltip.style.top = `${top}px`;
        };

        // 清理旧的事件监听器
        if (element.updatePositionHandler) {
            element.removeEventListener('mousemove', element.updatePositionHandler);
        }

        // 存储新的事件监听器引用
        element.updatePositionHandler = updatePosition;
        element.addEventListener('mousemove', updatePosition);

        // 初始化提示框位置
        const rect = element.getBoundingClientRect();
        updatePosition({ 
            clientX: rect.right, 
            clientY: rect.top 
        });

        // 显示提示框
        requestAnimationFrame(() => {
            tooltip.style.opacity = '1';
            tooltip.style.visibility = 'visible';
        });

        // 鼠标离开时移除提示框
        const handleMouseLeave = () => {
            this.removeAllTooltips();
            element.removeEventListener('mousemove', element.updatePositionHandler);
            element.removeEventListener('mouseleave', handleMouseLeave);
        };

        element.addEventListener('mouseleave', handleMouseLeave);
    }

    // 添加新方法：移除所有提示框
    removeAllTooltips() {
        const tooltips = document.querySelectorAll('.equipment-tooltip');
        tooltips.forEach(tooltip => {
            tooltip.style.opacity = '0';
            tooltip.style.visibility = 'hidden';
            
            // 使用 setTimeout 确保动画完成后再移除元素
            setTimeout(() => {
                if (tooltip.parentNode) {
                    tooltip.parentNode.removeChild(tooltip);
                }
            }, 200);
        });
    }

    // 更新玩家属性显示
    updatePlayerStats(player) {
        // 更新背包界面的属性显示
        const statsContainer = document.querySelector('.player-stats');
        if (statsContainer) {
            statsContainer.innerHTML = this.generatePlayerStatsHTML(player);
            
            // 添加属性变化动画
            const statValues = statsContainer.querySelectorAll('.stat-value');
            statValues.forEach(value => {
                value.classList.add('changing');
                setTimeout(() => value.classList.remove('changing'), 300);
            });
        }

        // 更新游戏主界面的状态条
        gameManager.updateStatBars();
    }

    // 生成玩家属性HTML
    generatePlayerStatsHTML(player) {
        const stats = player.stats;
        const attrs = player.attributes;
        
        // 确保与角色信息界面的属性顺序和显示一致
        const statsConfig = [
            { 
                name: '攻击力', 
                value: stats.attack || 0,
                type: 'attack'
            },
            { 
                name: '命中', 
                value: stats.hit || 0,
                type: 'hit'
            },
            { 
                name: '防御力', 
                value: stats.defense || 0,
                type: 'defense'
            },
            { 
                name: '闪避', 
                value: `${stats.dodge || 0}%`,
                type: 'dodge'
            },
            { 
                name: '暴击', 
                value: `${stats.crit || 0}%`,
                type: 'crit'
            },
            { 
                name: '爆伤', 
                value: `${stats.critDmg || 150}%`,
                type: 'crit-dmg'
            },
            { 
                name: '吸取', 
                value: `${stats.drain || 0}%`,
                type: 'drain'
            },
            { 
                name: '力道', 
                value: attrs.strength.base,
                type: 'strength'
            },
            { 
                name: '身法', 
                value: attrs.agility.base,
                type: 'agility'
            },
            { 
                name: '根骨', 
                value: attrs.constitution.base,
                type: 'constitution'
            },
            { 
                name: '悟性', 
                value: attrs.wisdom.base,
                type: 'wisdom'
            },
            { 
                name: '速度', 
                value: stats.speed || 0,
                type: 'speed'
            }
        ];

        return statsConfig.map(stat => `
            <div class="stat-item" data-type="${stat.type}">
                <span class="stat-name">${stat.name}</span>
                <span class="stat-value">${stat.value}</span>
            </div>
        `).join('');
    }
}

// 创建全局装备系统实例
const equipmentSystem = new EquipmentSystem(); 