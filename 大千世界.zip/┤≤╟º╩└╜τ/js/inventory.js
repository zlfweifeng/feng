class InventorySystem {
    constructor() {
        this.SLOT_TYPES = {
            WEAPON: 'weapon',
            HEAD: 'head',
            BODY: 'body',
            HANDS: 'hands',
            LEGS: 'legs',
            FEET: 'feet'
        };
        this.bulkSellMode = false;
        this.selectedItems = new Set();
    }

    // 初始化背包系统
    initializeInventory(player) {
        if (!player.inventory) {
            player.inventory = {
                items: [],
                equipped: {},
                maxSlots: this.calculateMaxSlots(player)
            };
        } else {
            // 更新最大格子数
            player.inventory.maxSlots = this.calculateMaxSlots(player);
        }
        return player.inventory;
    }

    // 计算最大背包格子数（基于负重能力）
    calculateMaxSlots(player) {
        // 基础格子数
        const baseSlots = 50;
        
        // 等级加成: 每1级增加2个格子
        const levelBonus = player.level * 2;
        
        // 力道加成: 每10点力道增加1个格子
        const strengthBonus = Math.floor(player.attributes.strength.base / 10);
        
        // 计算总格子数
        const totalSlots = baseSlots + levelBonus + strengthBonus;
        
        // 限制最大格子数为200
        return Math.min(300, totalSlots);
    }

    // 更新背包显示
    updateInventoryDisplay(player) {
        const panel = document.getElementById('inventory-panel');
        if (!panel) return;

        // 强制重新计算玩家属性
        player.stats = player.calculateStats();

        // 更新金币显示
        const goldAmount = panel.querySelector('.gold-amount');
        if (goldAmount) {
            goldAmount.textContent = player.gold || 0;
        }

        // 更新背包格子信息
        const weightValue = panel.querySelector('.weight-value');
        const maxWeightValue = panel.querySelector('.max-weight-value');
        if (weightValue && maxWeightValue) {
            // 重新计算最大格子数
            const maxSlots = this.calculateMaxSlots(player);
            player.inventory.maxSlots = maxSlots;
            
            // 计算当前已使用的格子数
            const usedSlots = player.inventory.items.length;
            
            // 更新显示
            weightValue.textContent = usedSlots;
            maxWeightValue.textContent = maxSlots;

            // 添加视觉反馈
            const weightInfo = panel.querySelector('.weight-info');
            if (weightInfo) {
                weightInfo.className = 'weight-info';
                if (usedSlots >= maxSlots) {
                    weightInfo.classList.add('full');
                } else if (usedSlots >= maxSlots * 0.8) {
                    weightInfo.classList.add('nearly-full');
                }
                
                // 添加提示信息
                weightInfo.title = `基础格子: 20
等级加成: +${player.level * 2} (每级+2)
力道加成: +${Math.floor(player.attributes.strength.base / 10)} (每10点力道+1)
总格子数: ${maxSlots}`;
            }
        }

        // 更新装备栏显示
        this.updateEquipmentDisplay(player);

        // 更新玩家属性显示
        equipmentSystem.updatePlayerStats(player);

        // 更新背包格子
        this.updateInventoryGrid(player);

        // 强制更新DOM
        requestAnimationFrame(() => {
            panel.offsetHeight;
        });

        // 更新背包栏标题和按钮
        const inventorySection = document.querySelector('.inventory-section');
        if (inventorySection) {
            // 检查是否已经存在 inventory-header
            let headerContainer = inventorySection.querySelector('.inventory-header');
            
            // 如果不存在，才创建新的 header container
            if (!headerContainer) {
                const header = inventorySection.querySelector('h4');
                if (header) {
                    headerContainer = document.createElement('div');
                    headerContainer.className = 'inventory-header';
                    header.parentNode.insertBefore(headerContainer, header);
                    headerContainer.appendChild(header);

                    const controls = document.createElement('div');
                    controls.className = 'bulk-sell-controls';
                    controls.innerHTML = `
                        <button class="bulk-sell-btn">
                            <span class="btn-icon">📦</span>
                            批量出售
                        </button>
                        <button class="confirm-sell-btn">
                            <span class="btn-icon">💰</span>
                            出售选中
                        </button>
                    `;
                    headerContainer.appendChild(controls);

                    // 添加批量出售按钮事件
                    const bulkSellBtn = controls.querySelector('.bulk-sell-btn');
                    const confirmSellBtn = controls.querySelector('.confirm-sell-btn');

                    bulkSellBtn.onclick = () => this.toggleBulkSellMode(player);
                    confirmSellBtn.onclick = () => this.confirmBulkSell(player);
                }
            }
        }
    }

    // 更新装备栏显示
    updateEquipmentDisplay(player) {
        const equipmentSection = document.querySelector('.equipment-section');
        if (!equipmentSection) return;

        equipmentSection.innerHTML = `
            <div class="equipment-container">
                <div class="equipment-left">
                    <h4>装备栏</h4>
                    <div class="equipment-slots">
                        ${this.generateEquipmentSlotsHTML(player)}
                    </div>
                </div>
                <div class="equipment-right">
                    <h4>角色属性</h4>
                    <div class="player-stats">
                        ${equipmentSystem.generatePlayerStatsHTML(player)}
                    </div>
                </div>
            </div>
        `;

        // 为装备槽添加事件监听
        this.setupEquipmentSlotEvents(player);
    }

    // 生成装备槽HTML
    generateEquipmentSlotsHTML(player) {
        const slots = [
            { type: 'WEAPON', name: '武器', icon: '⚔️' },
            { type: 'HEAD', name: '头部', icon: '👒' },
            { type: 'BODY', name: '衣服', icon: '👕' },
            { type: 'HANDS', name: '手部', icon: '🧤' },
            { type: 'LEGS', name: '裤子', icon: '👖' },
            { type: 'FEET', name: '鞋子', icon: '👞' }
        ];

        return slots.map(slot => {
            const equipped = player.inventory?.equipped?.[slot.type];
            return `
                <div class="equip-slot ${equipped ? 'equipped' : ''}" data-slot="${slot.type}">
                    ${equipped ? `
                        <div class="item">
                            <div class="item-icon">${equipped.icon}</div>
                            <div class="item-name">${equipped.name}</div>
                        </div>
                    ` : `
                        <div class="slot-icon">${slot.icon}</div>
                        <div class="slot-name">${slot.name}</div>
                    `}
                </div>
            `;
        }).join('');
    }

    // 更新背包格子显示
    updateInventoryGrid(player) {
        const grid = document.getElementById('inventory-grid');
        if (!grid) return;

        // 添加或移除批量出售模式的类名
        grid.className = `inventory-grid${this.bulkSellMode ? ' bulk-sell-mode' : ''}`;

        grid.innerHTML = '';
        const maxSlots = player.inventory.maxSlots;

        for (let i = 0; i < maxSlots; i++) {
            const slot = document.createElement('div');
            slot.className = 'inventory-slot empty';
            slot.dataset.index = i;

            const item = player.inventory.items[i];
            if (item) {
                slot.classList.remove('empty');
                
                // 添加品质类名
                if (item.quality) {
                    slot.classList.add(`quality-${item.quality.toLowerCase()}`);
                }

                // 更新物品显示,包含堆叠数量
                slot.innerHTML = `
                    <div class="item">
                        <div class="item-icon">${item.icon}</div>
                        <div class="item-name">
                            ${item.name}${item.count > 1 ? ` (${item.count})` : ''}
                        </div>
                        ${item.count > 1 ? `
                            <div class="item-count">${item.count}</div>
                        ` : ''}
                    </div>
                `;
                
                this.addItemTooltip(slot, item);
            }

            grid.appendChild(slot);
        }

        // 修改格子点击事件
        const slots = document.querySelectorAll('.inventory-slot');
        slots.forEach(slot => {
            slot.onclick = (e) => {
                const index = slot.dataset.index;
                const item = player.inventory.items[index];
                if (item) {
                    if (this.bulkSellMode) {
                        this.toggleItemSelection(slot, index);
                    } else {
                        this.showItemDetailDialog(item, index, player);
                    }
                }
            };
        });
    }

    // 添加物品提示框
    addItemTooltip(element, item) {
        const tooltip = document.createElement('div');
        tooltip.className = 'item-tooltip';
        
        // 获取品质配置
        const qualityConfig = itemGenerator.QUALITY_CONFIG[item.quality] || {
            name: '',
            color: '#666'
        };

        // 检查是否是装备类型物品
        const isEquipment = ['WEAPON', 'HEAD', 'BODY', 'HANDS', 'LEGS', 'FEET'].includes(item.type);
        
        // 如果是装备,获取当前装备槽的装备
        let equippedItem = null;
        if (isEquipment && gameManager.currentPlayer?.inventory?.equipped) {
            equippedItem = gameManager.currentPlayer.inventory.equipped[item.type];
        }

        tooltip.innerHTML = `
            <div class="tooltip-header">
                <span class="tooltip-name" style="color: ${qualityConfig.color}">${item.name}</span>
                <span class="tooltip-quality" style="color: ${qualityConfig.color}">${item.icon}</span>
            </div>
            <div class="tooltip-quality-badge" style="background: ${qualityConfig.color}">${qualityConfig.name}</div>
            ${isEquipment ? `
                <div class="tooltip-type">${equipmentSystem.EQUIPMENT_SLOTS[item.type].name}</div>
                ${item.levelReq ? `<div class="level-req">需要等级: ${item.levelReq}</div>` : ''}
                <div class="tooltip-stats">
                    ${this.generateComparisonStats(item, equippedItem)}
                </div>
            ` : `
                <div class="tooltip-description">${item.description || ''}</div>
                ${item.effect ? `
                    <div class="tooltip-effect">
                        ${this.formatEffectDescription(item.effect)}
                    </div>
                ` : ''}
            `}
        `;

        element.onmousemove = (e) => {
            const x = e.clientX;
            const y = e.clientY;
            
            tooltip.style.left = `${x + 15}px`;
            tooltip.style.top = `${y - tooltip.offsetHeight/2}px`;
        };

        element.onmouseenter = () => {
            document.body.appendChild(tooltip);
            tooltip.style.opacity = '1';
            tooltip.style.visibility = 'visible';
        };

        element.onmouseleave = () => {
            tooltip.style.opacity = '0';
            tooltip.style.visibility = 'hidden';
            if (tooltip.parentNode) {
                document.body.removeChild(tooltip);
            }
        };
    }

    // 添加效果描述格式化方法
    formatEffectDescription(effect) {
        switch(effect.type) {
            case 'heal':
                return `恢复 ${effect.value} 点生命值`;
            case 'restore_mp':
                return `恢复 ${effect.value} 点法力值`;
            case 'buff_attack':
                return `增加 ${effect.value}% 攻击力，持续 ${effect.duration} 秒`;
            case 'buff_defense':
                return `增加 ${effect.value}% 防御力，持续 ${effect.duration} 秒`;
            case 'buff_speed':
                return `增加 ${effect.value}% 速度，持续 ${effect.duration} 秒`;
            case 'resurrection':
                return `复活后恢复 ${effect.value}% 生命值`;
            case 'enhance':
                return `强化成功率: ${effect.successRate}%`;
            case 'reforge':
                return `重新随机装备属性`;
            default:
                return '';
        }
    }

    // 获取物品属性HTML
    getItemStatsHtml(item) {
        let html = '';
        if (item.stats) {
            for (const [stat, value] of Object.entries(item.stats)) {
                html += `
                    <div class="item-stat">
                        <span class="stat-label">${this.getStatName(stat)}</span>
                        <span class="stat-value">${this.formatStatValue(stat, value)}</span>
                    </div>
                `;
            }
        }
        return html;
    }

    // 获取装备槽图标
    getSlotIcon(slotType) {
        const icons = {
            WEAPON: '⚔️',
            HEAD: '👒',
            BODY: '👕',
            HANDS: '🧤',
            LEGS: '👖',
            FEET: '👞'
        };
        return icons[slotType] || '❓';
    }

    // 获取装备槽名称
    getSlotName(slotType) {
        const names = {
            WEAPON: '武器',
            HEAD: '头部',
            BODY: '衣服',
            HANDS: '手部',
            LEGS: '裤子',
            FEET: '鞋子'
        };
        return names[slotType] || '未知';
    }

    // 获取属性名称
    getStatName(stat) {
        const statNames = {
            attack: '攻击',
            defense: '防御',
            hp: '生命',
            mp: '法力',
            speed: '速度',
            critRate: '暴击',
            critDamage: '暴伤',
            dodge: '闪避',
            lifeSteal: '偷取',
            mpRegen: '恢复',
            skillDamage: '技伤',
            cooldownReduction: '冷却'
            // ... 其他属性名称映射
        };
        return statNames[stat] || stat;
    }

    // 格式化属性值
    formatStatValue(stat, value) {
        if (typeof value === 'number') {
            return value > 0 ? `+${value}` : value;
        }
        return value;
    }

    // 计算当前负重
    calculateCurrentWeight(inventory) {
        let weight = 0;
        // 计算背包物品重量
        inventory.items.forEach(item => {
            if (item && item.weight) {
                weight += item.weight * (item.count || 1);
            }
        });
        // 计算装备物品重量
        Object.values(inventory.equipped).forEach(item => {
            if (item && item.weight) {
                weight += item.weight;
            }
        });
        return weight;
    }

    // 计算最大负重
    calculateMaxWeight(player) {
        // 基础负重 + 力量加成
        const baseWeight = 100;
        const strengthBonus = player.attributes.strength.base * 2;
        return baseWeight + strengthBonus;
    }

    // 添加物品到背包
    addItem(player, item) {
        if (!player.inventory) {
            player.inventory = {
                items: [],
                equipped: {},
                maxSlots: this.calculateMaxSlots(player)
            };
        }

        // 如果是可堆叠物品,尝试堆叠
        if (item.stackable) {
            // 查找背包中相同ID的物品
            const existingItem = player.inventory.items.find(i => 
                i.id.split('_')[0] === item.id.split('_')[0] && // 比较基础ID(不含时间戳)
                i.count < (i.maxStack || 99)
            );
            
            if (existingItem) {
                // 如果找到可堆叠的物品,增加数量
                existingItem.count = (existingItem.count || 1) + 1;
                this.updateInventoryDisplay(player);
                return true;
            }
        }

        // 检查背包是否已满
        if (player.inventory.items.length >= player.inventory.maxSlots) {
            gameManager.showFloatingTip('背包已满！', 'error');
            return false;
        }

        // 如果是新的可堆叠物品,初始化count属性
        if (item.stackable) {
            item.count = 1;
            item.maxStack = 99;
        }

        // 添加新物品到背包
        player.inventory.items.push(item);
        this.updateInventoryDisplay(player);
        return true;
    }

    // 添加物品详情弹窗方法
    showItemDetailDialog(item, itemIndex, player) {
        const dialog = document.createElement('div');
        dialog.className = 'item-detail-dialog';
        
        // 获取品质配置，如果没有则使用默认值
        const qualityConfig = itemGenerator.QUALITY_CONFIG[item.quality] || {
            name: '普通',
            color: '#666'
        };

        // 获取物品类显示名称
        const getTypeName = (item) => {
            // 如果是装备类型
            if (itemGenerator.EQUIPMENT_TYPES[item.type]) {
                return itemGenerator.EQUIPMENT_TYPES[item.type].name;
            }
            
            // 其他类型的物品
            const typeNames = {
                material: '材料',
                consumable: '消耗品',
                book: '书籍',
                quest: '任务物品',
                special: '特殊物品',
                currency: '货币'
            };
            return typeNames[item.type] || item.type;
        };

        // 根据物品类型显示不同的详情内容
        if (item.type === 'consumable' || item.type === 'buff' || item.type === 'special' || 
            item.type === 'material' || item.type === 'book' || item.type === 'quest') {
            dialog.innerHTML = `
                <div class="item-detail-content">
                    <div class="detail-header">
                        <h3>物品详情</h3>
                        <button class="close-detail-btn">×</button>
                    </div>
                    <div class="detail-body">
                        <div class="item-icon-large">${item.icon}</div>
                        <div class="detail-info">
                            <div class="detail-name">
                                ${item.name}
                                ${item.count > 1 ? `<span class="stack-count">(${item.count}/${item.maxStack || 99})</span>` : ''}
                            </div>
                            <div class="item-type">${getTypeName(item)}</div>
                            <div class="detail-description">${item.description || ''}</div>
                            ${item.effect ? `
                                <div class="detail-effect">
                                    ${this.formatEffectDescription(item.effect)}
                                </div>
                            ` : ''}
                        </div>
                        <div class="detail-actions">
                            ${item.type === 'consumable' || item.type === 'buff' || item.type === 'special' ? `
                                <button class="action-btn use-btn">
                                    <span class="btn-icon">✨</span>
                                    使用
                                </button>
                            ` : ''}
                            <button class="action-btn sell-btn">
                                <span class="btn-icon">💰</span>
                                出售 (${Math.floor(Math.max(0, ((item.price || 10) * 0.5)))}金币)
                            </button>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // 装备类物品详情
            dialog.innerHTML = `
                <div class="item-detail-content">
                    <div class="detail-header">
                        <h3>装备详情</h3>
                        <button class="close-detail-btn">×</button>
                    </div>
                    <div class="detail-body">
                        <div class="item-icon-large" style="color: ${qualityConfig.color}">${item.icon}</div>
                        <div class="detail-info">
                            <div class="detail-name" style="color: ${qualityConfig.color}">
                                ${item.name}
                            </div>
                            <div class="equipment-info">
                                <div class="info-row">
                                    <span class="info-label">类型:</span>
                                    <span class="info-value">${getTypeName(item)}</span>
                                </div>
                                <div class="info-row">
                                    <span class="info-label">品质:</span>
                                    <span class="info-value" style="color: ${qualityConfig.color}">${qualityConfig.name}</span>
                                </div>
                            </div>
                            ${item.stats ? `
                                <div class="detail-stats">
                                    ${Object.entries(item.stats).map(([key, value]) => {
                                        const statConfig = itemGenerator.STAT_POOL[key];
                                        if (!statConfig) return '';
                                        return `
                                            <div class="stat-line">
                                                <span class="stat-name">${statConfig.name}</span>
                                                <span class="stat-value">+${value}${statConfig.format === 'percentage' ? '%' : ''}</span>
                                            </div>
                                        `;
                                    }).join('')}
                                </div>
                            ` : ''}
                        </div>
                        <div class="detail-actions">
                            ${itemGenerator.EQUIPMENT_TYPES[item.type] ? `
                                <button class="action-btn equip-btn">
                                    <span class="btn-icon">👕</span>
                                    装备
                                </button>
                            ` : ''}
                            <button class="action-btn sell-btn">
                                <span class="btn-icon">💰</span>
                                出售 (${Math.floor(Math.max(0, ((item.price || 10) * 0.5)))}金币)
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }
        // 添加事件监听
        const closeBtn = dialog.querySelector('.close-detail-btn');
        closeBtn.onclick = () => {
            document.body.removeChild(dialog);
        };

        // 装备按钮
        const equipBtn = dialog.querySelector('.equip-btn');
        if (equipBtn) {
            equipBtn.onclick = () => {
                const result = equipmentSystem.equipItem(gameManager.currentPlayer, item, item.type);
                if (result) {
                    document.body.removeChild(dialog);
                }
            };
        }

        // 使用按钮
        const useBtn = dialog.querySelector('.use-btn');
        if (useBtn) {
            useBtn.onclick = () => {
                const result = equipmentSystem.useItem(gameManager.currentPlayer, item);
                if (result) {
                    document.body.removeChild(dialog);
                }
            };
        }

        // 出售按钮
        const sellBtn = dialog.querySelector('.sell-btn');
        if (sellBtn) {
            // 计算出售价格，使用默认价格10金币
            const basePrice = item.price || 10;  // 如果没有价格则默认为10
            const sellPrice = Math.floor(Math.max(0, basePrice * 0.5));  // 确保不会是负数

            // 更新按钮文本
            sellBtn.innerHTML = `
                <span class="btn-icon">💰</span>
                出售 (${sellPrice}金币)
            `;

            sellBtn.onclick = () => {
                if (confirm(`确定要出售 ${item.name} 吗？可获得 ${sellPrice} 金币`)) {
                    // 添加币
                    player.gold = (player.gold || 0) + sellPrice;
                    
                    // 从背包移除物品
                    if (item.count && item.count > 1) {
                        item.count--;
                    } else {
                        player.inventory.items.splice(itemIndex, 1);
                    }

                    // 更新显示
                    this.updateInventoryDisplay(player);
                    document.body.removeChild(dialog);
                    
                    // 显示提示
                    gameManager.showFloatingTip(`出售成功！获得 ${sellPrice} 金币`, 'success');
                }
            };
        }

        document.body.appendChild(dialog);
    }

    // 设置装备槽事件监听
    setupEquipmentSlotEvents(player) {
        const slots = document.querySelectorAll('.equip-slot');
        slots.forEach(slot => {
            slot.onclick = () => {
                const slotType = slot.dataset.slot;
                const equipped = player.inventory?.equipped?.[slotType];
                if (equipped) {
                    // 直接卸下装备,不再显示详情对话框
                    equipmentSystem.unequipItem(player, slotType);
                }
            };

            // 添加鼠标悬停效果
            slot.onmouseenter = () => {
                const equipped = player.inventory?.equipped?.[slot.dataset.slot];
                if (equipped) {
                    equipmentSystem.addEquipmentTooltip(slot, equipped);
                    slot.classList.add('hover');
                }
            };

            slot.onmouseleave = () => {
                slot.classList.remove('hover');
            };
        });
    }

    // 显示背包面板
    showInventoryPanel() {
        //console.log('Opening inventory panel...'); // 添加初始日志
        
        const panel = document.getElementById('inventory-panel');
        if (!panel) {
            console.error('找不到背包面板元素');
            return;
        }

        try {
            const player = gameManager.currentPlayer;
            if (!player) {
                console.error('找不到玩家数据');
                throw new Error('No player data found');
            }

            //console.log('当前玩家数据:', player);

            // 初始化玩家背包
            if (!player.inventory) {
                //console.log('初始化玩家背包');
                player.inventory = this.initializeInventory(player);
            }

            // 确保玩家有基础属性
            if (!player.stats) {
                //console.log('初始化玩家属性');
                player.stats = {
                    attack: 10,
                    defense: 5,
                    hp: 100,
                    maxHp: 100,
                    mp: 50,
                    maxMp: 50,
                    crit: 5,
                    critDmg: 150,
                    dodge: 5,
                    speed: 10,
                    drain: 0,
                    skillDamage: 0,
                    cooldownReduction: 0,
                    mpRegen: 1
                };
            }

            // 先清空装备区域
            const equipmentSection = panel.querySelector('.equipment-section');
            if (equipmentSection) {
                //console.log('清空装备区域');
                equipmentSection.innerHTML = '';
            }

            // 更新装备栏显示
            //console.log('更新装备栏显示');
            this.updateEquipmentDisplay(player);

            // 更新背包显示
            //console.log('更新背包显示');
            this.updateInventoryDisplay(player);

            // 显示面板
            //console.log('显示背包面板');
            panel.style.display = 'block';

            // 添加关闭按钮事件
            const closeBtn = panel.querySelector('.close-panel-btn');
            if (closeBtn) {
                closeBtn.onclick = () => {
                    panel.style.display = 'none';
                };
            }

        } catch (error) {
            console.error('显示背包面板时出错:', error);
            alert('打开背包失败！');
        }
    }

    // 添加新方法：生成对比属性HTML
    generateComparisonStats(newItem, equippedItem) {
        if (!newItem.stats) return '';

        return Object.entries(newItem.stats).map(([stat, value]) => {
            let comparisonHtml = '';
            
            if (equippedItem && equippedItem.stats) {
                const equippedValue = equippedItem.stats[stat] || 0;
                const difference = value - equippedValue;
                
                if (difference !== 0) {
                    const arrow = difference > 0 ? '↑' : '↓';
                    const color = difference > 0 ? '#4CAF50' : '#f44336';
                    comparisonHtml = `<span class="stat-comparison" style="color: ${color}">
                        (${arrow}${Math.abs(difference)}${itemGenerator.STAT_POOL[stat].format === 'percentage' ? '%' : ''})
                    </span>`;
                }
            }

            return `
                <div class="stat-line">
                    <span class="stat-name">${itemGenerator.STAT_POOL[stat].name}</span>
                    <div class="stat-value-container">
                        <span class="stat-value">+${value}${itemGenerator.STAT_POOL[stat].format === 'percentage' ? '%' : ''}</span>
                        ${comparisonHtml}
                    </div>
                </div>
            `;
        }).join('');
    }

    // 在 InventorySystem 类中添加获取品质图标的方法
    getQualityIcon(quality) {
        const qualityIcons = {
            NORMAL: '⚪',
            RARE: '🟢',
            EPIC: '🔵',
            LEGENDARY: '🟡',
            MYTHIC: '🔴'
        };
        return qualityIcons[quality] || '⚪';
    }

    // 切换批量出售模式
    toggleBulkSellMode(player) {
        this.bulkSellMode = !this.bulkSellMode;
        this.selectedItems.clear();

        const bulkSellBtn = document.querySelector('.bulk-sell-btn');
        const confirmSellBtn = document.querySelector('.confirm-sell-btn');
        
        if (this.bulkSellMode) {
            bulkSellBtn.classList.add('active');
            confirmSellBtn.classList.add('show');
        } else {
            bulkSellBtn.classList.remove('active');
            confirmSellBtn.classList.remove('show');
        }

        this.updateInventoryGrid(player);
    }

    // 切换物品选中状态
    toggleItemSelection(slot, index) {
        if (this.selectedItems.has(index)) {
            this.selectedItems.delete(index);
            slot.classList.remove('selected');
        } else {
            // 确保物品仍然存在
            if (gameManager.currentPlayer.inventory.items[index]) {
                this.selectedItems.add(index);
                slot.classList.add('selected');
            }
        }
        
        // 更新确认按钮状态
        const confirmSellBtn = document.querySelector('.confirm-sell-btn');
        if (confirmSellBtn) {
            if (this.selectedItems.size > 0) {
                confirmSellBtn.classList.add('active');
            } else {
                confirmSellBtn.classList.remove('active');
            }
        }
    }

    // 修改确认批量出售方法
    confirmBulkSell(player) {
        if (this.selectedItems.size === 0) {
            gameManager.showFloatingTip('请先选择要出售的物品', 'warning');
            return;
        }

        // 创建要出售的物品列表
        const itemsToSell = Array.from(this.selectedItems)
            .map(index => ({
                index,
                item: player.inventory.items[index]
            }))
            .filter(({item}) => item != null);

        let totalGold = 0;

        // 计算总价值
        itemsToSell.forEach(({item}) => {
            const basePrice = item.price || 10;
            const sellPrice = Math.floor(basePrice * 0.5);
            totalGold += sellPrice * (item.count || 1);
        });

        if (confirm(`确定要出售选中的 ${itemsToSell.length} 件物品吗？可获得 ${totalGold} 金币`)) {
            // 先添加金币
            player.gold = (player.gold || 0) + totalGold;

            // 获取要删除的索引数组并排序（从大到小）
            const indexesToRemove = Array.from(this.selectedItems).sort((a, b) => b - a);
            
            // 从后往前删除物品，这样不会影响前面物品的索引
            indexesToRemove.forEach(index => {
                player.inventory.items.splice(index, 1);
            });

            // 清空选中的物品集合
            this.selectedItems.clear();

            // 显示提示并更新显示
            gameManager.showFloatingTip(`批量出售成功！获得 ${totalGold} 金币`, 'success');
            this.toggleBulkSellMode(player);
            this.updateInventoryDisplay(player);

            // 保存角色数据
            saveCharacter(player);
        }
    }
}

// 创建全局背包系统实例
const inventorySystem = new InventorySystem(); 

document.addEventListener('DOMContentLoaded', () => {
    //console.log('初始化背包系统...');
    window.inventorySystem = new InventorySystem();
});