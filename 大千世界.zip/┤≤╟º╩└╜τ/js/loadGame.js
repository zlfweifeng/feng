class LoadGameManager {
    constructor() {
        this.saveListElement = document.getElementById('save-list');
        this.currentSaveCount = document.getElementById('current-save-count');
        this.maxSaveCount = document.getElementById('max-save-count');
        this.setupEventListeners();
        this.refreshSaveList();
        this.updateSaveCount();
    }

    // 更新存档数量显示
    updateSaveCount() {
        if (this.currentSaveCount && this.maxSaveCount) {
            const saves = saveManager.loadSaves();
            this.currentSaveCount.textContent = saves.length;
            this.maxSaveCount.textContent = saveManager.MAX_SAVES;
        }
    }

    // 刷新存档列表
    refreshSaveList() {
        const saves = saveManager.loadSaves();
        this.saveListElement.innerHTML = '';

        if (!saves || saves.length === 0) {
            this.saveListElement.innerHTML = `
                <div class="no-saves">
                    <p>暂无存档</p>
                </div>
            `;
        } else {
            // 过滤掉无效的存档并按最后保存时间排序
            const validSaves = saves
                .filter(save => save && save.id && save.character && save.character.name)
                .sort((a, b) => b.lastSaved - a.lastSaved);

            validSaves.forEach(save => {
                const saveItem = this.createSaveItem(save);
                if (saveItem) {
                    this.saveListElement.appendChild(saveItem);
                }
            });
        }

        // 更新存档数量
        this.updateSaveCount();
    }

    // 创建存档项
    createSaveItem(save) {
        if (!save || !save.id) {
            console.error('Invalid save data:', save);
            return null;
        }

        const div = document.createElement('div');
        div.className = 'save-item';
        const saveId = String(save.id);
        
        div.innerHTML = `
            <div class="save-info">
                <div class="save-header">
                    <span class="character-icon">${Character.getClassIcon(save.character.class)}</span>
                    <span class="character-name">${save.character.name}</span>
                    <span class="character-level">Lv.${save.character.level}</span>
                </div>
                <div class="save-details">
                    职业：${this.getClassName(save.character.class)}
                </div>
                <div class="save-timestamp">
                    保存时间：${save.timestamp}
                </div>
            </div>
            <div class="save-actions">
                <button class="save-action-btn load-btn" data-save-id="${saveId}">
                    <span class="button-icon">▶️</span>
                    加载
                </button>
                <button class="save-action-btn export-btn" data-save-id="${saveId}">
                    <span class="button-icon">📤</span>
                    导出
                </button>
                <button class="save-action-btn delete-btn" data-save-id="${saveId}">
                    <span class="button-icon">🗑️</span>
                    删除
                </button>
            </div>
        `;
        return div;
    }

    // 获取职业中文名
    getClassName(classId) {
        const classNames = {
            mage: '法师',
            warrior: '战士',
            monk: '武者',
            taoist: '道士'
        };
        return classNames[classId] || classId;
    }

    // 设置事件监听
    setupEventListeners() {
        // 返回按钮
        const backButton = document.getElementById('back-to-main-from-load');
        if (backButton) {
            backButton.addEventListener('click', () => {
                showPage('start-page');
            });
        }

        // 导入存档按钮
        const importButton = document.getElementById('import-save');
        const importInput = document.getElementById('import-save-input');
        
        if (importButton) {
            importButton.addEventListener('click', () => {
                importInput.click();
            });
        }

        if (importInput) {
            importInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = async (e) => {
                        try {
                            const saveData = JSON.parse(e.target.result);
                            await this.handleSaveImport(saveData);
                        } catch (error) {
                            console.error('Import error:', error);
                            alert('存档文件格式错误！');
                        }
                    };
                    reader.readAsText(file);
                }
            });
        }

        // 导出所有存档按钮
        const exportAllButton = document.getElementById('export-all-saves');
        if (exportAllButton) {
            exportAllButton.addEventListener('click', () => {
                const saves = saveManager.loadSaves();
                if (saves.length === 0) {
                    alert('没有可导出的存档！');
                    return;
                }
                
                const saveData = JSON.stringify(saves, null, 2);
                const blob = new Blob([saveData], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `all_saves_${new Date().toISOString().slice(0,10)}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            });
        }

        // 存档列表的点击事件委托
        if (this.saveListElement) {
            this.saveListElement.addEventListener('click', (e) => {
                const button = e.target.closest('.save-action-btn');
                if (!button) return;

                const saveId = button.dataset.saveId;
                if (!saveId) {
                    console.error('No save ID found');
                    return;
                }

                console.log('Clicked button:', button.className, 'Save ID:', saveId);

                if (button.classList.contains('load-btn')) {
                    this.loadSave(saveId);
                } else if (button.classList.contains('export-btn')) {
                    this.exportSave(saveId);
                } else if (button.classList.contains('delete-btn')) {
                    this.deleteSave(saveId);
                }
            });
        }

        // 清空所有存档按钮
        const clearAllButton = document.getElementById('clear-all-saves');
        if (clearAllButton) {
            clearAllButton.addEventListener('click', () => {
                this.clearAllSaves();
            });
        }
    }

    // 加载存档
    loadSave(saveId) {
        //console.log('Loading save:', saveId);
        try {
            const character = saveManager.loadSave(saveId);
            if (!character) {
                console.error('Failed to load character data');
                alert('加载存档失败：未找到角色数据！');
                return;
            }

            if (typeof gameManager !== 'undefined') {
                try {
                    gameManager.setPlayer(character);
                    showPage('game-main');
                } catch (error) {
                    console.error('Error loading character:', error);
                    alert(error.message);
                }
            } else {
                console.error('Game manager not initialized');
                alert('加载存档失败：游戏管理器未初始化！');
            }
        } catch (error) {
            console.error('Error loading save:', error);
            alert('加载存档失败：' + error.message);
        }
    }

    // 导出单个存档
    exportSave(saveId) {
        //console.log('Exporting save:', saveId);
        const saves = saveManager.loadSaves();
        // 将saveId转换为数字进行比较
        const save = saves.find(s => String(s.id) === String(saveId));
        if (save) {
            const saveData = JSON.stringify(save, null, 2);
            const blob = new Blob([saveData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `save_${save.character.name}_${new Date().toISOString().slice(0,10)}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } else {
            alert('导出失败：未找到存档！');
        }
    }

    // 删除存档
    deleteSave(saveId) {
        if (!saveId) {
            console.error('Invalid save ID');
            return;
        }

        //console.log('Deleting save:', saveId);
        if (confirm('确定要删除这个存档吗？')) {
            try {
                // 先检查存档是否存在
                const saves = saveManager.loadSaves();
                const saveExists = saves.some(s => String(s.id) === String(saveId));
                
                if (!saveExists) {
                    alert('该存档已不存在！');
                    this.refreshSaveList(); // 刷新列表以显示最新状态
                    return;
                }

                if (saveManager.deleteSave(saveId)) {
                    // 删除成功后立即重新获取存档列表
                    const remainingSaves = saveManager.loadSaves();
                    
                    // 更新DOM
                    this.saveListElement.innerHTML = '';
                    if (remainingSaves.length === 0) {
                        this.saveListElement.innerHTML = `
                            <div class="no-saves">
                                <p>暂无存档</p>
                            </div>
                        `;
                    } else {
                        remainingSaves.forEach(save => {
                            const saveItem = this.createSaveItem(save);
                            if (saveItem) {
                                this.saveListElement.appendChild(saveItem);
                            }
                        });
                    }
                    
                    // 更新存档计数
                    this.updateSaveCount();
                    alert('删除成功！');
                } else {
                    alert('删除失败！');
                }
            } catch (error) {
                console.error('Error deleting save:', error);
                alert('删除失败：' + error.message);
            }
        }
    }

    // 清空所有存档
    clearAllSaves() {
        const saves = saveManager.loadSaves();
        if (saves.length === 0) {
            alert('没有可清空的存档！');
            return;
        }

        if (confirm('确定要清空所有存档吗？此操作不可恢复！')) {
            try {
                localStorage.removeItem('gameSaves');
                this.refreshSaveList();
                alert('所有存档已清空！');
            } catch (error) {
                console.error('Error clearing saves:', error);
                alert('清空存档失败：' + error.message);
            }
        }
    }

    // 处理存档导入
    async handleSaveImport(saveData) {
        const saves = saveManager.loadSaves();
        const currentCount = saves.length;

        // 如果存档未满，直接导入
        if (currentCount < saveManager.MAX_SAVES) {
            saveManager.saveCharacter(saveData.character);
            this.refreshSaveList();
            alert('存档导入成功！');
            return;
        }

        // 如果存档已满，显示选择对话框
        const result = await this.showReplaceDialog(saves, saveData);
        if (result === 'cancel') {
            return;
        }

        // 替换选中的存档
        if (result !== null) {
            const updatedSaves = [...saves];
            updatedSaves[result] = {
                id: Date.now(),
                timestamp: new Date().toLocaleString(),
                character: saveData.character,
                lastSaved: new Date().getTime()
            };
            localStorage.setItem('gameSaves', JSON.stringify(updatedSaves));
            this.refreshSaveList();
            alert('存档替换成功！');
        }
    }

    // 显示存档替换选择对话框
    showReplaceDialog(saves, newSave) {
        return new Promise((resolve) => {
            // 创建对话框容器
            const dialog = document.createElement('div');
            dialog.className = 'replace-dialog';
            
            dialog.innerHTML = `
                <div class="replace-dialog-content">
                    <h3>存档已满，请选择要替换的存档：</h3>
                    <div class="replace-save-list">
                        ${saves.map((save, index) => `
                            <div class="replace-save-item">
                                <input type="radio" name="replace-save" id="save-${index}" value="${index}">
                                <label for="save-${index}">
                                    <span class="character-icon">${Character.getClassIcon(save.character.class)}</span>
                                    <span class="character-name">${save.character.name}</span>
                                    <span class="character-level">Lv.${save.character.level}</span>
                                    <span class="save-time">${save.timestamp}</span>
                                </label>
                            </div>
                        `).join('')}
                    </div>
                    <div class="dialog-buttons">
                        <button class="dialog-btn confirm-btn">确认替换</button>
                        <button class="dialog-btn cancel-btn">取消</button>
                    </div>
                </div>
            `;

            // 添加样式
            const style = document.createElement('style');
            style.textContent = `
                .replace-dialog {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.5);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 1000;
                }
                .replace-dialog-content {
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                    width: 90%;
                    max-width: 500px;
                    max-height: 80vh;
                    overflow-y: auto;
                }
                .replace-save-list {
                    margin: 15px 0;
                }
                .replace-save-item {
                    padding: 10px;
                    border: 1px solid #ddd;
                    margin: 5px 0;
                    border-radius: 5px;
                    display: flex;
                    align-items: center;
                }
                .replace-save-item label {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    flex: 1;
                    cursor: pointer;
                }
                .dialog-buttons {
                    display: flex;
                    justify-content: center;
                    gap: 15px;
                    margin-top: 20px;
                }
                .dialog-btn {
                    padding: 8px 20px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                }
                .confirm-btn {
                    background: #4CAF50;
                    color: white;
                }
                .cancel-btn {
                    background: #e74c3c;
                    color: white;
                }
            `;
            document.head.appendChild(style);
            document.body.appendChild(dialog);

            // 添加事件监听
            const confirmBtn = dialog.querySelector('.confirm-btn');
            const cancelBtn = dialog.querySelector('.cancel-btn');

            confirmBtn.addEventListener('click', () => {
                const selectedRadio = dialog.querySelector('input[name="replace-save"]:checked');
                document.body.removeChild(dialog);
                if (selectedRadio) {
                    resolve(parseInt(selectedRadio.value));
                } else {
                    alert('请选择要替换的存档！');
                    resolve(null);
                }
            });

            cancelBtn.addEventListener('click', () => {
                document.body.removeChild(dialog);
                resolve('cancel');
            });
        });
    }
}

// 当页面加载完成后初始化存档管理器
let loadGameManager;
document.addEventListener('DOMContentLoaded', () => {
    loadGameManager = new LoadGameManager();
}); 