class Character {
    constructor(name, characterClass) {
        this.name = name;
        this.class = characterClass;
        this.level = 1;
        this.exp = 0;
        this.gold = 1000000;
        this.attributes = this.initializeAttributes(characterClass);
        this.stats = this.calculateStats();
        this.skills = [];
        this.skillPoints = 10;
        
        // 初始化背包系统
        this.inventory = {
            items: [],
            equipped: {},
            maxSlots: 20
        };

        // 初始化基础技能
        this.initializeBaseSkills();
    }

    // 添加初始化基础技能的方法
    initializeBaseSkills() {
        // 添加基础攻击技能
        this.skills.push({
            id: 'basic_attack',
            name: '普通攻击',
            icon: '⚔️',
            type: 'basic',
            level: 1
        });

        // 根据职业添加初始技能
        const classSkills = SkillSystem.SKILLS_CONFIG[this.class]?.basic || [];
        if (classSkills.length > 0) {
            // 添加第一个职业基础技能
            const firstSkill = classSkills[0];
            this.skills.push({
                id: firstSkill.id,
                name: firstSkill.name,
                icon: firstSkill.icon,
                type: 'basic',
                level: 0 // 初始等级为0，需要使用技能点升级
            });
        }
    }

    // 初始化属性
    initializeAttributes(characterClass) {
        const baseAttributes = {
            mage: {
                strength: { base: 8, growth: 1.2 },    // 力道成长较低
                constitution: { base: 12, growth: 2.0 },// 根骨成长中等
                agility: { base: 9, growth: 1.5 },     // 身法成长较低
                wisdom: { base: 15, growth: 2.5 },     // 悟性成长最高
                speed: { base: 10, growth: 1.8 }       // 速度成长中等
            },
            warrior: {
                strength: { base: 15, growth: 2.5 },   // 力道成长最高
                constitution: { base: 14, growth: 2.2 },// 根骨成长较高
                agility: { base: 10, growth: 1.5 },    // 身法成长中等
                wisdom: { base: 8, growth: 1.2 },      // 悟性成长较低
                speed: { base: 11, growth: 1.8 }       // 速度成长中等
            },
            monk: {
                strength: { base: 13, growth: 2.0 },   // 力道成长较高
                constitution: { base: 12, growth: 1.8 },// 根骨成长中等
                agility: { base: 14, growth: 2.2 },    // 身法成长最高
                wisdom: { base: 10, growth: 1.5 },     // 悟性成长中等
                speed: { base: 13, growth: 2.0 }       // 速度成长较高
            },
            taoist: {
                strength: { base: 9, growth: 1.3 },    // 力道成长较低
                constitution: { base: 11, growth: 1.8 },// 根骨成长中等
                agility: { base: 12, growth: 1.7 },    // 身法成长中等
                wisdom: { base: 14, growth: 2.3 },     // 悟性成长较高
                speed: { base: 12, growth: 1.9 }       // 速度成长中等
            }
        };
        return baseAttributes[characterClass];
    }

    // 计算衍生属性
    calculateStats() {
        const attrs = this.attributes;
        // 保存旧的最大值，用于计算差值
        const oldMaxHp = this.stats?.maxHp || 0;
        const oldMaxMp = this.stats?.maxMp || 0;

        const stats = {
            // 基础生命值和法力值
            hp: this.stats?.hp || (100 + Number((attrs.constitution.base * 5).toFixed(1))),
            maxHp: 100 + Number((attrs.constitution.base * 5).toFixed(1)),
            mp: this.stats?.mp || (100 + Number((attrs.wisdom.base * 3).toFixed(1))),
            maxMp: 100 + Number((attrs.wisdom.base * 3).toFixed(1)),
            
            // 战斗属性
            attack: 10 + Number((attrs.strength.base * 1.5).toFixed(1)),
            defense: 10 + Number((attrs.constitution.base * 1.2).toFixed(1)),
            hit: Number((attrs.wisdom.base * 1.3).toFixed(1)),
            dodge: Number((attrs.agility.base * 1.2).toFixed(1)),
            crit: Number((attrs.agility.base * 0.5).toFixed(1)),
            critDmg: 150 + Number((attrs.strength.base * 0.8).toFixed(1)),
            drain: Number((attrs.wisdom.base * 0.3).toFixed(1)),
            speed: Number(attrs.speed.base.toFixed(1))
        };

        // 确保 inventory 存在并添加装备加成
        if (this.inventory?.equipped) {
            for (const [slot, item] of Object.entries(this.inventory.equipped)) {
                if (item?.stats) {
                    for (const [stat, value] of Object.entries(item.stats)) {
                        if (stats[stat] !== undefined) {
                            // 对于最大生命值和最大法力值的特殊处理
                            if (stat === 'hp' || stat === 'maxHp') {
                                stats.maxHp += Number(value.toFixed(1));
                                // 当前生命值也相应增加
                                stats.hp += Number(value.toFixed(1));
                            } else if (stat === 'mp' || stat === 'maxMp') {
                                stats.maxMp += Number(value.toFixed(1));
                                // 当前法力值也相应增加
                                stats.mp += Number(value.toFixed(1));
                            } else {
                                stats[stat] += Number(value.toFixed(1));
                            }
                        }
                    }
                }
            }
        }

        // 确保生命值和法力值不超过最大值
        stats.hp = Math.min(stats.hp, stats.maxHp);
        stats.mp = Math.min(stats.mp, stats.maxMp);

        return stats;
    }

    // 初始化技能
    initializeSkills(characterClass) {
        const skillSets = {
            mage: [
                {
                    name: '火球术',
                    description: '释放一个火球造成魔法伤害',
                    damage: 30,
                    mpCost: 15,
                    cooldown: 2,
                    type: 'magic'
                },
                {
                    name: '冰冻术',
                    description: '冰冻敌人，造成伤害并减速',
                    damage: 20,
                    mpCost: 20,
                    cooldown: 4,
                    type: 'magic',
                    effect: 'slow'
                }
            ],
            warrior: [
                {
                    name: '横扫千军',
                    description: '对周围敌人造成物理伤害',
                    damage: 25,
                    mpCost: 10,
                    cooldown: 3,
                    type: 'physical'
                },
                {
                    name: '战争怒吼',
                    description: '提升自身攻击力和防御力',
                    mpCost: 15,
                    cooldown: 5,
                    type: 'buff',
                    effect: 'increase_attack_defense'
                }
            ],
            monk: [
                {
                    name: '连环踢',
                    description: '快速踢击敌人多次',
                    damage: 15,
                    hits: 3,
                    mpCost: 12,
                    cooldown: 3,
                    type: 'physical'
                },
                {
                    name: '气功波',
                    description: '发射气功波造成伤害',
                    damage: 35,
                    mpCost: 20,
                    cooldown: 4,
                    type: 'energy'
                }
            ],
            taoist: [
                {
                    name: '五雷符',
                    description: '召唤雷电攻击敌人',
                    damage: 28,
                    mpCost: 18,
                    cooldown: 3,
                    type: 'magic'
                },
                {
                    name: '太极护体',
                    description: '创造防护罩减少伤害',
                    mpCost: 25,
                    cooldown: 6,
                    type: 'buff',
                    effect: 'damage_reduction'
                }
            ]
        };
        return skillSets[characterClass];
    }

    // 职业描述
    static getClassDescription(characterClass) {
        const descriptions = {
            mage: "精通法术的智者，擅长远程魔法攻击，具有强大的法术输出能力。",
            warrior: "强大的近战战士，拥有超高的物理攻击力和防御力。",
            monk: "灵活的武学大师，擅长近身格斗和连击技能。",
            taoist: "精通道法的修士，善于使用符咒和法术，平衡攻守。"
        };
        return descriptions[characterClass];
    }

    // 职业图标
    static getClassIcon(characterClass) {
        const icons = {
            mage: "🧙‍♂️",
            warrior: "⚔️",
            monk: "🥋",
            taoist: "☯️"
        };
        return icons[characterClass];
    }

    // 添加升级方法
    levelUp() {
        this.level++;
        this.exp = 0;
        this.skillPoints += 1;

        // 确保 inventory 存在
        if (!this.inventory) {
            this.inventory = {
                items: [],
                equipped: {},
                maxSlots: 20
            };
        }

        // 先移除装备加成
        const oldEquipped = {...(this.inventory.equipped || {})};
        this.inventory.equipped = {};

        // 根据职业成长公式增加属性
        this.growAttributes();

        // 重新计算基础属性(不含装备)
        this.stats = this.calculateStats();

        // 恢复装备
        this.inventory.equipped = oldEquipped;
        
        // 重新计算最终属性(含装备)
        this.stats = this.calculateStats();

        // 升级时恢复所有生命值和法力值
        this.stats.hp = this.stats.maxHp;
        this.stats.mp = this.stats.maxMp;

        // 显示升级信息
        this.showLevelUpMessage();

        // 更新游戏管理器中的玩家数据
        if (gameManager) {
            gameManager.currentPlayer = this;
            // 强制更新游戏管理器的显示
            gameManager.updatePlayerInfo();
        }

        // 如果背包面板打开，更新背包显示
        if (inventorySystem) {
            const inventoryPanel = document.getElementById('inventory-panel');
            if (inventoryPanel && inventoryPanel.style.display === 'block') {
                inventorySystem.updateInventoryDisplay(this);
            }
        }

        // 如果角色面板打开，更新角色面板
        const characterPanel = document.getElementById('character-panel');
        if (characterPanel && characterPanel.style.display === 'block') {
            this.updateCharacterPanel();
        }

        // 更新主界面状态条
        this.updateMainGameBars();

        // 更新等级和经验条
        this.updateLevelAndExp();

        // 保存角色数据
        saveCharacter(this);

        // 强制触发DOM更新
        requestAnimationFrame(() => {
            document.body.offsetHeight;
            // 再次更新所有界面确保同步
            if (gameManager) {
                gameManager.updatePlayerInfo();
            }
        });

        console.log(`${this.name} 升级到 ${this.level} 级!`, {
            属性: this.attributes,
            状态: this.stats,
            装备: this.inventory.equipped
        });
    }

    // 修改属性成长方法
    growAttributes() {
        // 遍历所有属性
        for (const [attr, data] of Object.entries(this.attributes)) {
            // 获取成长值并保留一位小数
            const growth = Number(data.growth.toFixed(1));
            
            // 更新基础属性值(保留一位小数)
            const oldValue = Number(data.base.toFixed(1));
            data.base = Number((oldValue + growth).toFixed(1));
            const increase = Number((data.base - oldValue).toFixed(1));

            console.log(`${attr} 成长: +${increase} (${oldValue} -> ${data.base})`);
        }
    }

    // 修改显示升级提示的方法
    showLevelUpMessage() {
        const oldLevel = this.level - 1; // 因为已经升级了所以要减1
        
        // 创建提示元素
        const message = document.createElement('div');
        message.className = 'level-up-message';
        message.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #4CAF50;
            font-size: 18px;
            text-align: center;
            z-index: 9999;
            animation: fadeInOut 3s forwards;
        `;

        // 创建CSS动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
                10% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                80% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                100% { opacity: 0; transform: translate(-50%, -50%) scale(1.2); }
            }
        `;
        document.head.appendChild(style);

        // 生成属性变化文本
        const attributeChanges = [];
        for (const [attr, data] of Object.entries(this.attributes)) {
            const attrNames = {
                strength: '力道',
                constitution: '根骨',
                agility: '身法',
                wisdom: '悟性',
                speed: '速度'
            };
            const oldValue = Number((data.base - data.growth).toFixed(1));
            const newValue = Number(data.base.toFixed(1));
            const increase = Number((newValue - oldValue).toFixed(1));
            attributeChanges.push(`${attrNames[attr]}: ${oldValue} ───> ${newValue} (+${increase})`);
        }

        // 设置消息内容
        message.innerHTML = `
            <div style="font-size: 24px; margin-bottom: 10px;">升级了！</div>
            <div style="margin-bottom: 15px;">${oldLevel}级 ───> ${this.level}级</div>
            <div style="font-size: 16px; color: #45a049; text-align: left; margin-left: 20px;">
                ${attributeChanges.join('<br>')}
            </div>
        `;

        // 添加到面
        document.body.appendChild(message);

        // 3秒后移除
        setTimeout(() => {
            if (message.parentNode) {
                message.parentNode.removeChild(message);
            }
            if (style.parentNode) {
                style.parentNode.removeChild(style);
            }
        }, 3000);
    }

    // 修改更新所有显示的方法
    updateAllDisplays() {
        if (gameManager) {
            // 先重新计算属性
            this.stats = this.calculateStats();

            // 更新主游戏界面的状态条
            this.updateMainGameBars();

            // 更新角色面板
            this.updateCharacterPanel();

            // 更新背包界面
            this.updateInventoryPanel();

            // 更新等级和经验条
            this.updateLevelAndExp();

            // 强制更新游戏管理器中的玩家数据
            gameManager.currentPlayer = this;
            
            // 强制更新所有界面
            gameManager.updatePlayerInfo();

            // 保存角色数据
            saveCharacter(this);

            // 强制更新背包系统中的玩家数据
            if (inventorySystem) {
                inventorySystem.updateInventoryDisplay(this);
            }

            console.log('更新后的角色状态:', {
                等级: this.level,
                属性: this.attributes,
                状态: this.stats,
                装备: this.inventory.equipped
            });
        }
    }

    // 修改更新主游戏状态条的方法
    updateMainGameBars() {
        // 先重新计算状态
        this.stats = this.calculateStats();
        
        // 更新HP条
        const hpBar = document.querySelector('.hp-bar .bar-fill');
        const hpText = document.querySelector('.hp-bar .bar-text');
        if (hpBar && hpText) {
            const hpPercent = (this.stats.hp / this.stats.maxHp) * 100;
            hpBar.style.width = `${hpPercent}%`;
            hpText.textContent = `${Math.floor(this.stats.hp)}/${Math.floor(this.stats.maxHp)}`;
        }

        // 更新MP条
        const mpBar = document.querySelector('.mp-bar .bar-fill');
        const mpText = document.querySelector('.mp-bar .bar-text');
        if (mpBar && mpText) {
            const mpPercent = (this.stats.mp / this.stats.maxMp) * 100;
            mpBar.style.width = `${mpPercent}%`;
            mpText.textContent = `${Math.floor(this.stats.mp)}/${Math.floor(this.stats.maxMp)}`;
        }

        // 强制重新渲染状态条
        requestAnimationFrame(() => {
            if (hpBar) {
                hpBar.style.transition = 'none';
                hpBar.offsetHeight; // 触发重排
                hpBar.style.transition = '';
            }
            if (mpBar) {
                mpBar.style.transition = 'none';
                mpBar.offsetHeight; // 触发重排
                mpBar.style.transition = '';
            }
        });
    }

    // 添加更新角色面板的方法
    updateCharacterPanel() {
        const characterPanel = document.getElementById('character-panel');
        if (characterPanel && characterPanel.style.display === 'block') {
            // 更新所有基础属性显示
            const attributesSection = characterPanel.querySelector('.attributes-section');
            if (attributesSection) {
                attributesSection.innerHTML = `
                    <h4>角色属性</h4>
                    <div class="attributes-grid">
                        ${gameManager.generateCharacterStatsHTML(this)}
                    </div>
                `;
            }

            // 更新状态条
            const charHpBar = characterPanel.querySelector('.char-hp-fill');
            const charHpText = characterPanel.querySelector('.char-hp-value');
            if (charHpBar && charHpText) {
                const hpPercent = (this.stats.hp / this.stats.maxHp) * 100;
                charHpBar.style.width = `${hpPercent}%`;
                charHpText.textContent = `${Math.floor(this.stats.hp)}/${Math.floor(this.stats.maxHp)}`;
            }

            const charMpBar = characterPanel.querySelector('.char-mp-fill');
            const charMpText = characterPanel.querySelector('.char-mp-value');
            if (charMpBar && charMpText) {
                const mpPercent = (this.stats.mp / this.stats.maxMp) * 100;
                charMpBar.style.width = `${mpPercent}%`;
                charMpText.textContent = `${Math.floor(this.stats.mp)}/${Math.floor(this.stats.maxMp)}`;
            }
        }
    }

    // 添加更新背包界面的方法
    updateInventoryPanel() {
        const inventoryPanel = document.getElementById('inventory-panel');
        if (inventoryPanel && inventoryPanel.style.display === 'block') {
            // 更新背包显示
            inventorySystem.updateInventoryDisplay(this);
            
            // 更新背包中的角色属性显示
            const statsContainer = inventoryPanel.querySelector('.player-stats');
            if (statsContainer) {
                statsContainer.innerHTML = equipmentSystem.generatePlayerStatsHTML(this);
            }
        }
    }

    // 添加更新等级和经验条的方法
    updateLevelAndExp() {
        // 更新等级显示
        const levelDisplay = document.getElementById('player-level');
        if (levelDisplay) {
            levelDisplay.textContent = this.level;
        }

        // 更新经验条
        const expBar = document.querySelector('.exp-bar .bar-fill');
        const expText = document.querySelector('.exp-bar .bar-text');
        if (expBar && expText) {
            const maxExp = gameManager.getExpForNextLevel(this.level);
            const expPercent = (this.exp / maxExp) * 100;
            expBar.style.width = `${expPercent}%`;
            expText.textContent = `${this.exp}/${maxExp}`;
        }
    }
}

// 页面加载完成后的初始化
document.addEventListener('DOMContentLoaded', () => {
    const classButtons = document.querySelectorAll('.class-btn');
    const classCard = document.querySelector('.class-card');
    
    // 更新职业卡片显示
    function updateClassCard(characterClass) {
        const attributes = new Character('temp', characterClass).attributes;
        const description = Character.getClassDescription(characterClass);
        const icon = Character.getClassIcon(characterClass);

        classCard.innerHTML = `
            <div class="card-header">
                <span class="class-icon">${icon}</span>
                <h3 class="class-name">${characterClass === 'mage' ? '法师' : 
                                       characterClass === 'warrior' ? '战士' :
                                       characterClass === 'monk' ? '武者' : '道士'}</h3>
            </div>
            <div class="card-content">
                <div class="class-description">
                    <p>${description}</p>
                </div>
                <div class="attributes">
                    <h4>基础属</h4>
                    <div class="attribute-grid">
                        <div class="attribute-item">
                            <span class="attribute-label">力道:</span>
                            <span class="attribute-value">${attributes.strength.base}</span>
                            <span class="attribute-growth">(+${attributes.strength.growth}/级)</span>
                        </div>
                        <div class="attribute-item">
                            <span class="attribute-label">根骨:</span>
                            <span class="attribute-value">${attributes.constitution.base}</span>
                            <span class="attribute-growth">(+${attributes.constitution.growth}/级)</span>
                        </div>
                        <div class="attribute-item">
                            <span class="attribute-label">身法:</span>
                            <span class="attribute-value">${attributes.agility.base}</span>
                            <span class="attribute-growth">(+${attributes.agility.growth}/级)</span>
                        </div>
                        <div class="attribute-item">
                            <span class="attribute-label">悟性:</span>
                            <span class="attribute-value">${attributes.wisdom.base}</span>
                            <span class="attribute-growth">(+${attributes.wisdom.growth}/级)</span>
                        </div>
                        <div class="attribute-item">
                            <span class="attribute-label">速度:</span>
                            <span class="attribute-value">${attributes.speed.base}</span>
                            <span class="attribute-growth">(+${attributes.speed.growth}/级)</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // 初始化显示法师信息
    updateClassCard('mage');

    // 职业选择按钮点击事
    classButtons.forEach(button => {
        button.addEventListener('click', () => {
            // 移除其他按钮的active类
            classButtons.forEach(btn => btn.classList.remove('active'));
            // 添加当前按钮的active类
            button.classList.add('active');
            // 更新职业卡片
            updateClassCard(button.dataset.class);
        });
    });

    // 创建角色按钮点击事件
    const createButton = document.getElementById('create-character');
    createButton.addEventListener('click', () => {
        const name = document.getElementById('character-name').value;
        const selectedClass = document.querySelector('.class-btn.active').dataset.class;
        
        if (name.trim() === '') {
            alert('请输入角色名称！');
            return;
        }

        // 创建新角色
        const newCharacter = new Character(name, selectedClass);
        
        // 保存角色数据并获取存档信息
        const saveData = saveCharacter(newCharacter);
        
        if (!saveData) {
            alert('角色保存失败！');
            return;
        }
        
        // 初始化游戏管理器并设置玩家
        if (typeof gameManager !== 'undefined') {
            gameManager.setPlayer(newCharacter);
            gameManager.addGameLog(`创建角色成功！存档时间：${saveData.timestamp}`);
        }
        
        // 跳转到游戏主页面
        showPage('game-main');
    });
}); 