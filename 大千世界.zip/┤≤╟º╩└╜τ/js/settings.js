class CombatSettings {
    constructor() {
        this.filterRules = [];
        document.addEventListener('DOMContentLoaded', () => {
            this.initializeEventListeners();
        });
    }

    initializeEventListeners() {
        const combatSettingsBtn = document.querySelector('.combat-settings');
        if (combatSettingsBtn) {
            combatSettingsBtn.addEventListener('click', () => {
                this.showCombatSettingsPanel();
            });
        }

        const closeBtn = document.querySelector('#combat-settings-panel .close-panel-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.hideCombatSettingsPanel();
            });
        }

        const addFilterBtn = document.querySelector('.zd_add-filter-btn');
        if (addFilterBtn) {
            addFilterBtn.addEventListener('click', () => {
                this.addFilterRule();
            });
        }

        this.loadFilterRules();
    }

    showCombatSettingsPanel() {
        const panel = document.getElementById('combat-settings-panel');
        if (panel) {
            const settingsPanel = document.getElementById('settings-panel');
            if (settingsPanel) {
                settingsPanel.style.display = 'none';
            }

            panel.style.opacity = '0';
            panel.style.display = 'block';
            
            requestAnimationFrame(() => {
                panel.style.opacity = '1';
            });
        }
    }

    hideCombatSettingsPanel() {
        const panel = document.getElementById('combat-settings-panel');
        if (panel) {
            panel.style.opacity = '0';
            
            setTimeout(() => {
                panel.style.display = 'none';
                
                const settingsPanel = document.getElementById('settings-panel');
                if (settingsPanel) {
                    settingsPanel.style.display = 'block';
                }
            }, 300);
        }
    }

    updateFilterValueOptions(typeSelect, valueSelect) {
        if (!typeSelect || !valueSelect) return;
        
        valueSelect.innerHTML = '';
        
        switch(typeSelect.value) {
            case 'quality':
                // 添加品质选项
                const qualities = [
                    { value: 'NORMAL', name: '普通' },
                    { value: 'RARE', name: '稀有' },
                    { value: 'EPIC', name: '史诗' },
                    { value: 'LEGENDARY', name: '传说' },
                    { value: 'MYTHIC', name: '神话' }
                ];
                
                qualities.forEach(quality => {
                    const option = document.createElement('option');
                    option.value = quality.value;
                    option.textContent = quality.name;
                    valueSelect.appendChild(option);
                });
                break;
                
            case 'type':
                // 添加装备类型选项
                const types = [
                    { value: 'WEAPON', name: '武器' },
                    { value: 'HEAD', name: '头部' },
                    { value: 'BODY', name: '衣服' },
                    { value: 'HANDS', name: '手部' },
                    { value: 'LEGS', name: '裤子' },
                    { value: 'FEET', name: '鞋子' },
                    { value: 'material', name: '材料' },
                    { value: 'consumable', name: '消耗品' }
                ];
                
                types.forEach(type => {
                    const option = document.createElement('option');
                    option.value = type.value;
                    option.textContent = type.name;
                    valueSelect.appendChild(option);
                });
                break;
                
            case 'level':
                // 添加等级选项
                for(let i = 1; i <= 50; i++) {
                    const option = document.createElement('option');
                    option.value = i;
                    option.textContent = `${i}级`;
                    valueSelect.appendChild(option);
                }
                break;
        }

        // 添加change事件监听
        valueSelect.addEventListener('change', () => {
            this.saveFilterRules();
        });
    }

    addFilterRule() {
        const template = document.querySelector('.zd_filter-rule-template');
        if (!template) {
            console.error('找不到过滤规则模板');
            return;
        }

        const filterList = document.querySelector('.zd_filter-list');
        if (!filterList) {
            console.error('找不到过滤规则列表容器');
            return;
        }

        // 创建新规则元素
        const newRule = template.cloneNode(true);
        newRule.classList.remove('zd_filter-rule-template');
        newRule.style.display = 'block';

        // 获取选择框元素
        const typeSelect = newRule.querySelector('.zd_filter-type');
        const conditionSelect = newRule.querySelector('.zd_filter-condition');
        const valueSelect = newRule.querySelector('.zd_filter-value');

        // 初始化值选项
        this.updateFilterValueOptions(typeSelect, valueSelect);

        // 添加事件监听
        typeSelect.addEventListener('change', () => {
            this.updateFilterValueOptions(typeSelect, valueSelect);
            this.saveFilterRules();
        });

        conditionSelect.addEventListener('change', () => {
            this.saveFilterRules();
        });

        valueSelect.addEventListener('change', () => {
            this.saveFilterRules();
        });

        // 添加删除按钮事件
        const deleteBtn = newRule.querySelector('.zd_delete-rule-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => {
                newRule.remove();
                this.saveFilterRules();
            });
        }

        // 添加到列表
        filterList.appendChild(newRule);
        this.saveFilterRules();
    }

    saveFilterRules() {
        const rules = [];
        document.querySelectorAll('.zd_filter-list .zd_filter-rule').forEach(rule => {
            rules.push({
                type: rule.querySelector('.zd_filter-type').value,
                condition: rule.querySelector('.zd_filter-condition').value,
                value: rule.querySelector('.zd_filter-value').value
            });
        });
        
        this.filterRules = rules;
        localStorage.setItem('combatFilterRules', JSON.stringify(rules));
    }

    loadFilterRules() {
        const savedRules = localStorage.getItem('combatFilterRules');
        if (savedRules) {
            const rules = JSON.parse(savedRules);
            rules.forEach(rule => {
                this.addFilterRule();
                const lastRule = document.querySelector('.zd_filter-list .zd_filter-rule:last-child');
                lastRule.querySelector('.zd_filter-type').value = rule.type;
                this.updateFilterValueOptions(
                    lastRule.querySelector('.zd_filter-type'),
                    lastRule.querySelector('.zd_filter-value')
                );
                lastRule.querySelector('.zd_filter-condition').value = rule.condition;
                lastRule.querySelector('.zd_filter-value').value = rule.value;
            });
        }
    }

    // 检查物品是否应该被过滤
    shouldFilterItem(item) {
        return this.filterRules.some(rule => {
            switch(rule.type) {
                case 'quality':
                    return this.checkQualityRule(item.quality, rule);
                case 'type':
                    return this.checkTypeRule(item.type, rule);
                case 'level':
                    return this.checkLevelRule(item.level || 0, rule);
                default:
                    return false;
            }
        });
    }

    checkQualityRule(itemQuality, rule) {
        const qualityRanks = {
            'NORMAL': 0,
            'RARE': 1,
            'EPIC': 2,
            'LEGENDARY': 3,
            'MYTHIC': 4
        };

        const itemRank = qualityRanks[itemQuality] || 0;
        const ruleRank = qualityRanks[rule.value] || 0;

        switch(rule.condition) {
            case 'equal':
                return itemRank === ruleRank;
            case 'lower':
                return itemRank < ruleRank;
            case 'higher':
                return itemRank > ruleRank;
            default:
                return false;
        }
    }

    checkTypeRule(itemType, rule) {
        return rule.condition === 'equal' && itemType === rule.value;
    }

    checkLevelRule(itemLevel, rule) {
        const ruleValue = parseInt(rule.value);
        switch(rule.condition) {
            case 'equal':
                return itemLevel === ruleValue;
            case 'lower':
                return itemLevel < ruleValue;
            case 'higher':
                return itemLevel > ruleValue;
            default:
                return false;
        }
    }
}

// 创建全局实例
const combatSettings = new CombatSettings(); 