class GameManager {
    constructor() {
        this.currentPlayer = null;
        this.gameLog = [];
        this.initialize();
    }

    initialize() {
        this.updatePlayerInfo();
        this.setupEventListeners();
    }

    // 更新玩家信息显示
    updatePlayerInfo() {
        const player = this.currentPlayer;
        if (!player) return;

        // 强制重新计算玩家属性
        player.stats = player.calculateStats();

        // 更新玩家名和职业图标
        document.querySelector('.player-name').textContent = player.name;
        document.querySelector('.player-avatar .class-icon').textContent = 
            Character.getClassIcon(player.class);

        // 更新等级
        document.getElementById('player-level').textContent = player.level;

        // 更新状态条
        this.updateStatBars();

        // 更新角色面板(如果打开的话)
        const characterPanel = document.getElementById('character-panel');
        if (characterPanel && characterPanel.style.display === 'block') {
            this.showCharacterPanel();
        }

        // 强制更新DOM
        requestAnimationFrame(() => {
            document.body.offsetHeight;
        });
    }

    // 更新状态条
    updateStatBars() {
        const player = this.currentPlayer;
        if (!player) return;

        // 强制重新计算玩家属性
        player.stats = player.calculateStats();
        const stats = player.stats;

        // 更新HP状态条
        const hpBar = document.querySelector('.hp-bar .bar-fill');
        const hpText = document.querySelector('.hp-bar .bar-text');
        if (hpBar && hpText) {
            const hpPercent = (stats.hp / stats.maxHp) * 100;
            hpBar.style.width = `${hpPercent}%`;
            hpText.textContent = `${Math.floor(stats.hp)}/${Math.floor(stats.maxHp)}`;

            // 强制重新渲染
            requestAnimationFrame(() => {
                hpBar.style.transition = 'none';
                hpBar.offsetHeight; // 触发重排
                hpBar.style.transition = '';
            });
        }

        // 更新MP状态条
        const mpBar = document.querySelector('.mp-bar .bar-fill');
        const mpText = document.querySelector('.mp-bar .bar-text');
        if (mpBar && mpText) {
            const mpPercent = (stats.mp / stats.maxMp) * 100;
            mpBar.style.width = `${mpPercent}%`;
            mpText.textContent = `${Math.floor(stats.mp)}/${Math.floor(stats.maxMp)}`;

            // 强制重新渲染
            requestAnimationFrame(() => {
                mpBar.style.transition = 'none';
                mpBar.offsetHeight; // 触发重排
                mpBar.style.transition = '';
            });
        }

        // 更新EXP状态条
        const expBar = document.querySelector('.exp-bar .bar-fill');
        const expText = document.querySelector('.exp-bar .bar-text');
        if (expBar && expText) {
            const maxExp = this.getExpForNextLevel(player.level);
            const expPercent = (player.exp / maxExp) * 100;
            expBar.style.width = `${expPercent}%`;
            expText.textContent = `${player.exp}/${maxExp}`;

            // 强制重新渲染
            requestAnimationFrame(() => {
                expBar.style.transition = 'none';
                expBar.offsetHeight; // 触发重排
                expBar.style.transition = '';
            });
        }

        // 强制更新DOM（添加检查）
        const gameMain = document.querySelector('.game-main');
        if (gameMain) {
            requestAnimationFrame(() => {
                gameMain.offsetHeight;
            });
        }
    }

    // 修改获取下一级所需经验值的方法
    getExpForNextLevel(level) {
        // 基础经验值
        const baseExp = 100;
        
        // 经验成长系数(可以调整这个值来控制难度)
        const growthFactor = 2.1;
        
        // 计算该等级需要的经验值: 基础经验 * (成长系数 ^ (等级-1))
        // 使用 Math.floor 确保得到整数
        const expNeeded = Math.floor(baseExp * Math.pow(growthFactor, level - 1));
        
        //console.log(`等级 ${level} 升级需要经验: ${expNeeded}`);
        
        return expNeeded;
    }

    // 设置当前玩家
    setPlayer(player) {
        try {
            // 检查是否是存档数据
            if (player.inventory && player.gold !== undefined) {
                // 如果是存档数据,直接使用
                this.currentPlayer = player;
            } else {
                // 如果是新角色,创建新的 Character 实例
                if (!player || !player.name || !player.class) {
                    throw new Error('无效的角色数据');
                }
                const character = new Character(player.name, player.class);
                character.level = player.level || 1;
                character.exp = player.exp || 0;
                
                // 如果有保存的属性,使用保存的属性,否则使用默认值
                if (player.attributes) {
                    character.attributes = player.attributes;
                }
                
                // 重新计算衍生属性
                character.stats = character.calculateStats();
                
                // 保存技能
                if (player.skills) {
                    character.skills = player.skills;
                }

                this.currentPlayer = character;
            }

            this.updatePlayerInfo();
            this.addGameLog(`欢迎 ${this.currentPlayer.name} 进入游戏！`);

            // 初始化队伍显示
            teamSystem.initializeDisplay();
            
            // 初始化地图系统
            if (mapSystem) {
                mapSystem.renderMap();
            }
            
            //console.log('Player loaded successfully:', this.currentPlayer);
        } catch (error) {
            console.error('Error setting player:', error);
            throw new Error('角色数据加载失败：' + error.message);
        }
    }

    // 添加游戏日志
    addGameLog(message) {
        const logContent = document.querySelector('.log-content');
        const logEntry = document.createElement('div');
        logEntry.textContent = `${new Date().toLocaleTimeString()} - ${message}`;
        logContent.appendChild(logEntry);
        logContent.scrollTop = logContent.scrollHeight;
    }

    // 设置事件监听
    setupEventListeners() {
        // 菜单按钮点击事件
        const menuButtons = document.querySelectorAll('.menu-btn');
        menuButtons.forEach(button => {
            button.addEventListener('click', () => {
                const page = button.dataset.page;
                this.openGamePage(page);
            });
        });
    }

    // 打开游戏子页面
    openGamePage(page) {
        switch(page) {
            case 'character':
                this.showCharacterPanel();
                break;
            case 'team':
                this.showTeamPanel();
                break;
            case 'skills':
                this.showSkillsPanel();
                break;
            case 'inventory':
                inventorySystem.showInventoryPanel();
                break;
            case 'settings':
                this.showSettingsPanel();
                break;
            case 'shop':
                shopSystem.showShop();
                break;
            case 'map':
                // 确保地图系统已初始化
                if (mapSystem) {
                    mapSystem.renderMap();
                }
                break;
        }
    }

    // 显示角色面板
    showCharacterPanel() {
        const panel = document.getElementById('character-panel');
        if (!panel || !this.currentPlayer) return;

        try {
            const player = this.currentPlayer;
            const stats = player.stats;

            // 更新基本信息
            const updateElement = (selector, value) => {
                const element = panel.querySelector(selector);
                if (element) {
                    element.textContent = value;
                }
            };

            // 更新基本信息
            updateElement('.class-icon', Character.getClassIcon(player.class));
            updateElement('.char-name', player.name);
            updateElement('.char-class', this.getClassName(player.class));
            updateElement('.level-num', player.level);

            // 更新状态条值
            updateElement('.char-hp-value', `${stats.hp}/${stats.maxHp}`);
            updateElement('.char-mp-value', `${stats.mp}/${stats.maxMp}`);
            updateElement('.char-exp-value', `${player.exp}/${this.getExpForNextLevel(player.level)}`);

            // 更新状态条进度
            const updateStatusBar = (type, current, max) => {
                const fill = panel.querySelector(`.char-${type}-fill`);
                const text = panel.querySelector(`.char-${type}-value`);
                if (fill && text) {
                    const percent = Math.floor((current / max) * 100);
                    fill.style.width = `${percent}%`;
                    
                    // 根据百分比添加不同的状态类
                    fill.className = `char-status-fill char-${type}-fill`;
                    if (percent === 100) fill.classList.add('full');
                    else if (percent >= 80) fill.classList.add('high');
                    else if (percent >= 50) fill.classList.add('medium');
                    else if (percent >= 20) fill.classList.add('low');
                    else fill.classList.add('critical');
                }
            };

            // 更新各个状态条
            updateStatusBar('hp', stats.hp, stats.maxHp);
            updateStatusBar('mp', stats.mp, stats.maxMp);
            updateStatusBar('exp', player.exp, this.getExpForNextLevel(player.level));

            // 更新属性显示
            const attributesContainer = panel.querySelector('.attributes-section');
            if (attributesContainer) {
                attributesContainer.innerHTML = `
                    <h4>角色属性</h4>
                    <div class="attributes-grid">
                        ${this.generateCharacterStatsHTML(player)}
                    </div>
                `;

                // 添加属性提示框事件
                const attributeRows = attributesContainer.querySelectorAll('.attribute-row');
                attributeRows.forEach(row => {
                    this.setupAttributeTooltip(row);
                });
            }

            // 显示面板
            panel.style.display = 'block';

            // 添加关闭按钮事件
            const closeBtn = panel.querySelector('.close-panel-btn');
            if (closeBtn) {
                closeBtn.onclick = () => {
                    panel.style.display = 'none';
                };
            }

        } catch (error) {
            console.error('Error updating character panel:', error);
            alert('更新角色信息失败！');
        }
    }

    // 添加计算装备加成方法
    calculateEquipmentBonus(attrName) {
        const player = this.currentPlayer;
        if (!player?.inventory?.equipped) return 0;

        let bonus = 0;
        Object.values(player.inventory.equipped).forEach(item => {
            if (item?.stats) {
                switch(attrName) {
                    case 'attack':
                        bonus += item.stats.attack || 0;
                        break;
                    case 'defense':
                        bonus += item.stats.defense || 0;
                        break;
                    case 'speed':
                        bonus += item.stats.speed || 0;
                        break;
                    case 'dodge':
                        bonus += item.stats.dodge || 0;
                        break;
                    case 'crit':
                        bonus += item.stats.critRate || 0;
                        break;
                    case 'crit-dmg':
                        bonus += item.stats.critDamage || 0;
                        break;
                    case 'drain':
                        bonus += item.stats.lifeSteal || 0;
                        break;
                    case 'hit':
                        bonus += item.stats.hit || 0;
                        break;
                    // 基础属性不受装备加成
                    case 'strength':
                    case 'agility':
                    case 'constitution':
                    case 'wisdom':
                        bonus = 0;
                        break;
                }
            }
        });
        return bonus;
    }

    // 添加生成属性提示框内容方法
    generateAttributeTooltip(attrInfo, equipBonus) {
        if (!attrInfo) return '';

        return `
            <div class="attribute-tooltip">
                <div class="tooltip-title">${attrInfo.title}</div>
                <div class="tooltip-description">${attrInfo.description}</div>
                <div class="tooltip-effects">
                    ${Object.entries(attrInfo.effects).map(([key, value]) => {
                        if (key === '当前加成') {
                            return `
                                <div class="effect-category">当前加成：</div>
                                ${Object.entries(value).map(([subEffect, subValue]) => `
                                    <div class="effect-item">
                                        <span class="effect-name">${subEffect}</span>
                                        <span class="effect-value">${subValue}</span>
                                    </div>
                                `).join('')}
                            `;
                        } else {
                            return `
                                <div class="effect-item">
                                    <span class="effect-name">${key}</span>
                                    <span class="effect-value">${value}</span>
                                </div>
                            `;
                        }
                    }).join('')}
                    ${equipBonus > 0 ? `
                        <div class="effect-category equipment-bonus">
                            装备加成：<span class="bonus-value">+${equipBonus}</span>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }

    // 添加属性单位获取方法
    getAttributeUnit(attrName) {
        const percentageAttrs = ['dodge', 'crit', 'crit-dmg', 'drain'];
        return percentageAttrs.includes(attrName) ? '%' : '';
    }

    // 获取职业名称
    getClassName(characterClass) {
        const classNames = {
            mage: '法师',
            warrior: '战士',
            monk: '武者',
            taoist: '道士'
        };
        return classNames[characterClass] || characterClass;
    }

    // 显示技能面板
    showSkillsPanel() {
        const panel = document.getElementById('skills-panel');
        if (!panel || !this.currentPlayer) return;

        try {
            // 更新技能点显示
            const skillPointsValue = panel.querySelector('.skill-points-value');
            if (skillPointsValue) {
                skillPointsValue.textContent = this.currentPlayer.skillPoints || 0;
            }

            // 获取当前业的技能配置
            const classSkills = SkillSystem.SKILLS_CONFIG[this.currentPlayer.class];
            if (!classSkills) {
                console.error('No skills found for class:', this.currentPlayer.class);
                return;
            }

            // 更新基础技能
            this.updateSkillGrid('basic-skills-grid', classSkills.basic, 'basic');
            
            // 更新级技能
            this.updateSkillGrid('intermediate-skills-grid', classSkills.intermediate, 'intermediate');
            
            // 更新高级技能
            this.updateSkillGrid('advanced-skills-grid', classSkills.advanced, 'advanced');
            
            // 更新被动技能
            this.updatePassiveSkill(classSkills.passive);

            // 显示面板
            panel.style.display = 'block';

            // 添加关闭按钮事件
            const closeBtn = panel.querySelector('.close-panel-btn');
            if (closeBtn) {
                closeBtn.onclick = () => {
                    panel.style.display = 'none';
                };
            }

        } catch (error) {
            console.error('Error updating skills panel:', error);
            alert('更新技能界面失败！');
        }
    }

    // 更新技能网格
    updateSkillGrid(gridId, skills, type) {
        const grid = document.getElementById(gridId);
        if (!grid || !skills) return;

        grid.innerHTML = '';
        skills.forEach(skillConfig => {
            // 在玩家技能列表中查找对应技能
            const playerSkill = this.currentPlayer.skills.find(s => s.id === skillConfig.id);
            const skillLevel = playerSkill?.level || 0;
            const maxLevel = skillSystem.MAX_LEVELS[type];
            
            // 检查是否可以升级
            const canUpgrade = this.canUpgradeSkill(type, skillLevel);
            const isMaxed = skillLevel >= maxLevel;
            
            const skillElement = document.createElement('div');
            skillElement.className = `skill-item ${!canUpgrade ? 'locked' : ''} ${isMaxed ? 'maxed' : ''}`;
            
            // 添加技能状态标签
            const statusLabel = !canUpgrade ? 
                (this.currentPlayer.level < skillSystem.LEVEL_REQUIREMENTS[type] ? '等级不足' : '技能点不足') : 
                (isMaxed ? '已满级' : '可升级');
            
            skillElement.innerHTML = `
                <div class="skill-icon">${skillConfig.icon}</div>
                <div class="skill-info">
                    <div class="skill-name">${skillConfig.name}</div>
                    <div class="skill-level">等级: ${skillLevel}/${maxLevel}</div>
                    <div class="skill-description">${skillConfig.description}</div>
                </div>
                <div class="skill-cost">技能点: ${skillSystem.getSkillCost(type)}</div>
                <div class="skill-status ${!canUpgrade ? 'locked' : isMaxed ? 'maxed' : 'available'}">
                    ${statusLabel}
                </div>
                <div class="skill-progress">
                    <div class="skill-progress-fill" style="width: ${(skillLevel / maxLevel) * 100}%"></div>
                </div>
                <div class="skill-tooltip">
                    <div class="tooltip-title">${skillConfig.name}</div>
                    <div class="tooltip-description">${skillConfig.description}</div>
                    <div class="tooltip-requirements">
                        <div>等级要求: ${skillSystem.LEVEL_REQUIREMENTS[type]}</div>
                        <div>技能点消耗: ${skillSystem.getSkillCost(type)}</div>
                        ${!canUpgrade ? 
                            `<div class="tooltip-warning">${statusLabel}</div>` : 
                            ''}
                    </div>
                    <div class="tooltip-effects">
                        ${this.getSkillEffectsHtml(skillConfig, skillLevel)}
                    </div>
                    ${!isMaxed ? 
                        `<div class="tooltip-next-level">下一级效果:</div>
                        ${this.getSkillEffectsHtml(skillConfig, skillLevel + 1)}` : 
                        '<div class="tooltip-maxed">已达到最高等级</div>'}
                </div>
            `;

            // 只有在可以升级时才添加点击事件
            if (canUpgrade && !isMaxed) {
                skillElement.onclick = () => {
                    if (this.currentPlayer.skillPoints <= 0) {
                        this.showFloatingTip('技能点不足！', 'error', skillElement);
                        return;
                    }
                    if (this.currentPlayer.level < skillSystem.LEVEL_REQUIREMENTS[type]) {
                        this.showFloatingTip(`需要等级 ${skillSystem.LEVEL_REQUIREMENTS[type]}！`, 'error', skillElement);
                        return;
                    }
                    this.upgradeSkill(skillConfig.id, type);
                };
            }

            // 添加技能提示框事件处理
            this.setupSkillTooltip(skillElement);

            grid.appendChild(skillElement);
        });
    }

    // 修改 canUpgradeSkill 方法
    canUpgradeSkill(type, currentLevel) {
        // 检查玩家等级是否满足要求
        if (this.currentPlayer.level < skillSystem.LEVEL_REQUIREMENTS[type]) {
            return false;
        }

        // 查是否有足够的技能点
        if (this.currentPlayer.skillPoints <= 0) {
            return false;
        }

        // 检查是否达到最大等级
        if (currentLevel >= skillSystem.MAX_LEVELS[type]) {
            return false;
        }

        return true;
    }

    // 更新被动技能
    updatePassiveSkill(passive) {
        const grid = document.getElementById('passive-skills-grid');
        if (!grid || !passive) return;

        const skillLevel = this.getSkillLevel(passive.id) || 0;
        const maxLevel = skillSystem.MAX_LEVELS.passive;
        const canUpgrade = this.currentPlayer.skillPoints > 0 && skillLevel < maxLevel;

        const skillElement = document.createElement('div');
        skillElement.className = `skill-item ${!canUpgrade ? 'locked' : ''} ${skillLevel >= maxLevel ? 'maxed' : ''}`;
        
        skillElement.innerHTML = `
            <div class="skill-icon">${passive.icon}</div>
            <div class="skill-info">
                <div class="skill-name">${passive.name}</div>
                <div class="skill-level">等级: ${skillLevel}/${maxLevel}</div>
                <div class="skill-description">${passive.description}</div>
            </div>
            <div class="skill-cost">技能点: 1</div>
            <div class="skill-progress">
                <div class="skill-progress-fill" style="width: ${(skillLevel / maxLevel) * 100}%"></div>
            </div>
            <div class="skill-tooltip">
                <div class="tooltip-title">${passive.name}</div>
                <div class="tooltip-description">${passive.description}</div>
                <div class="tooltip-effects">
                    ${this.getPassiveEffectsHtml(passive, skillLevel)}
                </div>
                ${skillLevel < maxLevel ? 
                    `<div class="tooltip-next-level">下一级效果:</div>
                    ${this.getPassiveEffectsHtml(passive, skillLevel + 1)}` : 
                    '<div class="tooltip-maxed">已达到最高等级</div>'
                }
            </div>
        `;

        // 添加鼠标移动事件监听器
        const tooltip = skillElement.querySelector('.skill-tooltip');
        if (tooltip) {
            skillElement.onmousemove = (e) => {
                // 获取鼠标位置
                const x = e.clientX;
                const y = e.clientY;
                
                // 获取tooltip尺寸
                const tooltipWidth = 250;
                const tooltipHeight = tooltip.offsetHeight;
                
                // 计算tooltip位置，默认显示在鼠标右侧
                let left = x + 15; // 鼠标右侧15px
                let top = y - tooltipHeight/2; // 垂直居中对齐
                
                // 检查是否会超出视窗右边界
                if (left + tooltipWidth > window.innerWidth) {
                    left = x - tooltipWidth - 15; // 如果会超出，则显示在鼠标左侧
                }
                
                // 检查是否会超出视窗上下边界
                if (top < 0) {
                    top = 5;
                } else if (top + tooltipHeight > window.innerHeight) {
                    top = window.innerHeight - tooltipHeight - 5;
                }
                
                // 设置tooltip位置
                tooltip.style.left = `${left}px`;
                tooltip.style.top = `${top}px`;
            };

            skillElement.onmouseenter = () => {
                // 确保tooltip在DOM树的最顶层
                if (tooltip.parentNode !== document.body) {
                    document.body.appendChild(tooltip);
                }
                tooltip.style.opacity = '1';
                tooltip.style.visibility = 'visible';
            };

            skillElement.onmouseleave = () => {
                tooltip.style.opacity = '0';
                tooltip.style.visibility = 'hidden';
                // 当鼠标离开时，将tooltip放回原位置
                if (tooltip.parentNode === document.body) {
                    skillElement.appendChild(tooltip);
                }
            };
        }

        // 只有在可以升级时才添加点击事件
        if (canUpgrade) {
            skillElement.onclick = () => {
                if (this.currentPlayer.skillPoints <= 0) {
                    this.showFloatingTip('技能点不足！', 'error', skillElement);
                    return;
                }
                this.upgradePassiveSkill(passive.id);
            };
        }

        grid.innerHTML = '';
        grid.appendChild(skillElement);
    }

    // 获取技能效果HTML
    getSkillEffectsHtml(skill, level) {
        if (!skill.effects || level <= 0) return '';

        let html = '<div class="effect-list">';
        for (const [key, values] of Object.entries(skill.effects)) {
            const value = values[level - 1];
            if (value !== undefined) {
                html += `
                    <div class="effect-item">
                        <span class="effect-name">${this.getEffectName(key)}</span>
                        <span class="effect-value">${this.formatEffectValue(key, value)}</span>
                    </div>
                `;
            }
        }
        html += '</div>';
        return html;
    }

    // 获取被动技能效果HTML
    getPassiveEffectsHtml(passive, level) {
        if (!passive.effects || level <= 0) return '';

        let html = '<div class="effect-list">';
        for (const [key, values] of Object.entries(passive.effects)) {
            const value = values[level - 1];
            if (value !== undefined) {
                html += `
                    <div class="effect-item">
                        <span class="effect-name">${this.getEffectName(key)}</span>
                        <span class="effect-value">+${value}%</span>
                    </div>
                `;
            }
        }
        html += '</div>';
        return html;
    }

    // 获取效果名称
    getEffectName(key) {
        const effectNames = {
            damage: '伤害',
            mpCost: '法力消耗',
            cooldown: '冷却时间',
            duration: '持续时间',
            radius: '影响范围',
            hits: '打击次数',
            slow: '减速效果',
            stunDuration: '眩晕时间',
            bounces: '弹射次数',
            // 被动技能效果
            dodgeBonus: '闪避加成',
            critBonus: '暴击加成',
            spellDamage: '法术伤害',
            manaRegen: '法力恢复',
            attackBonus: '攻击加成',
            hpBonus: '生命加成',
            skillEffect: '技能效果'
        };
        return effectNames[key] || key;
    }

    // 格式化效果值
    formatEffectValue(key, value) {
        switch(key) {
            case 'cooldown':
            case 'duration':
                return `${value}秒`;
            case 'radius':
                return `${value}米`;
            case 'slow':
            case 'damageBonus':
                return `${value}%`;
            default:
                return value;
        }
    }

    // 获取技能等级
    getSkillLevel(skillId) {
        // 在技能数组中查找对应技能并返回其等级
        const skill = this.currentPlayer?.skills?.find(s => s.id === skillId);
        return skill?.level || 0;
    }

    // 修改 upgradeSkill 方法
    upgradeSkill(skillId, type) {
        const player = this.currentPlayer;
        if (!player) return;

        // 检查技能点
        if (!player.skillPoints || player.skillPoints <= 0) {
            this.showFloatingTip('技能点不足！', 'error');
            return;
        }

        // 检查等级要求
        const levelReq = skillSystem.LEVEL_REQUIREMENTS[type];
        if (player.level < levelReq) {
            this.showFloatingTip(`需要等级 ${levelReq}！`, 'error');
            return;
        }

        try {
            // 扣除技能点
            player.skillPoints--;
            
            // 查找技能
            let skill = player.skills.find(s => s.id === skillId);
            
            if (!skill) {
                // 如果技能不存在，添加新技能
                const skillConfig = this.getSkillConfig(player.class, skillId);
                if (skillConfig) {
                    skill = {
                        id: skillId,
                        name: skillConfig.name,
                        icon: skillConfig.icon,
                        type: type,
                        level: 0
                    };
                    player.skills.push(skill);
                }
            }
            
            // 增加技能等级
            skill.level++;

            // 保存角色数据
            const saveResult = saveCharacter(player);
            if (!saveResult) {
                throw new Error('保存失败');
            }

            // 显示成功提示
            this.showFloatingTip('技能升级成功！', 'success');

            // 更新技能显示
            this.showSkillsPanel();
            
            /*console.log('技能升级后的玩家数据:', {
                技能点: player.skillPoints,
                技能列表: player.skills
            });*/
        } catch (error) {
            console.error('Error upgrading skill:', error);
            // 升级失败时回滚改动
            player.skillPoints++;
            const skill = player.skills.find(s => s.id === skillId);
            if (skill) {
                skill.level--;
            }
            this.showFloatingTip('技能升级失败！', 'error');
        }
    }

    // 添加获取技能配置的辅助方法
    getSkillConfig(characterClass, skillId) {
        const classSkills = SkillSystem.SKILLS_CONFIG[characterClass];
        if (!classSkills) return null;

        // 在所有类型的技能中查找
        for (const type of ['basic', 'intermediate', 'advanced']) {
            const skill = classSkills[type]?.find(s => s.id === skillId);
            if (skill) return skill;
        }

        // 检查被动技能
        if (classSkills.passive?.id === skillId) {
            return classSkills.passive;
        }

        return null;
    }

    // 升级被动技能
    upgradePassiveSkill(skillId) {
        const player = this.currentPlayer;
        if (!player) return;

        // 检查技能点
        if (!player.skillPoints || player.skillPoints <= 0) {
            this.showFloatingTip('技能点不足！', 'error');
            return;
        }

        // 获取当前技能等级
        const currentLevel = this.getSkillLevel(skillId);
        const maxLevel = skillSystem.MAX_LEVELS.passive;

        if (currentLevel >= maxLevel) {
            this.showFloatingTip('技能已达到最高等级！', 'warning');
            return;
        }

        try {
            // 扣除技能点并升级技能
            player.skillPoints--;
            if (!player.skills) player.skills = {};
            if (!player.skills[skillId]) {
                player.skills[skillId] = { level: 0 };
            }
            player.skills[skillId].level++;

            // 保存角色数据
            const saveResult = saveCharacter(player);
            if (!saveResult) {
                throw new Error('保存失败');
            }

            // 显示成功提示
            this.showFloatingTip('被动技能升级成功！', 'success');

            // 更新技能显示
            this.showSkillsPanel();
        } catch (error) {
            console.error('Error upgrading passive skill:', error);
            // 升级失败时回滚改动
            player.skillPoints++;
            if (player.skills && player.skills[skillId]) {
                player.skills[skillId].level--;
            }
            this.showFloatingTip('技能升级失败！', 'error');
        }
    }

    // 显示浮动提示
    showFloatingTip(message, type = 'info', element = null) {
        // 创建提示素
        const tip = document.createElement('div');
        tip.className = `floating-tip ${type}`;
        tip.textContent = message;

        // 果没有指定元素，就在屏幕中央显示
        if (!element) {
            tip.style.position = 'fixed';
            tip.style.left = '50%';
            tip.style.top = '50%';
            tip.style.transform = 'translate(-50%, -50%)';
        } else {
            // 获取元素位置
            const rect = element.getBoundingClientRect();
            tip.style.position = 'fixed';
            tip.style.left = `${rect.left + rect.width / 2}px`;
            tip.style.top = `${rect.top - 10}px`; // 在元素上方显示
            tip.style.transform = 'translate(-50%, -100%)';
        }

        document.body.appendChild(tip);

        // 添加动画效果
        requestAnimationFrame(() => {
            tip.style.opacity = '1';
            tip.style.transform = element ? 
                'translate(-50%, -150%)' : 
                'translate(-50%, -50%) translateY(-20px)';
        });

        // 一段时间后移除提示
        setTimeout(() => {
            tip.style.opacity = '0';
            setTimeout(() => {
                if (tip.parentNode) {
                    document.body.removeChild(tip);
                }
            }, 300);
        }, 2000);
    }

    // 添加显示背包面板的方法
    showInventoryPanel() {
        const panel = document.getElementById('inventory-panel');
        if (!panel || !this.currentPlayer) return;

        try {
            // 初始化玩家背包
            if (!this.currentPlayer.inventory) {
                this.currentPlayer.inventory = inventorySystem.initializeInventory(this.currentPlayer);
            }

            // 更新背包显示
            inventorySystem.updateInventoryDisplay(this.currentPlayer);

            // 显示面板
            panel.style.display = 'block';

            // 添加关闭按钮事件
            const closeBtn = panel.querySelector('.close-panel-btn');
            if (closeBtn) {
                closeBtn.onclick = () => {
                    panel.style.display = 'none';
                };
            }

        } catch (error) {
            console.error('Error showing inventory panel:', error);
            alert('打开背包失败！');
        }
    }

    // 在 GameManager 类中添加设置界面相关方法
    showSettingsPanel() {
        const panel = document.getElementById('settings-panel');
        if (!panel) return;

        try {
            // 显示面板
            panel.style.display = 'block';

            // 绑定按钮事件
            const saveBtn = panel.querySelector('.save-game');
            const loadBtn = panel.querySelector('.load-game');
            const mainBtn = panel.querySelector('.back-to-main');
            const contactBtn = panel.querySelector('.contact-author');
            const updateLogBtn = panel.querySelector('.update-log');
            const feedbackBtn = panel.querySelector('.feedback-btn');
            const closeBtn = panel.querySelector('.close-panel-btn');

            // 保存游戏
            if (saveBtn) {
                saveBtn.onclick = () => {
                    const saveResult = saveCharacter(this.currentPlayer);
                    if (saveResult) {
                        this.showFloatingTip('游戏保存成功！', 'success');
                    } else {
                        this.showFloatingTip('游戏保存失败！', 'error');
                    }
                };
            }

            // 读取存
            if (loadBtn) {
                loadBtn.onclick = () => {
                    showPage('load-game-page');
                    panel.style.display = 'none';
                };
            }

            // 返回首页
            if (mainBtn) {
                mainBtn.onclick = () => {
                    this.showConfirmDialog(
                        '确定要返回首页吗？未保存的进度将会丢失。',
                        () => {
                            showPage('start-page');
                            panel.style.display = 'none';
                        }
                    );
                };
            }

            // 联系作者
            if (contactBtn) {
                contactBtn.onclick = () => {
                    this.showContactDialog();
                };
            }

            // 更新日志按钮
            if (updateLogBtn) {
                updateLogBtn.onclick = () => {
                    updateLogSystem.showUpdateLog();
                };
            }

            // 反馈按钮
            if (feedbackBtn) {
                feedbackBtn.onclick = () => {
                    feedbackSystem.showFeedbackDialog();
                };
            }

            // 关闭按钮
            if (closeBtn) {
                closeBtn.onclick = () => {
                    panel.style.display = 'none';
                };
            }

        } catch (error) {
            console.error('Error showing settings panel:', error);
            alert('打开设置失败！');
        }
    }

    // 显示确认对话框
    showConfirmDialog(message, onConfirm) {
        const dialog = document.createElement('div');
        dialog.className = 'confirm-dialog';
        dialog.innerHTML = `
            <div class="confirm-dialog-content">
                ${message}
            </div>
            <div class="confirm-dialog-buttons">
                <button class="confirm-dialog-btn confirm-yes">确定</button>
                <button class="confirm-dialog-btn confirm-no">取消</button>
            </div>
        `;

        document.body.appendChild(dialog);
        requestAnimationFrame(() => dialog.classList.add('active'));

        const yesBtn = dialog.querySelector('.confirm-yes');
        const noBtn = dialog.querySelector('.confirm-no');

        yesBtn.onclick = () => {
            document.body.removeChild(dialog);
            onConfirm();
        };

        noBtn.onclick = () => {
            document.body.removeChild(dialog);
        };
    }

    // 添加显示队伍面板的方法
    showTeamPanel() {
        const panel = document.getElementById('team-panel');
        if (!panel || !this.currentPlayer) return;

        try {
            // 显示面板
            panel.style.display = 'block';

            // 更新队伍显示
            teamSystem.updateTeamDisplay();
            teamSystem.updateCompanionsDisplay();

            // 添加关闭按钮事件
            const closeBtn = panel.querySelector('.close-panel-btn');
            if (closeBtn) {
                closeBtn.onclick = () => {
                    panel.style.display = 'none';
                };
            }
        } catch (error) {
            console.error('Error showing team panel:', error);
            alert('打开队伍面板失败！');
        }
    }

    // 添加 updateAttribute 方法
    updateAttribute(name, value, element) {
        if (!element) return;

        // 获取装备加成
        const equipBonus = this.calculateEquipmentBonus(name);
        const totalValue = value + equipBonus;
        
        // 生成属性提示
        const attrInfo = getAttributeInfo(name, this.currentPlayer);
        if (!attrInfo) return;

        // 获取属性单位
        const unit = this.getAttributeUnit(name);

        // 更新属性行的内容
        element.dataset.attr = name;  // 添加属性标识
        element.innerHTML = `
            <span class="attr-label">${attrInfo.title}</span>
            <span class="attr-value ${equipBonus > 0 ? 'has-bonus' : ''}" data-type="${name}">
                ${totalValue}${unit}
                ${equipBonus > 0 ? `<span class="equip-bonus">(+${equipBonus})</span>` : ''}
            </span>
            <div class="attribute-tooltip">
                <div class="tooltip-title">${attrInfo.title}</div>
                <div class="tooltip-description">${attrInfo.description}</div>
                <div class="tooltip-effects">
                    ${Object.entries(attrInfo.effects).map(([key, value]) => {
                        if (key === '当前加成') {
                            return `
                                <div class="effect-category">当前加成：</div>
                                ${Object.entries(value).map(([subEffect, subValue]) => `
                                    <div class="effect-item">
                                        <span class="effect-name">${subEffect}</span>
                                        <span class="effect-value">${subValue}</span>
                                    </div>
                                `).join('')}
                            `;
                        } else {
                            return `
                                <div class="effect-item">
                                    <span class="effect-name">${key}</span>
                                    <span class="effect-value">${value}</span>
                                </div>
                            `;
                        }
                    }).join('')}
                    ${equipBonus > 0 ? `
                        <div class="effect-category equipment-bonus">
                            装备加成：<span class="bonus-value">+${equipBonus}</span>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        // 添加提示框事件
        this.setupAttributeTooltip(element);
    }

    // 添加 setupAttributeTooltip 方法
    setupAttributeTooltip(element) {
        const tooltip = element.querySelector('.attribute-tooltip');
        if (!tooltip) return;

        element.onmouseenter = () => {
            // 确保提示框在body下
            if (tooltip.parentNode !== document.body) {
                document.body.appendChild(tooltip);
            }
            tooltip.style.opacity = '1';
            tooltip.style.visibility = 'visible';
        };

        element.onmouseleave = () => {
            tooltip.style.opacity = '0';
            tooltip.style.visibility = 'hidden';
            // 当鼠标离开时，将提示框放回原位置
            if (tooltip.parentNode === document.body) {
                element.appendChild(tooltip);
            }
        };

        element.onmousemove = (e) => {
            const x = e.clientX;
            const y = e.clientY;
            
            // 获取提示框尺寸
            const tooltipRect = tooltip.getBoundingClientRect();
            
            // 计算位置，避免超出视窗
            let left = x + 15;
            let top = y;
            
            if (left + tooltipRect.width > window.innerWidth) {
                left = x - tooltipRect.width - 15;
            }
            
            if (top + tooltipRect.height > window.innerHeight) {
                top = window.innerHeight - tooltipRect.height;
            }
            
            tooltip.style.left = `${left}px`;
            tooltip.style.top = `${top}px`;
        };
    }

    // 修改 generateCharacterStatsHTML 方法
    generateCharacterStatsHTML(player) {
        const stats = player.stats;
        const attrs = player.attributes;
        
        // 属性配置
        const statsConfig = [
            { 
                name: '攻击力', 
                value: stats.attack || 0,
                type: 'attack',
                icon: '⚔️',
                description: '决定角色的基础伤害输出能力',
                effects: {
                    '基础攻击': '10',
                    '力道加成': '+1.5/点',
                    '装备加成': `+${this.calculateEquipmentBonus('attack')}`,
                    '总计': stats.attack
                }
            },
            { 
                name: '命中', 
                value: stats.hit || 0,
                type: 'hit',
                icon: '🎯',
                description: '提高攻击的命中率和技能效果',
                effects: {
                    '基础命中': '0',
                    '悟性加成': '+1.3/点',
                    '装备加成': `+${this.calculateEquipmentBonus('hit')}`,
                    '总计': stats.hit
                }
            },
            { 
                name: '防御力', 
                value: stats.defense || 0,
                type: 'defense',
                icon: '🛡️',
                description: '减少受到的物理伤害',
                effects: {
                    '基础防御': '10',
                    '根骨加成': '+1.2/点',
                    '装备加成': `+${this.calculateEquipmentBonus('defense')}`,
                    '总计': stats.defense
                }
            },
            { 
                name: '闪避', 
                value: stats.dodge || 0,
                type: 'dodge',
                icon: '💨',
                description: '提高躲避攻击的几率',
                effects: {
                    '基础闪避': '0%',
                    '身法加成': '+1.2%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('dodge')}%`,
                    '总计': `${stats.dodge}%`
                }
            },
            { 
                name: '暴击', 
                value: stats.crit || 0,
                type: 'crit',
                icon: '⚡',
                description: '提高造成暴击的几率',
                effects: {
                    '基础暴击': '0%',
                    '身法加成': '+0.5%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('crit')}%`,
                    '总计': `${stats.crit}%`
                }
            },
            { 
                name: '爆伤', 
                value: stats.critDmg || 150,
                type: 'crit-dmg',
                icon: '💥',
                description: '增加暴击时造成的额外伤害',
                effects: {
                    '基础爆伤': '150%',
                    '力道加成': '+0.8%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('crit-dmg')}%`,
                    '总计': `${stats.critDmg}%`
                }
            },
            { 
                name: '吸取', 
                value: stats.drain || 0,
                type: 'drain',
                icon: '💫',
                description: '将造成伤害的一部分转化为生命值',
                effects: {
                    '基础吸取': '0%',
                    '悟性加成': '+0.3%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('drain')}%`,
                    '总计': `${stats.drain}%`
                }
            },
            { 
                name: '力道', 
                value: attrs.strength.base,
                type: 'strength',
                icon: '💪',
                description: '影响角色的物理攻击能力暴击伤害',
                effects: {
                    '攻击力': '+1.5/点',
                    '暴击伤害': '+0.8%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('strength')}`,
                    '总计': `+${Math.floor(attrs.strength.base * 1.5)}`
                }
            },
            { 
                name: '身法', 
                value: attrs.agility.base,
                type: 'agility',
                icon: '🌪️',
                description: '影响角色的闪避能力和暴击率',
                effects: {
                    '闪避率': '+1.2%/点',
                    '暴击率': '+0.5%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('agility')}%`,
                    '总计': `+${Math.floor(attrs.agility.base * 1.2)}%`
                }
            },
            { 
                name: '根骨', 
                value: attrs.constitution.base,
                type: 'constitution',
                icon: '❤️',
                description: '影响角色的生命值和防御能力',
                effects: {
                    '生命值': '+5/点',
                    '防御力': '+1.2/点',
                    '装备加成': `+${this.calculateEquipmentBonus('constitution')}`,
                    '总计': `+${attrs.constitution.base * 5}`
                }
            },
            { 
                name: '悟性', 
                value: attrs.wisdom.base,
                type: 'wisdom',
                icon: '💡',
                description: '影响角色的法力值和法术效果',
                effects: {
                    '命中': '+1.3/点',
                    '法力值': '+0.3%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('wisdom')}`,
                    '总计': `+${attrs.wisdom.base * 1.3}`
                }
            },
            { 
                name: '速度', 
                value: stats.speed || 0,
                type: 'speed',
                icon: '⚡',
                description: '影响角色的攻击速度和移动速度',
                effects: {
                    '攻击速度': '+0.5%/点',
                    '移动速度': '+0.8%/点',
                    '装备加成': `+${this.calculateEquipmentBonus('speed')}%`,
                    '总计': `+${Math.floor(attrs.speed.base * 0.8)}%`
                }
            }
        ];

        return statsConfig.map(stat => {
            return `
                <div class="attribute-row" data-attr="${stat.type}">
                    <div class="attr-label">
                        <span class="attr-icon">${stat.icon}</span>
                        ${stat.name}
                    </div>
                    <div class="attr-value" data-type="${stat.type}">
                        ${stat.value}${stat.type.includes('crit') || stat.type === 'dodge' || stat.type === 'drain' ? '%' : ''}
                    </div>
                    <div class="attribute-tooltip">
                        <div class="tooltip-title">${stat.name}</div>
                        <div class="tooltip-description">${stat.description}</div>
                        <div class="tooltip-effects">
                            ${Object.entries(stat.effects).map(([key, value]) => `
                                <div class="effect-item">
                                    <span class="effect-name">${key}</span>
                                    <span class="effect-value">${value}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // 添加 setupSkillTooltip 方法
    setupSkillTooltip(skillElement) {
        const tooltip = skillElement.querySelector('.skill-tooltip');
        if (!tooltip) return;

        skillElement.onmouseenter = (e) => {
            // 确保提示框在body下
            if (tooltip.parentNode !== document.body) {
                document.body.appendChild(tooltip);
            }
            tooltip.style.opacity = '1';
            tooltip.style.visibility = 'visible';
        };

        skillElement.onmouseleave = () => {
            tooltip.style.opacity = '0';
            tooltip.style.visibility = 'hidden';
            // 当鼠标离开时，将提示框放回原位置
            if (tooltip.parentNode === document.body) {
                skillElement.appendChild(tooltip);
            }
        };

        skillElement.onmousemove = (e) => {
            const x = e.clientX;
            const y = e.clientY;
            
            // 获取提示框尺寸
            const tooltipRect = tooltip.getBoundingClientRect();
            
            // 计算位置，避免超出视窗
            let left = x + 15;
            let top = y;
            
            if (left + tooltipRect.width > window.innerWidth) {
                left = x - tooltipRect.width - 15;
            }
            
            if (top + tooltipRect.height > window.innerHeight) {
                top = window.innerHeight - tooltipRect.height;
            }
            
            tooltip.style.left = `${left}px`;
            tooltip.style.top = `${top}px`;
        };
    }

    // 在 GameManager 类中添加显示联系方式对话框的方法
    showContactDialog() {
        const dialog = document.createElement('div');
        dialog.className = 'contact-dialog';
        
        dialog.innerHTML = `
            <div class="contact-content">
                <div class="dialog-header">
                    <h3>联系作者</h3>
                    <button class="close-dialog-btn">×</button>
                </div>
                <div class="dialog-body">
                    <div class="contact-item">
                        <div class="contact-icon">👤</div>
                        <div class="contact-info">
                            <div class="contact-label">作者QQ</div>
                            <div class="contact-value">2583249588</div>
                            <button class="copy-btn" data-copy="2583249588">
                                <span class="btn-icon">📋</span>
                                复制
                            </button>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">👥</div>
                        <div class="contact-info">
                            <div class="contact-label">交流群</div>
                            <div class="contact-value">723436861</div>
                            <button class="copy-btn" data-copy="723436861">
                                <span class="btn-icon">📋</span>
                                复制
                            </button>
                        </div>
                    </div>
                    <div class="contact-note">
                        <span class="note-icon">💡</span>
                        <span class="note-text">需要"大千世界"游戏源码的加群 群文件下载</span>
                    </div>
                </div>
            </div>
        `;

        // 添加关闭按钮事件
        const closeBtn = dialog.querySelector('.close-dialog-btn');
        closeBtn.onclick = () => {
            dialog.classList.add('fade-out');
            setTimeout(() => {
                document.body.removeChild(dialog);
            }, 300);
        };

        // 添加复制按钮事件
        const copyBtns = dialog.querySelectorAll('.copy-btn');
        copyBtns.forEach(btn => {
            btn.onclick = () => {
                const textToCopy = btn.dataset.copy;
                navigator.clipboard.writeText(textToCopy).then(() => {
                    // 临时改变按钮文本显示复制成功
                    const originalText = btn.innerHTML;
                    btn.innerHTML = `
                        <span class="btn-icon">✅</span>
                        已复制
                    `;
                    btn.classList.add('copied');
                    
                    setTimeout(() => {
                        btn.innerHTML = originalText;
                        btn.classList.remove('copied');
                    }, 1500);
                });
            };
        });

        document.body.appendChild(dialog);
        // 添加淡入效果
        setTimeout(() => dialog.classList.add('show'), 10);
    }
}

// 当页面加载完成后初始化游戏管理器
let gameManager;
document.addEventListener('DOMContentLoaded', () => {
    gameManager = new GameManager();
}); 