class ShopSystem {
    constructor() {
        this.shopTabs = {
            EQUIPMENT: '装备商店',
            CONSUMABLE: '消耗品',
            SPECIAL: '特殊道具'
        };
        
        this.currentTab = 'EQUIPMENT';
        this.equipmentStock = [];
        this.refreshCost = 500;
        this.refreshCount = 0;
        
        // 添加商店装备品质配置
        this.SHOP_EQUIPMENT_CONFIG = {
            NORMAL: {
                chance: 40,    // 40%概率
                count: 3,      // 每次刷新生成3件
                priceMultiplier: 2.5
            },
            RARE: {
                chance: 30,    // 30%概率
                count: 2,      // 每次刷新生成2件
                priceMultiplier: 5
            },
            EPIC: {
                chance: 20,    // 20%概率
                count: 1,      // 每次刷新生成1件
                priceMultiplier: 12
            },
            LEGENDARY: {
                chance: 8,     // 8%概率
                count: 1,      // 每次刷新生成1件
                priceMultiplier: 25
            },
            MYTHIC: {
                chance: 2,     // 2%概率
                count: 1,      // 每次刷新生成1件
                priceMultiplier: 50
            }
        };
        
        // 初始化商店库存
        this.initializeStock();
    }

    // 初始化商店库存
    initializeStock() {
        this.refreshEquipmentStock();
    }

    // 刷新装备库存
    refreshEquipmentStock() {
        this.equipmentStock = [];
        const playerLevel = gameManager?.currentPlayer?.level || 1;
        
        // 遍历每个品质等级
        Object.entries(this.SHOP_EQUIPMENT_CONFIG).forEach(([quality, config]) => {
            // 根据概率决定是否生成该品质的装备
            if (Math.random() * 100 <= config.chance) {
                // 生成指定数量的装备
                for (let i = 0; i < config.count; i++) {
                    const type = Object.keys(itemGenerator.EQUIPMENT_TYPES)[
                        Math.floor(Math.random() * Object.keys(itemGenerator.EQUIPMENT_TYPES).length)
                    ];
                    
                    // 生成装备并调整价格
                    const equipment = itemGenerator.generateEquipment(type, playerLevel);
                    equipment.quality = quality;
                    equipment.price = Math.floor(equipment.price * config.priceMultiplier);
                    
                    this.equipmentStock.push(equipment);
                }
            }
        });

        // 如果生成的装备少于4件，补充普通装备
        while (this.equipmentStock.length < 4) {
            const type = Object.keys(itemGenerator.EQUIPMENT_TYPES)[
                Math.floor(Math.random() * Object.keys(itemGenerator.EQUIPMENT_TYPES).length)
            ];
            const equipment = itemGenerator.generateEquipment(type, playerLevel);
            equipment.quality = 'NORMAL';
            this.equipmentStock.push(equipment);
        }

        // 最多显示8件装备
        if (this.equipmentStock.length > 8) {
            this.equipmentStock = this.equipmentStock.slice(0, 8);
        }

        // 根据品质排序（从高到低）
        const qualityOrder = ['MYTHIC', 'LEGENDARY', 'EPIC', 'RARE', 'NORMAL'];
        this.equipmentStock.sort((a, b) => {
            return qualityOrder.indexOf(a.quality) - qualityOrder.indexOf(b.quality);
        });
    }

    // 获取当前刷新费用
    getCurrentRefreshCost() {
        return this.refreshCost;
    }

    // 显示商店界面
    showShop() {
        const dialog = document.createElement('div');
        dialog.className = 'shop-dialog';
        
        dialog.innerHTML = `
            <div class="shop-dialog-content">
                <div class="panel-header">
                    <h3>商店</h3>
                    <div class="shop-info">
                        <div class="player-gold">
                            <span class="gold-icon">💰</span>
                            <span class="gold-amount">${gameManager.currentPlayer.gold || 0}</span>
                        </div>
                        <button class="refresh-btn">
                            <span class="refresh-icon">🔄</span>
                            刷新商品 (${this.getCurrentRefreshCost()} 金币)
                        </button>
                    </div>
                    <button class="close-panel-btn">×</button>
                </div>
                <div class="panel-content">
                    <div class="shop-tabs">
                        ${Object.entries(this.shopTabs).map(([key, value]) => `
                            <button class="shop-tab ${this.currentTab === key ? 'active' : ''}" 
                                    data-tab="${key}">
                                ${value}
                            </button>
                        `).join('')}
                    </div>
                    <div class="shop-items">
                        ${this.generateShopItemsHTML()}
                    </div>
                </div>
            </div>
        `;

        // 添加事件监听
        this.setupEventListeners(dialog);

        document.body.appendChild(dialog);
    }

    // 生成商品列表HTML
    generateShopItemsHTML() {
        switch (this.currentTab) {
            case 'EQUIPMENT':
                return this.generateEquipmentHTML();
            case 'CONSUMABLE':
                return this.generateConsumablesHTML();
            case 'SPECIAL':
                return this.generateSpecialItemsHTML();
            default:
                return '';
        }
    }

    // 生成装备列表HTML
    generateEquipmentHTML() {
        return `
            <div class="equipment-list">
                ${this.equipmentStock.map(item => this.generateItemHTML(item)).join('')}
            </div>
        `;
    }

    // 生成消耗品列表HTML
    generateConsumablesHTML() {
        const consumables = Object.entries(itemGenerator.CONSUMABLE_CONFIG)
            .filter(([_, item]) => item.type === 'consumable' || item.type === 'buff');
        
        return `
            <div class="consumable-list">
                ${consumables.map(([key, item]) => `
                    <div class="shop-item" data-item-id="${key}">
                        <div class="shopitem-icon">${item.icon}</div>
                        <div class="item-info">
                            <div class="shopitem-name">
                                ${item.name}
                            </div>
                            <div class="item-description">${item.description}</div>
                            ${item.effect ? `
                                <div class="shopitem-effect">
                                    ${this.formatEffectDescription(item.effect)}
                                </div>
                            ` : ''}
                        </div>
                        <div class="item-price">
                            <span class="gold-icon">💰</span>
                            ${item.price}
                        </div>
                        <button class="buy-btn" data-item-id="${key}">
                            <span class="button-icon">🛒</span>
                            购买
                        </button>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // 生成特殊道具列表HTML
    generateSpecialItemsHTML() {
        const specialItems = Object.entries(itemGenerator.CONSUMABLE_CONFIG)
            .filter(([_, item]) => item.type === 'special');
        
        return `
            <div class="special-list">
                ${specialItems.map(([key, item]) => `
                    <div class="shop-item" data-item-id="${key}">
                        <div class="shopitem-icon">${item.icon}</div>
                        <div class="item-info">
                            <div class="shopitem-name">
                                ${item.name}
                            </div>
                            <div class="item-description">${item.description}</div>
                            ${item.effect ? `
                                <div class="shopitem-effect">
                                    ${this.formatEffectDescription(item.effect)}
                                </div>
                            ` : ''}
                        </div>
                        <div class="item-price">
                            <span class="gold-icon">💰</span>
                            ${item.price}
                        </div>
                        <button class="buy-btn" data-item-id="${key}">
                            <span class="button-icon">🛒</span>
                            购买
                        </button>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // 生成单个商品HTML
    generateItemHTML(item) {
        const qualityConfig = itemGenerator.QUALITY_CONFIG[item.quality] || {
            name: '',
            color: '#666'
        };

        return `
            <div class="shop-item quality-${item.quality.toLowerCase()}" data-item-id="${item.id}">
                <div class="shopitem-icon" style="color: ${qualityConfig.color}">${item.icon}</div>
                <div class="item-info">
                    <div class="shopitem-name" style="color: ${qualityConfig.color}">
                        ${item.name}
                        <span class="quality-badge" style="background: ${qualityConfig.color}">
                            ${qualityConfig.name}
                        </span>
                    </div>
                    ${item.stats ? `
                        <div class="item-stats">
                            ${Object.entries(item.stats).map(([key, value]) => `
                                <div class="shopstat-line">
                                    ${itemGenerator.STAT_POOL[key].name}: 
                                    +${value}${itemGenerator.STAT_POOL[key].format === 'percentage' ? '%' : ''}
                                </div>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
                <div class="item-price">
                    <span class="gold-icon">💰</span>
                    ${item.price}
                </div>
                <button class="buy-btn" data-item-id="${item.id}">
                    <span class="button-icon">🛒</span>
                    购买
                </button>
            </div>
        `;
    }

    // 设置事件监听
    setupEventListeners(dialog) {
        // 关闭按钮
        const closeBtn = dialog.querySelector('.close-panel-btn');
        if (closeBtn) {
            closeBtn.onclick = () => {
                document.body.removeChild(dialog);
            };
        }

        // 标签切换
        const tabs = dialog.querySelectorAll('.shop-tab');
        tabs.forEach(tab => {
            tab.onclick = () => {
                this.currentTab = tab.dataset.tab;
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                
                const itemsContainer = dialog.querySelector('.shop-items');
                itemsContainer.innerHTML = this.generateShopItemsHTML();
                
                // 重新绑定购买按钮事件
                this.setupBuyButtons(dialog);
            };
        });

        // 刷新按钮
        const refreshBtn = dialog.querySelector('.refresh-btn');
        if (refreshBtn) {
            refreshBtn.onclick = () => {
                const cost = this.refreshCost;
                if (gameManager.currentPlayer.gold >= cost) {
                    gameManager.currentPlayer.gold -= cost;
                    this.refreshEquipmentStock();
                    
                    // 更新显示
                    dialog.querySelector('.gold-amount').textContent = 
                        gameManager.currentPlayer.gold;
                    dialog.querySelector('.shop-items').innerHTML = 
                        this.generateShopItemsHTML();
                    
                    // 重新绑定购买按钮事件
                    this.setupBuyButtons(dialog);
                    
                    gameManager.showFloatingTip('刷新成功！', 'success');
                } else {
                    gameManager.showFloatingTip('金币不足！', 'error');
                }
            };
        }

        // 购买按钮
        this.setupBuyButtons(dialog);
    }

    // 设置购买按钮事件
    setupBuyButtons(dialog) {
        const buyButtons = dialog.querySelectorAll('.buy-btn');
        buyButtons.forEach(btn => {
            btn.onclick = () => {
                const itemId = btn.dataset.itemId;
                let item;

                if (this.currentTab === 'EQUIPMENT') {
                    item = this.equipmentStock.find(i => i.id === itemId);
                } else {
                    // 对于消耗品和特殊道具，创建新的物品对象
                    const config = itemGenerator.CONSUMABLE_CONFIG[itemId];
                    if (config) {
                        item = {
                            ...config,
                            id: `${itemId}_${Date.now()}`, // 添加唯一ID
                            stackable: true,
                            maxStack: 99
                        };
                    }
                }

                if (item && gameManager.currentPlayer.gold >= item.price) {
                    // 检查背包是否已满
                    if (!inventorySystem.addItem(gameManager.currentPlayer, item)) {
                        gameManager.showFloatingTip('背包已满！', 'error');
                        return;
                    }

                    // 扣除金币
                    gameManager.currentPlayer.gold -= item.price;
                    
                    // 更新金币显示
                    dialog.querySelector('.gold-amount').textContent = 
                        gameManager.currentPlayer.gold;
                    
                    gameManager.showFloatingTip('购买成功！', 'success');
                    
                    // 只有装备需要从库存中移除
                    if (this.currentTab === 'EQUIPMENT') {
                        this.equipmentStock = this.equipmentStock.filter(i => i.id !== itemId);
                        dialog.querySelector('.shop-items').innerHTML = 
                            this.generateShopItemsHTML();
                        this.setupBuyButtons(dialog);
                    }
                } else {
                    gameManager.showFloatingTip('金币不足！', 'error');
                }
            };
        });
    }

    // 添加效果描述格式化方法
    formatEffectDescription(effect) {
        switch(effect.type) {
            case 'heal':
                return `恢复 ${effect.value} 点生命值`;
            case 'restore_mp':
                return `恢复 ${effect.value} 点法力值`;
            case 'buff_attack':
                return `增加 ${effect.value}% 攻击力，持续 ${effect.duration} 秒`;
            case 'buff_defense':
                return `增加 ${effect.value}% 防御力，持续 ${effect.duration} 秒`;
            case 'buff_speed':
                return `增加 ${effect.value}% 速度，持续 ${effect.duration} 秒`;
            case 'resurrection':
                return `复活后恢复 ${effect.value}% 生命值`;
            case 'enhance':
                return `强化成功率: ${effect.successRate}%`;
            case 'reforge':
                return `重新随机装备属性`;
            default:
                return '';
        }
    }
}

// 创建全局商店系统实例
const shopSystem = new ShopSystem(); 