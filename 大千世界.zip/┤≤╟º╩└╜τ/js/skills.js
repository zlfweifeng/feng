// 技能系统
class SkillSystem {
    constructor() {
        // 技能点配置
        this.SKILL_COSTS = {
            basic: 1,      // 基础技能消耗
            intermediate: 3,// 中级技能消耗
            advanced: 5    // 高级技能消耗
        };

        // 等级要求
        this.LEVEL_REQUIREMENTS = {
            basic: 1,        // 基础技能要求
            intermediate: 20, // 中级技能要求
            advanced: 30     // 高级技能要求
        };

        // 技能最大等级
        this.MAX_LEVELS = {
            basic: 5,
            intermediate: 5,
            advanced: 5,
            passive: 10
        };
    }

    // 职业技能配置
    static SKILLS_CONFIG = {
        mage: {
            // 法师技能
            basic: [
                {
                    id: 'fireball',
                    name: '火球术',
                    icon: '🔥',
                    description: '发射一个火球造成魔法伤害',
                    type: 'basic',
                    damageType: 'magic',
                    effects: {
                        damage: [30, 45, 60, 75, 90],
                        mpCost: [15, 18, 21, 24, 27],
                        cooldown: [3, 2.8, 2.6, 2.4, 2]
                    }
                },
                {
                    id: 'frost_nova',
                    name: '霜冻新星',
                    icon: '❄️',
                    description: '释放冰霜能量，对周围敌人造成伤害并减速',
                    type: 'basic',
                    damageType: 'magic',
                    effects: {
                        damage: [25, 35, 45, 55, 65],
                        mpCost: [20, 25, 30, 35, 40],
                        cooldown: [5, 4.5, 4, 3.5, 3],
                        slow: [30, 35, 40, 45, 50] // 减速百分比
                    }
                },
                {
                    id: 'arcane_missile',
                    name: '奥术飞弹',
                    icon: '✨',
                    description: '发射多枚奥术飞弹追踪敌人',
                    type: 'basic',
                    damageType: 'magic',
                    effects: {
                        damage: [15, 20, 25, 30, 35],
                        hits: [3, 4, 5, 6, 7],
                        mpCost: [25, 30, 35, 40, 45],
                        cooldown: [6, 5.5, 5, 4.5, 4]
                    }
                }
            ],
            intermediate: [
                {
                    id: 'meteor',
                    name: '陨石术',
                    icon: '☄️',
                    description: '召唤陨石打击范围内的敌人',
                    type: 'intermediate',
                    damageType: 'magic',
                    effects: {
                        damage: [80, 120, 160, 200, 240],
                        mpCost: [40, 50, 60, 70, 80],
                        cooldown: [12, 11, 10, 9, 8],
                        radius: [3, 3.5, 4, 4.5, 5]
                    }
                },
                {
                    id: 'ice_prison',
                    name: '冰霜牢笼',
                    icon: '🧊',
                    description: '将敌人冰冻在原地，持续造成伤害',
                    type: 'intermediate',
                    damageType: 'magic',
                    effects: {
                        damage: [20, 30, 40, 50, 60], // 每秒伤害
                        duration: [3, 4, 5, 6, 7],
                        mpCost: [45, 55, 65, 75, 85],
                        cooldown: [15, 14, 13, 12, 11]
                    }
                },
                {
                    id: 'chain_lightning',
                    name: '连锁闪电',
                    icon: '⚡',
                    description: '释放闪电链击中多个敌人',
                    type: 'intermediate',
                    damageType: 'magic',
                    effects: {
                        damage: [50, 70, 90, 110, 130],
                        bounces: [3, 4, 5, 6, 7],
                        mpCost: [50, 60, 70, 80, 90],
                        cooldown: [10, 9, 8, 7, 6]
                    }
                }
            ],
            advanced: [
                {
                    id: 'time_stop',
                    name: '时间停止',
                    icon: '⌛',
                    description: '短暂停止时间，让敌人静止',
                    type: 'advanced',
                    damageType: 'magic',
                    effects: {
                        duration: [2, 2.5, 3, 3.5, 4],
                        mpCost: [100, 110, 120, 130, 140],
                        cooldown: [30, 28, 26, 24, 22]
                    }
                },
                {
                    id: 'arcane_explosion',
                    name: '奥术爆炸',
                    icon: '💥',
                    description: '引发强大的奥术爆炸',
                    type: 'advanced',
                    damageType: 'magic',
                    effects: {
                        damage: [200, 250, 300, 350, 400],
                        radius: [4, 5, 6, 7, 8],
                        mpCost: [80, 90, 100, 110, 120],
                        cooldown: [20, 18, 16, 14, 12]
                    }
                },
                {
                    id: 'elemental_storm',
                    name: '元素风暴',
                    icon: '🌪️',
                    description: '召唤元素风暴持续伤害范围内的敌人',
                    type: 'advanced',
                    damageType: 'magic',
                    effects: {
                        damage: [40, 50, 60, 70, 80], // 每秒伤害
                        duration: [5, 6, 7, 8, 9],
                        radius: [5, 6, 7, 8, 9],
                        mpCost: [90, 100, 110, 120, 130],
                        cooldown: [25, 23, 21, 19, 17]
                    }
                }
            ],
            passive: {
                id: 'arcane_mastery',
                name: '奥术精通',
                icon: '📚',
                description: '提高法术伤害和法力值恢复',
                type: 'passive',
                maxLevel: 10,
                effects: {
                    spellDamage: [5, 10, 15, 20, 25, 30, 35, 40, 45, 50], // 法术伤害提升百分比
                    manaRegen: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] // 每秒法力恢复
                }
            }
        },
        warrior: {
            // 战士技能
            basic: [
                {
                    id: 'slash',
                    name: '斩击',
                    icon: '⚔️',
                    description: '对敌人进行一次强力斩击',
                    type: 'basic',
                    damageType: 'physical',
                    effects: {
                        damage: [40, 55, 70, 85, 100],
                        mpCost: [10, 12, 14, 16, 18],
                        cooldown: [2, 1.8, 1.6, 1.4, 1.2]
                    }
                },
                {
                    id: 'whirlwind',
                    name: '旋风斩',
                    icon: '🌪️',
                    description: '旋转攻击周围的敌人',
                    type: 'basic',
                    damageType: 'physical',
                    effects: {
                        damage: [30, 40, 50, 60, 70],
                        radius: [2, 2.5, 3, 3.5, 4],
                        mpCost: [15, 20, 25, 30, 35],
                        cooldown: [5, 4.5, 4, 3.5, 3]
                    }
                },
                {
                    id: 'charge',
                    name: '冲锋',
                    icon: '⚡',
                    description: '向目标冲锋并造成伤害',
                    type: 'basic',
                    damageType: 'physical',
                    effects: {
                        damage: [25, 35, 45, 55, 65],
                        stunDuration: [0.5, 0.7, 0.9, 1.1, 1.3],
                        mpCost: [20, 25, 30, 35, 40],
                        cooldown: [8, 7, 6, 5, 4]
                    }
                }
            ],
            intermediate: [
                {
                    id: 'shield_bash',
                    name: '盾击',
                    icon: '🛡️',
                    description: '用盾牌猛击敌人，造成伤害和眩晕',
                    type: 'intermediate',
                    damageType: 'physical',
                    effects: {
                        damage: [60, 80, 100, 120, 140],
                        stunDuration: [1, 1.2, 1.4, 1.6, 1.8],
                        mpCost: [30, 35, 40, 45, 50],
                        cooldown: [10, 9, 8, 7, 6]
                    }
                },
                {
                    id: 'battle_cry',
                    name: '战吼',
                    icon: '📢',
                    description: '发出震慑敌人的怒吼，降低周围敌人的攻击力和防御力',
                    type: 'intermediate',
                    damageType: 'physical',
                    effects: {
                        debuff: [20, 25, 30, 35, 40], // 降低百分比
                        duration: [5, 6, 7, 8, 9],
                        radius: [4, 4.5, 5, 5.5, 6],
                        mpCost: [35, 40, 45, 50, 55],
                        cooldown: [15, 14, 13, 12, 11]
                    }
                },
                {
                    id: 'iron_skin',
                    name: '铁布衫',
                    icon: '🔰',
                    description: '临时提高防御力和伤害减免',
                    type: 'intermediate',
                    damageType: 'buff',
                    effects: {
                        defenseBonus: [30, 40, 50, 60, 70],
                        damageReduction: [15, 20, 25, 30, 35],
                        duration: [8, 9, 10, 11, 12],
                        mpCost: [40, 45, 50, 55, 60],
                        cooldown: [20, 18, 16, 14, 12]
                    }
                }
            ],
            advanced: [
                {
                    id: 'execute',
                    name: '斩杀',
                    icon: '💀',
                    description: '对生命值低于一定百分比的敌人造成巨额伤害',
                    type: 'advanced',
                    damageType: 'physical',
                    effects: {
                        damage: [150, 200, 250, 300, 350],
                        executeThreshold: [20, 25, 30, 35, 40], // 斩杀线
                        mpCost: [60, 70, 80, 90, 100],
                        cooldown: [15, 14, 13, 12, 11]
                    }
                },
                {
                    id: 'avatar',
                    name: '战神附体',
                    icon: '👹',
                    description: '短时间内大幅提升所有属性',
                    type: 'advanced',
                    damageType: 'buff',
                    effects: {
                        attributeBonus: [30, 40, 50, 60, 70],
                        duration: [10, 12, 14, 16, 18],
                        mpCost: [80, 90, 100, 110, 120],
                        cooldown: [30, 28, 26, 24, 22]
                    }
                },
                {
                    id: 'earthquake',
                    name: '地裂斩',
                    icon: '🌋',
                    description: '对地面造成强力一击，产生震荡波伤害范围内的敌人',
                    type: 'advanced',
                    damageType: 'physical',
                    effects: {
                        damage: [120, 160, 200, 240, 280],
                        radius: [5, 6, 7, 8, 9],
                        stunDuration: [1, 1.2, 1.4, 1.6, 1.8],
                        mpCost: [70, 80, 90, 100, 110],
                        cooldown: [25, 23, 21, 19, 17]
                    }
                }
            ],
            passive: {
                id: 'warriors_spirit',
                name: '战士之魂',
                icon: '⚔️',
                description: '提高物理攻击力和生命值',
                type: 'passive',
                maxLevel: 10,
                effects: {
                    attackBonus: [5, 10, 15, 20, 25, 30, 35, 40, 45, 50], // 攻击力提升百分比
                    hpBonus: [3, 6, 9, 12, 15, 18, 21, 24, 27, 30] // 生命值提升百分比
                }
            }
        },
        monk: {
            // 武者技能
            basic: [
                {
                    id: 'rapid_strike',
                    name: '迅捷拳',
                    icon: '👊',
                    description: '快速连续打出数拳',
                    type: 'basic',
                    damageType: 'physical',
                    effects: {
                        damage: [15, 20, 25, 30, 35],
                        hits: [3, 4, 4, 5, 5],
                        mpCost: [12, 15, 18, 21, 24],
                        cooldown: [3, 2.8, 2.6, 2.4, 2.2]
                    }
                },
                {
                    id: 'palm_strike',
                    name: '震山掌',
                    icon: '🖐️',
                    description: '蓄力一掌，击退敌人并造成伤害',
                    type: 'basic',
                    damageType: 'physical',
                    effects: {
                        damage: [35, 45, 55, 65, 75],
                        knockback: [3, 3.5, 4, 4.5, 5],
                        mpCost: [15, 18, 21, 24, 27],
                        cooldown: [5, 4.5, 4, 3.5, 3]
                    }
                },
                {
                    id: 'flying_kick',
                    name: '飞踢',
                    icon: '🦶',
                    description: '快速冲向目标进行飞踢',
                    type: 'basic',
                    damageType: 'physical',
                    effects: {
                        damage: [40, 50, 60, 70, 80],
                        range: [4, 4.5, 5, 5.5, 6],
                        mpCost: [18, 21, 24, 27, 30],
                        cooldown: [6, 5.5, 5, 4.5, 4]
                    }
                }
            ],
            intermediate: [
                {
                    id: 'iron_body',
                    name: '金钟罩',
                    icon: '🔮',
                    description: '运功护体，减少受到的伤害',
                    type: 'intermediate',
                    damageType: 'buff',
                    effects: {
                        damageReduction: [20, 25, 30, 35, 40],
                        duration: [8, 9, 10, 11, 12],
                        mpCost: [30, 35, 40, 45, 50],
                        cooldown: [15, 14, 13, 12, 11]
                    }
                },
                {
                    id: 'chi_burst',
                    name: '气功波',
                    icon: '💫',
                    description: '释放强大的气功波',
                    type: 'intermediate',
                    damageType: 'energy',
                    effects: {
                        damage: [70, 90, 110, 130, 150],
                        range: [6, 7, 8, 9, 10],
                        mpCost: [40, 45, 50, 55, 60],
                        cooldown: [12, 11, 10, 9, 8]
                    }
                },
                {
                    id: 'shadow_step',
                    name: '瞬步',
                    icon: '👣',
                    description: '快速移动到目标位置并提高闪避率',
                    type: 'intermediate',
                    damageType: 'movement',
                    effects: {
                        range: [5, 6, 7, 8, 9],
                        dodgeBonus: [20, 25, 30, 35, 40],
                        duration: [4, 5, 6, 7, 8],
                        mpCost: [35, 40, 45, 50, 55],
                        cooldown: [10, 9, 8, 7, 6]
                    }
                }
            ],
            advanced: [
                {
                    id: 'hundred_fists',
                    name: '百裂拳',
                    icon: '🥊',
                    description: '短时间内快速打出大量攻击',
                    type: 'advanced',
                    damageType: 'physical',
                    effects: {
                        damage: [20, 25, 30, 35, 40],
                        hits: [8, 9, 10, 11, 12],
                        duration: [5, 6, 7, 8, 9],
                        mpCost: [70, 80, 90, 100, 110],
                        cooldown: [20, 18, 16, 14, 12]
                    }
                },
                {
                    id: 'dragon_kick',
                    name: '升龙击',
                    icon: '🐉',
                    description: '强力的上升踢击，造成巨大伤害',
                    type: 'advanced',
                    damageType: 'physical',
                    effects: {
                        damage: [150, 180, 210, 240, 270],
                        knockup: [1, 1.2, 1.4, 1.6, 1.8],
                        mpCost: [60, 70, 80, 90, 100],
                        cooldown: [15, 14, 13, 12, 11]
                    }
                },
                {
                    id: 'spirit_bomb',
                    name: '元气弹',
                    icon: '⭕',
                    description: '聚集强大的气功形成破坏性的能量球',
                    type: 'advanced',
                    damageType: 'energy',
                    effects: {
                        damage: [200, 250, 300, 350, 400],
                        chargeTime: [2, 1.8, 1.6, 1.4, 1.2],
                        radius: [4, 5, 6, 7, 8],
                        mpCost: [80, 90, 100, 110, 120],
                        cooldown: [25, 23, 21, 19, 17]
                    }
                }
            ],
            passive: {
                id: 'inner_peace',
                name: '心如止水',
                icon: '☯️',
                description: '提高闪避率和暴击率',
                type: 'passive',
                maxLevel: 10,
                effects: {
                    dodgeBonus: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20],
                    critBonus: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                }
            }
        },
        taoist: {
            // 道士技能
            basic: [
                {
                    id: 'thunder_strike',
                    name: '雷击术',
                    icon: '⚡',
                    description: '召唤雷电攻击敌人',
                    type: 'basic',
                    damageType: 'magic',
                    effects: {
                        damage: [35, 45, 55, 65, 75],
                        stunChance: [20, 25, 30, 35, 40],
                        mpCost: [15, 18, 21, 24, 27],
                        cooldown: [3, 2.8, 2.6, 2.4, 2.2]
                    }
                },
                {
                    id: 'healing_talisman',
                    name: '治疗符',
                    icon: '📜',
                    description: '使用符咒恢复生命值',
                    type: 'basic',
                    damageType: 'heal',
                    effects: {
                        healing: [30, 40, 50, 60, 70],
                        mpCost: [20, 25, 30, 35, 40],
                        cooldown: [6, 5.5, 5, 4.5, 4]
                    }
                },
                {
                    id: 'poison_cloud',
                    name: '毒云术',
                    icon: '☁️',
                    description: '释放毒云持续伤害敌人',
                    type: 'basic',
                    damageType: 'poison',
                    effects: {
                        damage: [10, 15, 20, 25, 30],
                        duration: [4, 5, 6, 7, 8],
                        radius: [3, 3.5, 4, 4.5, 5],
                        mpCost: [25, 30, 35, 40, 45],
                        cooldown: [8, 7.5, 7, 6.5, 6]
                    }
                }
            ],
            intermediate: [
                {
                    id: 'spirit_summon',
                    name: '召唤灵宠',
                    icon: '🐲',
                    description: '召唤灵宠协助战斗',
                    type: 'intermediate',
                    damageType: 'summon',
                    effects: {
                        petDamage: [25, 35, 45, 55, 65],
                        petHealth: [100, 150, 200, 250, 300],
                        duration: [20, 25, 30, 35, 40],
                        mpCost: [45, 50, 55, 60, 65],
                        cooldown: [25, 23, 21, 19, 17]
                    }
                },
                {
                    id: 'five_elements',
                    name: '五行阵',
                    icon: '🔮',
                    description: '布置五行阵法，增强己方，削弱敌方',
                    type: 'intermediate',
                    damageType: 'buff',
                    effects: {
                        buffStrength: [20, 25, 30, 35, 40],
                        debuffStrength: [15, 20, 25, 30, 35],
                        duration: [10, 12, 14, 16, 18],
                        mpCost: [50, 55, 60, 65, 70],
                        cooldown: [20, 18, 16, 14, 12]
                    }
                },
                {
                    id: 'soul_drain',
                    name: '吸魂术',
                    icon: '👻',
                    description: '吸取敌人生命值和法力值',
                    type: 'intermediate',
                    damageType: 'dark',
                    effects: {
                        damage: [40, 50, 60, 70, 80],
                        lifeSteal: [50, 60, 70, 80, 90],
                        manaSteal: [30, 35, 40, 45, 50],
                        mpCost: [40, 45, 50, 55, 60],
                        cooldown: [15, 14, 13, 12, 11]
                    }
                }
            ],
            advanced: [
                {
                    id: 'celestial_seal',
                    name: '天罡封印',
                    icon: '🔯',
                    description: '封印敌人的能力并造成持续伤害',
                    type: 'advanced',
                    damageType: 'seal',
                    effects: {
                        damage: [30, 40, 50, 60, 70],
                        duration: [5, 6, 7, 8, 9],
                        silenceDuration: [3, 3.5, 4, 4.5, 5],
                        mpCost: [70, 80, 90, 100, 110],
                        cooldown: [25, 23, 21, 19, 17]
                    }
                },
                {
                    id: 'reincarnation',
                    name: '还魂术',
                    icon: '🕯️',
                    description: '复活倒下的队友或获得一次复活机会',
                    type: 'advanced',
                    damageType: 'heal',
                    effects: {
                        healthPercent: [30, 40, 50, 60, 70],
                        duration: [300, 360, 420, 480, 540],
                        mpCost: [100, 110, 120, 130, 140],
                        cooldown: [60, 55, 50, 45, 40]
                    }
                },
                {
                    id: 'divine_punishment',
                    name: '天罚',
                    icon: '☄️',
                    description: '召唤天雷打击范围内的所有敌人',
                    type: 'advanced',
                    damageType: 'magic',
                    effects: {
                        damage: [150, 200, 250, 300, 350],
                        strikes: [3, 4, 5, 6, 7],
                        radius: [5, 6, 7, 8, 9],
                        mpCost: [90, 100, 110, 120, 130],
                        cooldown: [30, 28, 26, 24, 22]
                    }
                }
            ],
            passive: {
                id: 'spiritual_enlightenment',
                name: '道法自然',
                icon: '☯️',
                description: '提高法力值恢复和技能效果',
                type: 'passive',
                maxLevel: 10,
                effects: {
                    manaRegen: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20],
                    skillEffect: [3, 6, 9, 12, 15, 18, 21, 24, 27, 30]
                }
            }
        }
    };

    // 获取技能升级所需技能点
    getSkillCost(skillType) {
        return this.SKILL_COSTS[skillType];
    }

    // 检查技能是否可以升级
    canUpgradeSkill(character, skillId, currentLevel) {
        const skillConfig = this.getSkillConfig(character.class, skillId);
        if (!skillConfig) return false;

        // 检查技能点
        const requiredPoints = this.getSkillCost(skillConfig.type);
        if (character.skillPoints < requiredPoints) return false;

        // 检查等级要求
        const levelReq = this.LEVEL_REQUIREMENTS[skillConfig.type];
        if (character.level < levelReq) return false;

        // 检查是否达到最大等级
        const maxLevel = this.MAX_LEVELS[skillConfig.type];
        if (currentLevel >= maxLevel) return false;

        return true;
    }

    // 获取技能配置
    getSkillConfig(characterClass, skillId) {
        const classSkills = SkillSystem.SKILLS_CONFIG[characterClass];
        if (!classSkills) return null;

        // 在所有类型的技能中查找
        for (const type of ['basic', 'intermediate', 'advanced']) {
            const skill = classSkills[type]?.find(s => s.id === skillId);
            if (skill) return skill;
        }

        // 检查被动技能
        if (classSkills.passive?.id === skillId) {
            return classSkills.passive;
        }

        return null;
    }

    // 获取技能效果
    getSkillEffects(skillConfig, level) {
        if (!skillConfig || !skillConfig.effects) return null;

        const effects = {};
        for (const [key, values] of Object.entries(skillConfig.effects)) {
            effects[key] = values[level - 1];
        }
        return effects;
    }
}

// 导出技能系统
const skillSystem = new SkillSystem();
window.skillSystem = skillSystem;  // 确保全局可访问
window.SkillSystem = SkillSystem; // 导出类定义 