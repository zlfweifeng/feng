class SkillEffectSystem {
    constructor() {
        // 技能效果配置
        this.SKILL_EFFECTS = {
            // 基础技能
            basic_attack: {
                name: '普通攻击',
                type: 'physical',
                execute: (caster, target) => {
                    // 确保攻击力和防御力为正数
                    const attackValue = Math.abs(caster.stats.attack || 0);
                    const defenseValue = Math.abs(target.stats.defense || 0);
                    
                    // 计算伤害，确保最小伤害为1
                    const damage = Math.max(1, attackValue - defenseValue);
                    
                    console.log('普通攻击伤害计算:', {
                        攻击者: caster.name,
                        攻击力: attackValue,
                        防御者: target.name,
                        防御力: defenseValue,
                        计算伤害: damage
                    });

                    return {
                        damage: damage,
                        effects: []
                    };
                }
            },

            // 战士技能
            heavy_strike: {
                name: '重击',
                type: 'physical',
                mpCost: 20,
                cooldown: 3,
                execute: (caster, target) => {
                    const damage = (caster.stats.attack * 1.5) - target.stats.defense;
                    return {
                        damage: damage,
                        effects: [{
                            type: 'stun',
                            duration: 1,
                            chance: 0.3
                        }]
                    };
                }
            },
            shield_wall: {
                name: '盾墙',
                type: 'buff',
                mpCost: 30,
                execute: (caster) => {
                    return {
                        effects: [{
                            type: 'buff',
                            stat: 'defense',
                            value: caster.stats.defense * 0.5,
                            duration: 3
                        }]
                    };
                }
            },
            battle_cry: {
                name: '战吼',
                type: 'debuff',
                mpCost: 25,
                execute: (caster, target) => {
                    return {
                        effects: [{
                            type: 'debuff',
                            stat: 'attack',
                            value: -target.stats.attack * 0.2,
                            duration: 2
                        }]
                    };
                }
            },
            whirlwind: {
                name: '旋风斩',
                type: 'physical',
                mpCost: 35,
                cooldown: 5,
                execute: (caster, targets) => {
                    return {
                        damage: caster.stats.attack * 0.8,
                        aoe: true
                    };
                }
            },

            // 法师技能
            fireball: {
                name: '火球术',
                type: 'magical',
                mpCost: 15,
                cooldown: 3,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const baseDamage = attackPower * 2;
                    const dotDamage = attackPower * 0.3;

                    return {
                        damage: Math.floor(baseDamage),
                        effects: [{
                            type: 'dot',
                            damage: Math.floor(dotDamage),
                            duration: 3,
                            name: '燃烧'
                        }]
                    };
                }
            },
            frost_nova: {
                name: '霜冻新星',
                type: 'magical',
                mpCost: 20,
                cooldown: 5,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.5;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        effects: [{
                            type: 'slow',
                            value: 0.3,
                            duration: 3,
                            name: '减速'
                        }]
                    };
                }
            },
            arcane_missile: {
                name: '奥术飞弹',
                type: 'magical',
                mpCost: 25,
                cooldown: 6,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damagePerHit = attackPower * 0.6;
                    
                    return {
                        damage: Math.floor(damagePerHit),
                        hitCount: 3
                    };
                }
            },
            mana_shield: {
                name: '法力护盾',
                type: 'buff',
                mpCost: 40,
                execute: (caster) => {
                    return {
                        effects: [{
                            type: 'shield',
                            value: caster.stats.magic * 2,
                            duration: 3
                        }]
                    };
                }
            },
            meteor: {
                name: '陨石术',
                type: 'magical',
                mpCost: 40,
                cooldown: 12,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 3;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 5,
                        effects: [{
                            type: 'stun',
                            duration: 1.5,
                            name: '击晕'
                        }]
                    };
                }
            },
            ice_prison: {
                name: '冰霜牢笼',
                type: 'magical',
                mpCost: 45,
                cooldown: 15,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 0.8;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'freeze',
                            duration: 3,
                            damage: Math.floor(damage * 0.3),
                            name: '冰冻'
                        }]
                    };
                }
            },

            // 武僧技能
            palm_strike: {
                name: '掌击',
                type: 'physical',
                mpCost: 15,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.2;
                    return {
                        damage: damage,
                        effects: [{
                            type: 'stun',
                            duration: 1,
                            chance: 0.2
                        }]
                    };
                }
            },
            flying_kick: {
                name: '飞踢',
                type: 'physical',
                mpCost: 25,
                execute: (caster, target) => {
                    return {
                        damage: caster.stats.attack * 1.8
                    };
                }
            },
            chi_burst: {
                name: '真气爆发',
                type: 'magical',
                mpCost: 40,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    return {
                        damage: Math.floor(attackPower * 1.8),
                        aoe: true
                    };
                }
            },
            meditation: {
                name: '冥想',
                type: 'heal',
                mpCost: 30,
                execute: (caster) => {
                    return {
                        heal: caster.stats.magic * 1.5,
                        mpRestore: caster.stats.magic
                    };
                }
            },
            dragon_punch: {
                name: '升龙拳',
                type: 'physical',
                mpCost: 45,
                execute: (caster, target) => {
                    return {
                        damage: caster.stats.attack * 2.2,
                        effects: [{
                            type: 'knockup',
                            duration: 1
                        }]
                    };
                }
            },

            // 道士技能
            thunder_strike: {
                name: '雷击术',
                type: 'magical',
                mpCost: 35,
                cooldown: 8,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = (attackPower * 0.5 + magicPower * 1.5);
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'paralyze',
                            duration: 1.5,
                            chance: 0.4,
                            name: '麻痹'
                        }]
                    };
                }
            },
            healing_talisman: {
                name: '治疗符',
                type: 'heal',
                mpCost: 30,
                cooldown: 6,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const healing = magicPower * 2;
                    
                    return {
                        heal: Math.floor(healing),
                        effects: [{
                            type: 'regen',
                            healing: Math.floor(healing * 0.2),
                            duration: 3,
                            name: '回春'
                        }]
                    };
                }
            },
            poison_cloud: {
                name: '毒云术',
                type: 'poison',
                mpCost: 25,
                cooldown: 8,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 0.8;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 4,
                        effects: [{
                            type: 'poison',
                            damage: Math.floor(damage * 0.3),
                            duration: 4,
                            name: '中毒'
                        }]
                    };
                }
            },
            spirit_summon: {
                name: '召唤灵宠',
                type: 'summon',
                mpCost: 45,
                cooldown: 25,
                execute: (caster) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    
                    return {
                        summon: {
                            name: '灵宠',
                            duration: 20,
                            stats: {
                                hp: magicPower * 5,
                                attack: magicPower * 0.8,
                                defense: magicPower * 0.5,
                                magic: magicPower * 0.3
                            },
                            skills: ['basic_attack', 'spirit_strike']
                        }
                    };
                }
            },
            five_elements: {
                name: '五行阵',
                type: 'formation',
                mpCost: 50,
                cooldown: 20,
                execute: (caster) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    
                    return {
                        formation: {
                            radius: 5,
                            duration: 10,
                            effects: [
                                {
                                    type: 'buff',
                                    target: 'ally',
                                    stats: {
                                        attack: magicPower * 0.3,
                                        defense: magicPower * 0.3,
                                        magic: magicPower * 0.3
                                    },
                                    name: '五行加持'
                                },
                                {
                                    type: 'debuff',
                                    target: 'enemy',
                                    stats: {
                                        attack: -magicPower * 0.2,
                                        defense: -magicPower * 0.2,
                                        magic: -magicPower * 0.2
                                    },
                                    name: '五行侵蚀'
                                }
                            ]
                        }
                    };
                }
            },
            soul_drain: {
                name: '吸魂术',
                type: 'dark',
                mpCost: 40,
                cooldown: 15,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 2;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [
                            {
                                type: 'drain',
                                value: Math.floor(damage * 0.5),
                                drainType: 'hp',
                                name: '生命吸取'
                            },
                            {
                                type: 'drain',
                                value: Math.floor(magicPower * 0.3),
                                drainType: 'mp',
                                name: '法力吸取'
                            }
                        ]
                    };
                }
            },
            celestial_seal: {
                name: '天罡封印',
                type: 'seal',
                mpCost: 70,
                cooldown: 25,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 1.5;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [
                            {
                                type: 'seal',
                                duration: 5,
                                effects: {
                                    silence: true,
                                    disarm: true
                                },
                                name: '封印'
                            },
                            {
                                type: 'dot',
                                damage: Math.floor(damage * 0.2),
                                duration: 5,
                                name: '封印灼烧'
                            }
                        ]
                    };
                }
            },
            reincarnation: {
                name: '还魂术',
                type: 'resurrection',
                mpCost: 100,
                cooldown: 60,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    
                    return {
                        resurrection: {
                            healthPercent: 0.5,
                            effects: [{
                                type: 'buff',
                                stats: {
                                    defense: magicPower * 0.5
                                },
                                duration: 5,
                                name: '复活保'
                            }]
                        }
                    };
                }
            },
            divine_punishment: {
                name: '天罚',
                type: 'divine',
                mpCost: 90,
                cooldown: 30,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 3;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 6,
                        strikes: 5,
                        effects: [
                            {
                                type: 'stun',
                                duration: 0.5,
                                name: '天罚震慑'
                            },
                            {
                                type: 'dot',
                                damage: Math.floor(damage * 0.15),
                                duration: 3,
                                name: '天罚灼烧'
                            }
                        ]
                    };
                }
            },

            // 怪物技能
            counter_attack: {
                name: '反击',
                type: 'physical',
                mpCost: 15,
                execute: (caster, target) => {
                    return {
                        damage: caster.stats.attack * 1.2
                    };
                }
            },
            iron_defense: {
                name: '铁壁',
                type: 'buff',
                mpCost: 20,
                execute: (caster) => {
                    return {
                        effects: [{
                            type: 'buff',
                            stat: 'defense',
                            value: caster.stats.defense * 0.5,
                            duration: 3
                        }]
                    };
                }
            },
            quick_strike: {
                name: '快速打击',
                type: 'physical',
                mpCost: 15,
                execute: (caster, target) => {
                    return {
                        damage: caster.stats.attack * 0.8,
                        hitCount: 2
                    };
                }
            },
            intimidate: {
                name: '威吓',
                type: 'debuff',
                mpCost: 20,
                execute: (caster, target) => {
                    return {
                        effects: [{
                            type: 'debuff',
                            stat: 'attack',
                            value: -target.stats.attack * 0.2,
                            duration: 2
                        }]
                    };
                }
            },

            // 战士技能实现
            slash: {
                name: '斩击',
                type: 'physical',
                mpCost: 10,
                cooldown: 2,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.8;
                    
                    return {
                        damage: Math.floor(damage)
                    };
                }
            },
            whirlwind: {
                name: '旋风斩',
                type: 'physical',
                mpCost: 15,
                cooldown: 5,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.2;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 3
                    };
                }
            },
            charge: {
                name: '冲锋',
                type: 'physical',
                mpCost: 20,
                cooldown: 8,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.5;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'stun',
                            duration: 1,
                            name: '击晕'
                        }]
                    };
                }
            },
            shield_bash: {
                name: '盾击',
                type: 'physical',
                mpCost: 30,
                cooldown: 10,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.6;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'stun',
                            duration: 1.5,
                            name: '击晕'
                        }]
                    };
                }
            },

            // 武者技能实现
            rapid_strike: {
                name: '迅捷拳',
                type: 'physical',
                mpCost: 12,
                cooldown: 3,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damagePerHit = attackPower * 0.5;
                    
                    return {
                        damage: Math.floor(damagePerHit),
                        hitCount: 4
                    };
                }
            },
            palm_strike: {
                name: '震山掌',
                type: 'physical',
                mpCost: 15,
                cooldown: 5,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.7;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'knockback',
                            distance: 3,
                            name: '击退'
                        }]
                    };
                }
            },
            flying_kick: {
                name: '飞踢',
                type: 'physical',
                mpCost: 18,
                cooldown: 6,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 2;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'stun',
                            duration: 1,
                            name: '击晕'
                        }]
                    };
                }
            },

            // 法师高级技能
            chain_lightning: {
                name: '连锁闪电',
                type: 'magical',
                mpCost: 50,
                cooldown: 10,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.8;
                    
                    return {
                        damage: Math.floor(damage),
                        chainCount: 5,
                        chainDamageReduction: 0.2, // 每次链接伤害降低20%
                        effects: [{
                            type: 'paralyze',
                            duration: 1,
                            chance: 0.3,
                            name: '麻痹'
                        }]
                    };
                }
            },

            time_stop: {
                name: '时间停止',
                type: 'magical',
                mpCost: 100,
                cooldown: 30,
                execute: (caster, target) => {
                    return {
                        effects: [{
                            type: 'timestop',
                            duration: 3,
                            name: '时停'
                        }]
                    };
                }
            },

            arcane_explosion: {
                name: '奥术爆炸',
                type: 'magical',
                mpCost: 80,
                cooldown: 20,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 4;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 6,
                        effects: [{
                            type: 'silence',
                            duration: 2,
                            name: '沉默'
                        }]
                    };
                }
            },

            elemental_storm: {
                name: '元素风暴',
                type: 'magical',
                mpCost: 90,
                cooldown: 25,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.2;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 8,
                        duration: 5,
                        effects: [
                            {
                                type: 'dot',
                                damage: Math.floor(damage * 0.2),
                                duration: 5,
                                name: '元素灼烧'
                            },
                            {
                                type: 'slow',
                                value: 0.4,
                                duration: 5,
                                name: '元素缠绕'
                            }
                        ]
                    };
                }
            },

            // 战士高级技能
            execute: {
                name: '斩杀',
                type: 'physical',
                mpCost: 60,
                cooldown: 15,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const targetHpPercent = target.stats.hp / target.stats.maxHp;
                    let damageMultiplier = 2.5;
                    
                    // 目标生命值越低,伤害越高
                    if (targetHpPercent < 0.4) {
                        damageMultiplier = 4;
                    } else if (targetHpPercent < 0.2) {
                        damageMultiplier = 6;
                    }
                    
                    return {
                        damage: Math.floor(attackPower * damageMultiplier),
                        executeThreshold: 0.4 // 斩杀线
                    };
                }
            },

            avatar: {
                name: '战神附体',
                type: 'buff',
                mpCost: 80,
                cooldown: 30,
                execute: (caster) => {
                    return {
                        effects: [
                            {
                                type: 'buff',
                                stats: {
                                    attack: caster.stats.attack * 0.5,
                                    defense: caster.stats.defense * 0.3,
                                    speed: caster.stats.speed * 0.2,
                                    crit: 15
                                },
                                duration: 10,
                                name: '战神之力'
                            },
                            {
                                type: 'immune',
                                duration: 10,
                                name: '控制免疫'
                            }
                        ]
                    };
                }
            },

            earthquake: {
                name: '地裂斩',
                type: 'physical',
                mpCost: 70,
                cooldown: 25,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 2.8;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 7,
                        effects: [
                            {
                                type: 'stun',
                                duration: 1.5,
                                name: '震慑'
                            },
                            {
                                type: 'slow',
                                value: 0.3,
                                duration: 3,
                                name: '地形减速'
                            }
                        ]
                    };
                }
            },

            // 武者高级技能
            hundred_fists: {
                name: '百裂拳',
                type: 'physical',
                mpCost: 70,
                cooldown: 20,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damagePerHit = attackPower * 0.4;
                    
                    return {
                        damage: Math.floor(damagePerHit),
                        hitCount: 10,
                        effects: [{
                            type: 'stun',
                            duration: 0.1,
                            name: '击退',
                            stackable: true
                        }]
                    };
                }
            },

            dragon_kick: {
                name: '升龙击',
                type: 'physical',
                mpCost: 60,
                cooldown: 15,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 3.5;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [
                            {
                                type: 'knockup',
                                duration: 1.5,
                                name: '击飞'
                            },
                            {
                                type: 'vulnerable',
                                duration: 3,
                                value: 0.2,
                                name: '破防'
                            }
                        ]
                    };
                }
            },

            spirit_bomb: {
                name: '元气弹',
                type: 'energy',
                mpCost: 80,
                cooldown: 25,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = (attackPower + magicPower) * 2.5;
                    
                    return {
                        damage: Math.floor(damage),
                        chargeTime: 2,
                        aoe: true,
                        radius: 6,
                        effects: [{
                            type: 'dot',
                            damage: Math.floor(damage * 0.2),
                            duration: 3,
                            name: '元气侵蚀'
                        }]
                    };
                }
            },

            // 伙伴技能
            spirit_strike: {
                name: '灵力打击',
                type: 'magical',
                mpCost: 15,
                cooldown: 4,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 1.2;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'weaken',
                            value: 0.1,
                            duration: 2,
                            name: '灵力削弱'
                        }]
                    };
                }
            },

            spirit_shield: {
                name: '灵力护盾',
                type: 'buff',
                mpCost: 25,
                cooldown: 12,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    
                    return {
                        effects: [{
                            type: 'shield',
                            value: magicPower * 3,
                            duration: 5,
                            name: '灵力护盾'
                        }]
                    };
                }
            },

            spirit_heal: {
                name: '灵力治愈',
                type: 'heal',
                mpCost: 30,
                cooldown: 15,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const healing = magicPower * 1.8;
                    
                    return {
                        heal: Math.floor(healing),
                        effects: [{
                            type: 'regen',
                            healing: Math.floor(healing * 0.15),
                            duration: 3,
                            name: '灵力恢复'
                        }]
                    };
                }
            },

            // 特殊技能
            spirit_link: {
                name: '灵力共鸣',
                type: 'special',
                mpCost: 40,
                cooldown: 20,
                execute: (caster, target) => {
                    return {
                        effects: [{
                            type: 'link',
                            duration: 8,
                            sharePercent: 0.3, // 共享30%伤害
                            name: '灵力链接'
                        }]
                    };
                }
            },

            spirit_burst: {
                name: '灵力爆发',
                type: 'special',
                mpCost: 60,
                cooldown: 30,
                execute: (caster) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    
                    return {
                        effects: [{
                            type: 'empower',
                            stats: {
                                magic: magicPower * 0.5,
                                mpRegen: magicPower * 0.2
                            },
                            duration: 6,
                            name: '灵力增幅'
                        }]
                    };
                }
            },

            // 合体技能
            dual_strike: {
                name: '双重打击',
                type: 'combo',
                mpCost: 45,
                cooldown: 12,
                execute: (caster, partner, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const partnerPower = Math.max(0, Number(partner.stats.attack || 0));
                    const damage = (attackPower + partnerPower) * 1.5;
                    
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'vulnerable',
                            value: 0.2,
                            duration: 3,
                            name: '双重破防'
                        }]
                    };
                }
            },

            spirit_resonance: {
                name: '灵力共振',
                type: 'combo',
                mpCost: 70,
                cooldown: 25,
                execute: (caster, partner, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const partnerMagic = Math.max(0, Number(partner.stats.magic || 0));
                    const damage = (magicPower + partnerMagic) * 2;
                    
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 5,
                        effects: [
                            {
                                type: 'dot',
                                damage: Math.floor(damage * 0.2),
                                duration: 4,
                                name: '共振灼烧'
                            },
                            {
                                type: 'silence',
                                duration: 2,
                                name: '共振沉默'
                            }
                        ]
                    };
                }
            },

            ultimate_fusion: {
                name: '终极融合',
                type: 'ultimate',
                mpCost: 100,
                cooldown: 60,
                execute: (caster, partner) => {
                    const combinedPower = (caster.stats.attack + caster.stats.magic + 
                                         partner.stats.attack + partner.stats.magic) * 0.5;
                    
                    return {
                        fusion: {
                            duration: 15,
                            stats: {
                                attack: combinedPower,
                                magic: combinedPower,
                                defense: (caster.stats.defense + partner.stats.defense) * 0.7,
                                speed: Math.max(caster.stats.speed, partner.stats.speed) * 1.3
                            },
                            effects: [
                                {
                                    type: 'immune',
                                    duration: 15,
                                    name: '融合免疫'
                                },
                                {
                                    type: 'empower',
                                    value: 0.3,
                                    duration: 15,
                                    name: '融合强化'
                                }
                            ]
                        }
                    };
                }
            },

            // 狼群技能
            pack_tactics: {
                name: '狼群战术',
                type: 'buff',
                mpCost: 25,
                cooldown: 5,
                execute: (caster) => {
                    return {
                        effects: [{
                            type: 'buff',
                            stats: {
                                attack: Math.floor(caster.stats.attack * 0.3),
                                crit: 15
                            },
                            duration: 3,
                            name: '狼群增益'
                        }]
                    };
                }
            },

            // 蛇类技能
            poison_bite: {
                name: '毒牙',
                type: 'physical',
                mpCost: 20,
                cooldown: 4,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.3;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'dot',
                            damage: Math.floor(damage * 0.2),
                            duration: 3,
                            name: '中毒'
                        }]
                    };
                }
            },

            constrict: {
                name: '缠绕',
                type: 'physical',
                mpCost: 15,
                cooldown: 4,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.2;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'debuff',
                            stats: {
                                speed: -Math.floor(target.stats.speed * 0.3)
                            },
                            duration: 2,
                            name: '缠绕减速'
                        }]
                    };
                }
            },

            // 水灵技能
            water_blast: {
                name: '水流冲击',
                type: 'magical',
                mpCost: 30,
                cooldown: 3,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, caster.stats.magic || 0);
                    const damage = magicPower * 1.6;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'slow',
                            value: 0.2,
                            duration: 2,
                            name: '水流减速'
                        }]
                    };
                }
            },

            healing_mist: {
                name: '治愈之雾',
                type: 'heal',
                mpCost: 40,
                cooldown: 5,
                execute: (caster) => {
                    const magicPower = Math.max(0, caster.stats.magic || 0);
                    const healing = magicPower * 1.5;
                    return {
                        heal: Math.floor(healing),
                        effects: [{
                            type: 'regen',
                            healing: Math.floor(healing * 0.2),
                            duration: 3,
                            name: '治愈雾气'
                        }]
                    };
                }
            },

            // 山鹰技能
            dive_attack: {
                name: '俯冲攻击',
                type: 'physical',
                mpCost: 25,
                cooldown: 4,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.8;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'stun',
                            duration: 1,
                            name: '击晕'
                        }]
                    };
                }
            },

            wind_slash: {
                name: '风刃',
                type: 'physical',
                mpCost: 20,
                cooldown: 3,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 0.7;
                    return {
                        damage: Math.floor(damage),
                        hitCount: 2,
                        effects: [{
                            type: 'bleed',
                            damage: Math.floor(damage * 0.1),
                            duration: 3,
                            name: '撕裂'
                        }]
                    };
                }
            },

            // 蝙蝠技能
            sonic_wave: {
                name: '音波',
                type: 'magical',
                mpCost: 15,
                cooldown: 4,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, caster.stats.magic || 0);
                    const damage = magicPower * 1.3;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'debuff',
                            stats: {
                                hit: -Math.floor(target.stats.hit * 0.2)
                            },
                            duration: 2,
                            name: '音波干扰'
                        }]
                    };
                }
            },

            blood_drain: {
                name: '吸血',
                type: 'physical',
                mpCost: 20,
                cooldown: 4,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.2;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'drain',
                            value: Math.floor(damage * 0.5),
                            name: '生命吸取'
                        }]
                    };
                }
            },

            // 岩石怪技能
            rock_throw: {
                name: '投石',
                type: 'physical',
                mpCost: 15,
                cooldown: 3,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.5;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'slow',
                            value: 0.2,
                            duration: 2,
                            name: '击退减速'
                        }]
                    };
                }
            },

            stone_skin: {
                name: '石肤',
                type: 'buff',
                mpCost: 30,
                cooldown: 5,
                execute: (caster) => {
                    return {
                        effects: [{
                            type: 'buff',
                            stats: {
                                defense: Math.floor(caster.stats.defense * 0.8)
                            },
                            duration: 3,
                            name: '石化防御'
                        }]
                    };
                }
            },

            // 云雾精灵技能
            mist_veil: {
                name: '迷雾帷幕',
                type: 'buff',
                mpCost: 35,
                cooldown: 5,
                execute: (caster) => {
                    return {
                        effects: [{
                            type: 'buff',
                            stats: {
                                dodge: Math.floor(caster.stats.dodge * 0.5),
                                defense: Math.floor(caster.stats.defense * 0.3)
                            },
                            duration: 3,
                            name: '迷雾加护'
                        }]
                    };
                }
            },

            cloud_burst: {
                name: '云爆',
                type: 'magical',
                mpCost: 45,
                cooldown: 6,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, caster.stats.magic || 0);
                    const damage = magicPower * 1.7;
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 3,
                        effects: [{
                            type: 'dot',
                            damage: Math.floor(damage * 0.2),
                            duration: 3,
                            name: '云雾侵蚀'
                        }]
                    };
                }
            },

            stone_smash: {
                name: '碎岩击',
                type: 'physical',
                mpCost: 25,
                cooldown: 4,
                execute: (caster, target) => {
                    const damage = caster.stats.attack * 1.6;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'stun',
                            chance: 0.3,
                            duration: 1,
                            name: '击晕'
                        }]
                    };
                }
            },

            petrify: {
                name: '石化',
                type: 'magical',
                mpCost: 40,
                cooldown: 8,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, caster.stats.magic || 0);
                    return {
                        effects: [{
                            type: 'petrify',
                            stats: {
                                defense: -Math.floor(target.stats.defense * 0.3),
                                speed: -Math.floor(target.stats.speed * 0.5)
                            },
                            duration: 2,
                            name: '石化'
                        }]
                    };
                }
            },

            // 沙漠怪物技能
            sand_armor: {
                name: '沙甲',
                type: 'buff',
                mpCost: 25,
                cooldown: 5,
                execute: (caster) => {
                    const defenseBonus = Math.floor(caster.stats.defense * 0.5);
                    return {
                        effects: [{
                            type: 'buff',
                            stats: {
                                defense: defenseBonus
                            },
                            duration: 3,
                            name: '沙之护甲'
                        }]
                    };
                }
            },

            burrow: {
                name: '遁地',
                type: 'buff',
                mpCost: 30,
                cooldown: 6,
                execute: (caster) => {
                    const dodgeBonus = Math.floor(caster.stats.dodge * 1.0);
                    return {
                        effects: [{
                            type: 'buff',
                            stats: {
                                dodge: dodgeBonus
                            },
                            duration: 2,
                            name: '遁地闪避'
                        }]
                    };
                }
            },

            sand_blast: {
                name: '沙暴喷射',
                type: 'physical',
                mpCost: 35,
                cooldown: 4,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 1.8;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'blind',
                            duration: 2,
                            name: '致盲'
                        }]
                    };
                }
            },

            sand_storm: {
                name: '沙尘暴',
                type: 'magical',
                mpCost: 45,
                cooldown: 6,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 2.0;
                    return {
                        damage: Math.floor(damage),
                        aoe: true,
                        radius: 3,
                        effects: [{
                            type: 'slow',
                            value: 0.3,
                            duration: 2,
                            name: '沙暴减速'
                        }]
                    };
                }
            },

            ancient_curse: {
                name: '远古诅咒',
                type: 'magical',
                mpCost: 40,
                cooldown: 5,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 1.6;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'curse',
                            stats: {
                                attack: -Math.floor(target.stats.attack * 0.3),
                                defense: -Math.floor(target.stats.defense * 0.3),
                                speed: -Math.floor(target.stats.speed * 0.3)
                            },
                            duration: 3,
                            name: '远古诅咒'
                        }]
                    };
                }
            },

            // 地下迷宫怪物技能
            dark_ritual: {
                name: '暗影仪式',
                type: 'magical',
                mpCost: 45,
                cooldown: 5,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 2.0;
                    const dotDamage = Math.floor(damage * 0.2);
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'dot',
                            damage: dotDamage,
                            duration: 3,
                            name: '暗影灼烧'
                        }]
                    };
                }
            },

            dungeon_mastery: {
                name: '迷宫掌控',
                type: 'buff',
                mpCost: 60,
                cooldown: 8,
                execute: (caster) => {
                    const statBonus = {
                        attack: Math.floor(caster.stats.attack * 0.5),
                        defense: Math.floor(caster.stats.defense * 0.5),
                        speed: Math.floor(caster.stats.speed * 0.5)
                    };
                    return {
                        effects: [{
                            type: 'buff',
                            stats: statBonus,
                            duration: 3,
                            name: '迷宫掌控'
                        }]
                    };
                }
            },

            surprise_attack: {
                name: '突袭',
                type: 'physical',
                mpCost: 30,
                cooldown: 4,
                execute: (caster, target) => {
                    const attackPower = Math.max(0, Number(caster.stats.attack || 0));
                    const damage = attackPower * 2.5;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'stun',
                            duration: 1,
                            name: '突袭眩晕'
                        }],
                        critRateBonus: 50
                    };
                }
            },

            // 水灵技能
            water_blast: {
                name: '水流冲击',
                type: 'magical',
                mpCost: 35,
                cooldown: 4,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 1.8;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'slow',
                            value: 0.3,
                            duration: 2,
                            name: '水流减速'
                        }]
                    };
                }
            },

            healing_mist: {
                name: '治愈之雾',
                type: 'heal',
                mpCost: 45,
                cooldown: 6,
                execute: (caster) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const healing = magicPower * 1.5;
                    const regenAmount = Math.floor(healing * 0.2);
                    return {
                        heal: Math.floor(healing),
                        effects: [{
                            type: 'regen',
                            healing: regenAmount,
                            duration: 3,
                            name: '治愈雾气'
                        }]
                    };
                }
            },

            water_shield: {
                name: '水盾',
                type: 'buff',
                mpCost: 40,
                cooldown: 5,
                execute: (caster) => {
                    const defenseBonus = Math.floor(caster.stats.defense * 0.4);
                    const magicBonus = Math.floor(caster.stats.magic * 0.3);
                    return {
                        effects: [{
                            type: 'buff',
                            stats: {
                                defense: defenseBonus,
                                magic: magicBonus
                            },
                            duration: 3,
                            name: '水之护盾'
                        }]
                    };
                }
            },

            tidal_force: {
                name: '潮汐之力',
                type: 'magical',
                mpCost: 50,
                cooldown: 7,
                execute: (caster, target) => {
                    const magicPower = Math.max(0, Number(caster.stats.magic || 0));
                    const damage = magicPower * 2.0;
                    return {
                        damage: Math.floor(damage),
                        effects: [{
                            type: 'knockback',
                            distance: 2,
                            chance: 0.5,
                            name: '潮汐冲击'
                        }]
                    };
                }
            }
        };

        // 添加技能冷却追踪
        this.skillCooldowns = new Map();
    }

    // 执行技能
    executeSkill(skillId, caster, target) {
        const skill = this.SKILL_EFFECTS[skillId];
        if (!skill) {
            console.error('未知的技能:', skillId);
            return null;
        }

        // 检查技能是否在冷却中
        if (this.isSkillOnCooldown(caster.id, skillId)) {
            console.log(`技能 ${skill.name} 正在冷却中`);
            return null;
        }

        // 检查MP消耗
        if (skill.mpCost && caster.stats.mp < skill.mpCost) {
            console.log('法力值不足');
            return null;
        }

        // 扣除MP
        if (skill.mpCost) {
            caster.stats.mp -= skill.mpCost;
        }

        // 执行技能效果
        const result = skill.execute(caster, target);
        
        // 设置技能冷却
        if (skill.cooldown) {
            this.setSkillCooldown(caster.id, skillId, skill.cooldown);
        }

        // 验证并修正伤害值
        if (result) {
            if (typeof result.damage !== 'undefined') {
                result.damage = this.validateDamage(result.damage);
            }
            if (result.effects) {
                result.effects = result.effects.map(effect => {
                    if (effect.damage) {
                        effect.damage = this.validateDamage(effect.damage);
                    }
                    return effect;
                });
            }
        }

        return result;
    }

    // 添加伤害验证方法
    validateDamage(damage) {
        // 如果伤害无效，返回0
        if (isNaN(damage) || !isFinite(damage) || damage === null || damage === undefined) {
            console.warn('检测到无效的伤害值:', damage, '使用默认值0');
            return 0;
        }
        
        // 确保伤害为非负数并取整
        return Math.max(0, Math.floor(Number(damage)));
    }

    // 应用技能效果
    applySkillEffect(effect, target) {
        if (effect.damage) {
            target.stats.hp -= effect.damage;
        }

        if (effect.heal) {
            target.stats.hp = Math.min(target.stats.hp + effect.heal, target.stats.maxHp);
        }

        if (effect.effects) {
            effect.effects.forEach(statusEffect => {
                this.applyStatusEffect(statusEffect, target);
            });
        }
    }

    // 应用状态效果
    applyStatusEffect(effect, target) {
        switch (effect.type) {
            case 'buff':
                target.stats[effect.stat] += effect.value;
                setTimeout(() => {
                    target.stats[effect.stat] -= effect.value;
                }, effect.duration * 1000);
                break;

            case 'debuff':
                target.stats[effect.stat] += effect.value;
                setTimeout(() => {
                    target.stats[effect.stat] -= effect.value;
                }, effect.duration * 1000);
                break;

            case 'dot':
                const interval = setInterval(() => {
                    target.stats.hp -= effect.damage;
                }, 1000);
                setTimeout(() => {
                    clearInterval(interval);
                }, effect.duration * 1000);
                break;

            // ... 其他效果类型
        }
    }

    // 检查技能是否可用
    canUseSkill(skillId, caster) {
        const skill = this.SKILL_EFFECTS[skillId];
        if (!skill) return false;

        // 检查MP消耗
        if (skill.mpCost && caster.stats.mp < skill.mpCost) {
            return false;
        }

        return true;
    }

    // 添加检查技能冷却的方法
    isSkillOnCooldown(casterId, skillId) {
        const cooldownKey = `${casterId}_${skillId}`;
        const cooldownInfo = this.skillCooldowns.get(cooldownKey);
        
        if (!cooldownInfo) return false;
        
        const now = Date.now();
        const isOnCooldown = now < cooldownInfo.endTime;
        
        // 如果冷却已结束,清除冷却信息
        if (!isOnCooldown) {
            this.skillCooldowns.delete(cooldownKey);
        }
        
        return isOnCooldown;
    }

    // 添加设置技能冷却的方法
    setSkillCooldown(casterId, skillId, duration) {
        const cooldownKey = `${casterId}_${skillId}`;
        const now = Date.now();
        
        this.skillCooldowns.set(cooldownKey, {
            startTime: now,
            endTime: now + (duration * 1000)
        });
        
        //console.log(`设置技能 ${skillId} 冷却 ${duration} 秒`);
    }

    // 添加获取可用技能的方法
    getAvailableSkills(caster) {
        if (!caster.skills) return [];

        return caster.skills.filter(skill => {
            // 跳过普通攻击
            if (skill.id === 'basic_attack') return false;

            // 检查技能配置是否存在
            const skillConfig = this.SKILL_EFFECTS[skill.id];
            if (!skillConfig) return false;

            // 检查MP是否足够
            if (skillConfig.mpCost && caster.stats.mp < skillConfig.mpCost) return false;

            // 检查是否在冷却中
            if (this.isSkillOnCooldown(caster.id, skill.id)) return false;

            return true;
        });
    }

    // 添加获取技能剩余冷却时间的方法
    getSkillRemainingCooldown(casterId, skillId) {
        const cooldownKey = `${casterId}_${skillId}`;
        const cooldownInfo = this.skillCooldowns.get(cooldownKey);
        
        if (!cooldownInfo) return 0;
        
        const now = Date.now();
        const remaining = Math.max(0, Math.ceil((cooldownInfo.endTime - now) / 1000));
        
        return remaining;
    }
}

// 创建全局实例
const skillEffectSystem = new SkillEffectSystem(); 