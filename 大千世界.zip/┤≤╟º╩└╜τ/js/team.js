class TeamSystem {
    constructor() {
        this.maxTeamSize = 4;
        this.maxCompanions = 6;
        this.currentTeam = [];
        this.companions = [];
        
        // 品质配置
        this.QUALITY_CONFIG = {
            NORMAL: {
                name: '普通',
                color: '#A1A1A1',
                growthRate: 1.0
            },
            RARE: {
                name: '稀有',
                color: '#4CAF50',
                growthRate: 1.2
            },
            EPIC: {
                name: '史诗',
                color: '#2196F3',
                growthRate: 1.5
            },
            LEGENDARY: {
                name: '传说',
                color: '#FFC107',
                growthRate: 2.0
            },
            MYTHIC: {
                name: '神话',
                color: '#E91E63',
                growthRate: 2.5
            }
        };

        // 职业成长配置
        this.CLASS_GROWTH = {
            warrior: {
                NORMAL: {
                    strength: { base: 15, growth: 2.5 },
                    constitution: { base: 14, growth: 2.2 },
                    agility: { base: 10, growth: 1.5 },
                    wisdom: { base: 8, growth: 1.2 },
                    speed: { base: 11, growth: 1.8 }
                },
                RARE: {
                    strength: { base: 17, growth: 3.0 },
                    constitution: { base: 16, growth: 2.6 },
                    agility: { base: 11, growth: 1.8 },
                    wisdom: { base: 9, growth: 1.4 },
                    speed: { base: 12, growth: 2.1 }
                },
                EPIC: {
                    strength: { base: 20, growth: 3.8 },
                    constitution: { base: 19, growth: 3.3 },
                    agility: { base: 13, growth: 2.3 },
                    wisdom: { base: 10, growth: 1.8 },
                    speed: { base: 14, growth: 2.7 }
                },
                LEGENDARY: {
                    strength: { base: 25, growth: 5.0 },
                    constitution: { base: 23, growth: 4.4 },
                    agility: { base: 16, growth: 3.0 },
                    wisdom: { base: 12, growth: 2.4 },
                    speed: { base: 17, growth: 3.6 }
                },
                MYTHIC: {
                    strength: { base: 30, growth: 6.3 },
                    constitution: { base: 28, growth: 5.5 },
                    agility: { base: 20, growth: 3.8 },
                    wisdom: { base: 15, growth: 3.0 },
                    speed: { base: 21, growth: 4.5 }
                }
            },
            mage: {
                NORMAL: {
                    strength: { base: 8, growth: 1.2 },
                    constitution: { base: 12, growth: 2.0 },
                    agility: { base: 9, growth: 1.5 },
                    wisdom: { base: 15, growth: 2.5 },
                    speed: { base: 10, growth: 1.8 }
                },
                RARE: {
                    strength: { base: 9, growth: 1.4 },
                    constitution: { base: 14, growth: 2.4 },
                    agility: { base: 10, growth: 1.8 },
                    wisdom: { base: 18, growth: 3.0 },
                    speed: { base: 11, growth: 2.2 }
                },
                EPIC: {
                    strength: { base: 10, growth: 1.8 },
                    constitution: { base: 17, growth: 3.0 },
                    agility: { base: 12, growth: 2.3 },
                    wisdom: { base: 22, growth: 3.8 },
                    speed: { base: 13, growth: 2.7 }
                },
                LEGENDARY: {
                    strength: { base: 12, growth: 2.4 },
                    constitution: { base: 21, growth: 4.0 },
                    agility: { base: 15, growth: 3.0 },
                    wisdom: { base: 28, growth: 5.0 },
                    speed: { base: 16, growth: 3.6 }
                },
                MYTHIC: {
                    strength: { base: 15, growth: 3.0 },
                    constitution: { base: 26, growth: 5.0 },
                    agility: { base: 19, growth: 3.8 },
                    wisdom: { base: 35, growth: 6.3 },
                    speed: { base: 20, growth: 4.5 }
                }
            },
            monk: {
                NORMAL: {
                    strength: { base: 13, growth: 2.0 },
                    constitution: { base: 12, growth: 1.8 },
                    agility: { base: 14, growth: 2.2 },
                    wisdom: { base: 10, growth: 1.5 },
                    speed: { base: 13, growth: 2.0 }
                },
                RARE: {
                    strength: { base: 15, growth: 2.4 },
                    constitution: { base: 14, growth: 2.2 },
                    agility: { base: 17, growth: 2.6 },
                    wisdom: { base: 11, growth: 1.8 },
                    speed: { base: 15, growth: 2.4 }
                },
                EPIC: {
                    strength: { base: 18, growth: 3.0 },
                    constitution: { base: 17, growth: 2.7 },
                    agility: { base: 21, growth: 3.3 },
                    wisdom: { base: 13, growth: 2.3 },
                    speed: { base: 18, growth: 3.0 }
                },
                LEGENDARY: {
                    strength: { base: 22, growth: 4.0 },
                    constitution: { base: 21, growth: 3.6 },
                    agility: { base: 26, growth: 4.4 },
                    wisdom: { base: 16, growth: 3.0 },
                    speed: { base: 22, growth: 4.0 }
                },
                MYTHIC: {
                    strength: { base: 27, growth: 5.0 },
                    constitution: { base: 26, growth: 4.5 },
                    agility: { base: 32, growth: 5.5 },
                    wisdom: { base: 20, growth: 3.8 },
                    speed: { base: 27, growth: 5.0 }
                }
            },
            taoist: {
                NORMAL: {
                    strength: { base: 9, growth: 1.3 },
                    constitution: { base: 11, growth: 1.8 },
                    agility: { base: 12, growth: 1.7 },
                    wisdom: { base: 14, growth: 2.3 },
                    speed: { base: 12, growth: 1.9 }
                },
                RARE: {
                    strength: { base: 10, growth: 1.6 },
                    constitution: { base: 13, growth: 2.2 },
                    agility: { base: 14, growth: 2.0 },
                    wisdom: { base: 17, growth: 2.8 },
                    speed: { base: 14, growth: 2.3 }
                },
                EPIC: {
                    strength: { base: 12, growth: 2.0 },
                    constitution: { base: 16, growth: 2.7 },
                    agility: { base: 17, growth: 2.6 },
                    wisdom: { base: 21, growth: 3.5 },
                    speed: { base: 17, growth: 2.9 }
                },
                LEGENDARY: {
                    strength: { base: 15, growth: 2.6 },
                    constitution: { base: 20, growth: 3.6 },
                    agility: { base: 21, growth: 3.4 },
                    wisdom: { base: 26, growth: 4.6 },
                    speed: { base: 21, growth: 3.8 }
                },
                MYTHIC: {
                    strength: { base: 19, growth: 3.3 },
                    constitution: { base: 25, growth: 4.5 },
                    agility: { base: 26, growth: 4.3 },
                    wisdom: { base: 32, growth: 5.8 },
                    speed: { base: 26, growth: 4.8 }
                }
            }
        };

        // 姓名生成配置
        this.NAME_CONFIG = {
            firstName: ['赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', ''],
            middleName: ['天', '地', '玄', '黄', '宇', '宙', '洪', '荒', '日', '月', '金', '木'],
            lastName: ['龙', '凤', '云', '霄', '风', '雨', '雷', '电', '山', '河', '海', '洋']
        };

        // NPC数据配置
        this.NPC_CONFIG = {
            warrior_npc: {
                id: 'warrior_npc',
                name: this.generateRandomName(),
                class: 'warrior',
                level: 1,
                quality: 'RARE',
                icon: '⚔️',
                description: '浪迹天涯的剑客，擅长近战。'
            },
            // ... 其他NPC配置
        };

        // 添加品质招募费用配置
        this.QUALITY_COST = {
            NORMAL: 100,
            RARE: 300,
            EPIC: 1000,
            LEGENDARY: 3000,
            MYTHIC: 10000
        };

        // 刷新招募费用
        this.REFRESH_COST = 50;  // 基础刷新费用
        this.refreshCount = 0;   // 刷新次数计数
        
        // 当前可招募的NPC列表
        this.recruitableNPCs = [];
        
        // 添加技能池配置
        this.SKILL_POOLS = {
            warrior: [
                { id: 'slash', name: '斩击', icon: '⚔️', description: '对敌人进行一次强力斩击' },
                { id: 'whirlwind', name: '旋风斩', icon: '🌪️', description: '旋转攻击周围的敌人' },
                { id: 'charge', name: '冲锋', icon: '⚡', description: '向目标冲锋并造成伤害' },
                { id: 'shield_bash', name: '盾击', icon: '🛡️', description: '用盾牌猛击敌人，造成伤害和眩晕' },
                { id: 'battle_cry', name: '战吼', icon: '📢', description: '发出震慑敌人的怒吼' }
            ],
            mage: [
                { id: 'fireball', name: '火球术', icon: '🔥', description: '发射一个火球造成魔法伤害' },
                { id: 'frost_nova', name: '霜冻新星', icon: '❄️', description: '释放冰霜能量，对周围敌人造成伤害并减速' },
                { id: 'arcane_missile', name: '奥术飞弹', icon: '✨', description: '发射多枚奥术飞弹追踪敌人' },
                { id: 'meteor', name: '陨石术', icon: '☄️', description: '召唤陨石打击范围内的敌人' },
                { id: 'time_stop', name: '时间止', icon: '⌛', description: '短暂停止时间，让敌人静止' }
            ],
            monk: [
                { id: 'palm_strike', name: '掌击', icon: '🤚', description: '快速的掌法攻击' },
                { id: 'flying_kick', name: '飞踢', icon: '🦶', description: '一记凌空飞踢' },
                { id: 'chi_burst', name: '真气爆发', icon: '💫', description: '爆发体内真气造成范围伤害' },
                { id: 'meditation', name: '冥想', icon: '🧘', description: '恢复生命值和真气' },
                { id: 'dragon_punch', name: '升龙拳', icon: '🐉', description: '强力的升龙击打' }
            ],
            taoist: [
                { id: 'thunder_strike', name: '雷击术', icon: '⚡', description: '召唤雷电攻击敌人' },
                { id: 'healing_talisman', name: '治疗符', icon: '📜', description: '使用符咒恢复生命值' },
                { id: 'spirit_summon', name: '召唤灵宠', icon: '🐲', description: '召唤灵宠协助战斗' },
                { id: 'soul_drain', name: '吸魂术', icon: '👻', description: '吸取敌人生命值和法力值' },
                { id: 'divine_seal', name: '天罡封印', icon: '🔯', description: '封印敌人的能力并造成持续伤害' }
            ]
        };

        // 品质对应的技能数量范围
        this.QUALITY_SKILLS = {
            NORMAL: { min: 0, max: 1 },
            RARE: { min: 1, max: 2 },
            EPIC: { min: 2, max: 2 },
            LEGENDARY: { min: 3, max: 3 },
            MYTHIC: { min: 4, max: 4 }
        };

        // 初始化可招募NPC
        this.refreshRecruitableNPCs();

        // 添加玩家伙伴数据结构
        this.playerData = {
            companions: [], // 已招募的伙伴列表
            currentTeam: [], // 当前队伍
            maxTeamSize: 4,
            maxCompanions: 6
        };
    }

    // 初始化玩家伙伴数据
    initializePlayerData(player) {
        if (!player.teamData) {
            player.teamData = {
                companions: [],
                currentTeam: [],
                maxTeamSize: this.maxTeamSize,
                maxCompanions: this.maxCompanions
            };
        }
        // 从玩家数据同步到系统中
        this.companions = player.teamData.companions;
        this.currentTeam = player.teamData.currentTeam;
    }

    // 生成随机名字
    generateRandomName() {
        const getRandomElement = (array) => array[Math.floor(Math.random() * array.length)];
        
        const first = getRandomElement(this.NAME_CONFIG.firstName);
        const middle = getRandomElement(this.NAME_CONFIG.middleName);
        const last = getRandomElement(this.NAME_CONFIG.lastName);
        
        // 随机决定是否使用中间名
        return Math.random() > 0.5 ? `${first}${middle}${last}` : `${first}${last}`;
    }

    // 计算伙伴属性成长
    calculateCompanionGrowth(companion) {
        try {
            // 检查是否存在对应的职业成长配置
            if (!this.CLASS_GROWTH[companion.class]) {
                throw new Error(`未找到职业 ${companion.class} 的成长配置`);
            }

            // 检查是否存在对应品质的成长配置
            if (!this.CLASS_GROWTH[companion.class][companion.quality]) {
                throw new Error(`未找到职业 ${companion.class} 的 ${companion.quality} 品质成长配置`);
            }

            const baseGrowth = this.CLASS_GROWTH[companion.class][companion.quality];
            const qualityRate = this.QUALITY_CONFIG[companion.quality].growthRate;

            // 计算实际属性和成长值
            return {
                base: {
                    strength: baseGrowth.strength.base,
                    constitution: baseGrowth.constitution.base,
                    agility: baseGrowth.agility.base,
                    wisdom: baseGrowth.wisdom.base,
                    speed: baseGrowth.speed.base
                },
                growth: {
                    strength: baseGrowth.strength.growth * qualityRate,
                    constitution: baseGrowth.constitution.growth * qualityRate,
                    agility: baseGrowth.agility.growth * qualityRate,
                    wisdom: baseGrowth.wisdom.growth * qualityRate,
                    speed: baseGrowth.speed.growth * qualityRate
                }
            };
        } catch (error) {
            console.error('计算伙伴成长属性失败:', error);
            // 返回默认成长值
            return {
                base: {
                    strength: 10,
                    constitution: 10,
                    agility: 10,
                    wisdom: 10,
                    speed: 10
                },
                growth: {
                    strength: 1.0,
                    constitution: 1.0,
                    agility: 1.0,
                    wisdom: 1.0,
                    speed: 1.0
                }
            };
        }
    }

    // 招募伙伴时随机生成品质
    generateRandomQuality() {
        const rand = Math.random() * 100;
        if (rand < 1) return 'MYTHIC';      // 1%
        if (rand < 5) return 'LEGENDARY';    // 4%
        if (rand < 15) return 'EPIC';        // 10%
        if (rand < 35) return 'RARE';        // 20%
        return 'NORMAL';                     // 65%
    }

    // 修改招募伙伴方法
    recruitCompanion(npcData, player) {
        if (!player) {
            console.error('No player data provided');
            return false;
        }

        if (!player.teamData) {
            player.teamData = {
                companions: [],
                currentTeam: [],
                maxTeamSize: this.maxTeamSize,
                maxCompanions: this.maxCompanions
            };
        }

        if (player.teamData.companions.length >= this.maxCompanions) {
            gameManager.showFloatingTip('伙伴数量已达上限！', 'error');
            return false;
        }

        try {
            // 直接使用NPC的品质和技能，而不是重新生成
            const companion = {
                id: `companion_${Date.now()}`,
                name: npcData.name,
                class: npcData.class,
                level: 1,
                quality: npcData.quality, // 使用NPC的品质
                icon: npcData.icon,
                description: npcData.description,
                skills: npcData.skills || [], // 使用NPC的技能
                growth: this.CLASS_GROWTH[npcData.class][npcData.quality], // 根据NPC的品质获取成长
                stats: this.calculateCompanionStats({
                    class: npcData.class,
                    quality: npcData.quality,
                    level: 1,
                    growth: this.CLASS_GROWTH[npcData.class][npcData.quality]
                })
            };

            player.teamData.companions.push(companion);
            this.companions = player.teamData.companions;
            saveCharacter(player);
            
            return true;
        } catch (error) {
            console.error('Error recruiting companion:', error);
            gameManager.showFloatingTip('招募伙伴失败！', 'error');
            return false;
        }
    }

    // 修改培养伙伴方法
    trainCompanion(companionId, player) {
        if (!player.teamData) return false;

        const companion = player.teamData.companions.find(c => c.id === companionId);
        if (!companion) return false;

        // 计算升级消耗
        const cost = this.calculateLevelUpCost(companion);
        if (player.gold < cost) {
            gameManager.showFloatingTip('金币不足！', 'error');
            return false;
        }

        // 扣除金币
        player.gold -= cost;
        // 升级伙伴
        companion.level++;
        // 更新属性
        companion.stats = this.calculateCompanionStats(companion);

        // 保存角色数据
        saveCharacter(player);

        return true;
    }

    // 修改解雇伙伴方法
    dismissCompanion(companionId, player) {
        if (!player.teamData) return false;

        // 从队伍中移除
        player.teamData.currentTeam = player.teamData.currentTeam.filter(id => id !== companionId);
        // 从伙伴列表移除
        player.teamData.companions = player.teamData.companions.filter(c => c.id !== companionId);

        // 同步到系统中
        this.currentTeam = player.teamData.currentTeam;
        this.companions = player.teamData.companions;

        // 保存角色数据
        saveCharacter(player);

        return true;
    }

    // 修改队伍编成方法
    setTeamMember(companionId, position, player) {
        if (!player.teamData) return false;

        // 不允许修改位置0(队长位置)
        if (position === 0) return false;

        // 验证位置有效性
        if (position < 1 || position >= this.maxTeamSize) return false;

        // 更新队伍数据(注意数组索引要减1)
        const newTeam = [...player.teamData.currentTeam];
        newTeam[position - 1] = companionId;
        
        // 保存到玩家数据
        player.teamData.currentTeam = newTeam;
        // 同步到系统中
        this.currentTeam = newTeam;

        // 保存角色数据
        saveCharacter(player);

        return true;
    }

    // 修改移出队伍方法
    removeFromTeam(companionId) {
        const index = this.currentTeam.indexOf(companionId);
        if (index === -1) return false;

        // 从队伍中移除
        this.currentTeam.splice(index, 1);
        
        // 保存角色数据
        if (gameManager.currentPlayer) {
            gameManager.currentPlayer.teamData = {
                companions: this.companions,
                currentTeam: this.currentTeam,
                maxTeamSize: this.maxTeamSize,
                maxCompanions: this.maxCompanions
            };
            saveCharacter(gameManager.currentPlayer);
        }

        return true;
    }

    // 获取当前队伍成员数据
    getTeamMembers(player) {
        if (!player.teamData) return [];

        return player.teamData.currentTeam.map(id => {
            return player.teamData.companions.find(c => c.id === id);
        }).filter(member => member != null);
    }

    // 获取所有伙伴数据
    getAllCompanions(player) {
        if (!player.teamData) return [];
        return player.teamData.companions;
    }

    // 更新伙伴显示方法
    updateCompanionsDisplay() {
        const companionsList = document.querySelector('.companions-list');
        if (!companionsList) return;

        companionsList.innerHTML = '';
        
        this.companions.forEach(companion => {
            const card = document.createElement('div');
            const isInTeam = this.currentTeam.includes(companion.id);
            
            // 设置卡片的基本属性和状态
            card.className = `companion-card ${isInTeam ? 'selected' : ''}`;
            card.dataset.inTeam = isInTeam ? 'true' : 'false';
            card.dataset.companionId = companion.id;
            
            // 添加品质相关的样式
            const qualityConfig = this.QUALITY_CONFIG[companion.quality];
            card.style.borderColor = qualityConfig.color;
            
            card.innerHTML = `
                <span class="quality-badge" style="background: ${qualityConfig.color}">
                    ${qualityConfig.name}
                </span>
                <div class="companion-header">
                    <div class="companion-avatar" style="border: 2px solid ${qualityConfig.color}">
                        ${companion.icon}
                    </div>
                    <div class="companion-info">
                        <div class="companion-name">${companion.name}</div>
                        <div class="companion-class">
                            ${this.getClassName(companion.class)} Lv.${companion.level}
                        </div>
                    </div>
                </div>
                <div class="companion-description">
                    ${companion.description || '这个伙伴很神秘，没有留下描述。'}
                </div>
                ${companion.skills && companion.skills.length > 0 ? `
                    <div class="companion-skills">
                        ${companion.skills.map(skill => `
                            <div class="skill-icon" data-skill-name="${skill.name}" data-skill-desc="${skill.description}">
                                ${skill.icon}
                            </div>
                        `).join('')}
                    </div>
                ` : ''}
                <div class="companion-actions">
                    <button class="companion-btn train-btn">
                        <span class="btn-icon">📈</span>
                        培养
                    </button>
                    <button class="companion-btn leave-btn">
                        <span class="btn-icon">🚪</span>
                        离去
                    </button>
                </div>
            `;
            
            // 添加卡片到列表
            companionsList.appendChild(card);

            // 为每个技能图标添加事件监听
            const skillIcons = card.querySelectorAll('.skill-icon');
            skillIcons.forEach(icon => {
                // 创建提示框元素
                const tooltip = document.createElement('div');
                tooltip.className = 'skill-tooltip';
                tooltip.innerHTML = `
                    <div class="skill-name">${icon.dataset.skillName}</div>
                    <div class="skill-desc">${icon.dataset.skillDesc}</div>
                `;
                icon.appendChild(tooltip);

                // 添加鼠标事件
                icon.addEventListener('mouseenter', (e) => {
                    tooltip.style.position = 'fixed';
                    tooltip.style.zIndex = '10000';
                    this.showSkillTooltip(e, tooltip);
                    tooltip.style.opacity = '1';
                    tooltip.style.visibility = 'visible';
                });

                icon.addEventListener('mousemove', (e) => {
                    this.showSkillTooltip(e, tooltip);
                });

                icon.addEventListener('mouseleave', () => {
                    tooltip.style.opacity = '0';
                    tooltip.style.visibility = 'hidden';
                });
            });

            // 添加点击事件切换队伍状态
            card.onclick = (e) => {
                // 如果点击的是按钮，不触发队伍切换
                if (e.target.closest('.companion-btn')) return;
                
                const isInTeam = card.dataset.inTeam === 'true';
                
                if (isInTeam) {
                    // 如果已在队伍中，移除
                    if (this.removeTeamMember(companion.id)) {
                        card.classList.remove('selected');
                        card.dataset.inTeam = 'false';
                        gameManager.showFloatingTip(`${companion.name} 已离开队伍`, 'info');
                    }
                } else {
                    // 如果不在队伍中，尝试添加
                    if (this.currentTeam.length >= this.maxTeamSize - 1) {
                        gameManager.showFloatingTip('队伍已满！', 'error');
                        return;
                    }
                    
                    if (this.addTeamMember(companion.id)) {
                        card.classList.add('selected');
                        card.dataset.inTeam = 'true';
                        gameManager.showFloatingTip(`${companion.name} 已加入队伍`, 'success');
                    }
                }
                
                this.updateTeamDisplay();
            };

            // 添加培养按钮事件
            const trainBtn = card.querySelector('.train-btn');
            trainBtn.onclick = (e) => {
                e.stopPropagation();
                this.showTrainingDialog(companion);
            };

            // 添加离去按钮事件
            const leaveBtn = card.querySelector('.leave-btn');
            leaveBtn.onclick = (e) => {
                e.stopPropagation(); // 阻止事件冒泡
                this.showLeaveConfirmDialog(companion);
            };
        });

        // 更新伙伴数量显示
        const companionCount = document.querySelector('.companion-count');
        if (companionCount) {
            companionCount.textContent = `${this.companions.length}/${this.maxCompanions}`;
        }
    }

    // 初始化队伍系统
    initialize() {
        this.setupEventListeners();
    }

    // 添加新方法用于初始化显示
    initializeDisplay() {
        const player = gameManager.currentPlayer;
        if (!player) {
            console.error('No player found');
            return;
        }

        if (!player.teamData) {
            player.teamData = {
                companions: [],
                currentTeam: [],
                maxTeamSize: this.maxTeamSize,
                maxCompanions: this.maxCompanions
            };
        }

        this.companions = player.teamData.companions;
        this.currentTeam = player.teamData.currentTeam;

        this.updateTeamDisplay();
        this.updateCompanionsDisplay();
    }

    // 添加队员
    addTeamMember(companionId) {
        const player = gameManager.currentPlayer;
        if (!player || !player.teamData) return false;

        // 检查队伍是否已满(不包括队长位置)
        if (player.teamData.currentTeam.length >= this.maxTeamSize - 1) {
            gameManager.showFloatingTip('队伍已满！', 'error');
            return false;
        }

        const companion = player.teamData.companions.find(c => c.id === companionId);
        if (!companion) return false;

        // 添加到第一个空位置
        for (let i = 1; i < this.maxTeamSize; i++) {
            if (!player.teamData.currentTeam[i - 1]) {
                this.setTeamMember(companionId, i, player);
                this.updateTeamDisplay();
                return true;
            }
        }

        return false;
    }

    // 移除队员
    removeTeamMember(companionId) {
        // 从队伍中移除
        const index = this.currentTeam.indexOf(companionId);
        if (index !== -1) {
            this.currentTeam.splice(index, 1);
            
            // 获取伙伴数据
            const companion = this.companions.find(c => c.id === companionId);
            if (companion) {
                companion.isTeamMember = false; // 移除入队标识
            }

            // 保存角色数据
            if (gameManager.currentPlayer) {
                gameManager.currentPlayer.teamData = {
                    companions: this.companions,
                    currentTeam: this.currentTeam,
                    maxTeamSize: this.maxTeamSize,
                    maxCompanions: this.maxCompanions
                };
                saveCharacter(gameManager.currentPlayer);
            }

            // 更新显示
            this.updateTeamDisplay();
            return true;
        }
        return false;
    }

    // 更新队伍显示
    updateTeamDisplay() {
        const teamMembers = document.querySelector('.team-members');
        if (!teamMembers) return;

        const player = gameManager.currentPlayer;
        if (!player || !player.teamData) return;

        // 更新队伍人数显示
        const teamCount = document.querySelector('.team-count');
        if (teamCount) {
            // 计算当前队伍人数（包括队长）
            const currentTeamSize = 1 + (player.teamData.currentTeam?.length || 0); // 1是队长
            teamCount.textContent = `${currentTeamSize}/${this.maxTeamSize}`;
        }

        teamMembers.innerHTML = '';

        // 第一个位置显示玩家(队长)
        teamMembers.innerHTML += `
            <div class="team-slot player-slot occupied" data-position="0">
                <div class="player-marker">队长</div>
                <div class="companion-avatar" style="border-color: #ffd700">
                    ${Character.getClassIcon(player.class)}
                </div>
                <div class="companion-info">
                    <div class="companion-name">${player.name}</div>
                    <div class="companion-class">Lv.${player.level} ${this.getClassName(player.class)}</div>
                </div>
            </div>
        `;

        // 显示其他队伍位置(从索引1开始)
        for (let i = 1; i < this.maxTeamSize; i++) {
            const companionId = player.teamData.currentTeam[i - 1]; // 因为数组从0开始,所以要减1
            const companion = companionId ? 
                player.teamData.companions.find(c => c.id === companionId) : 
                null;

            teamMembers.innerHTML += `
                <div class="team-slot ${companion ? 'occupied' : ''}" data-position="${i}">
                    ${companion ? `
                        <div class="companion-avatar" style="border-color: ${this.QUALITY_CONFIG[companion.quality].color}">
                            ${companion.icon}
                        </div>
                        <div class="companion-info">
                            <div class="companion-name">${companion.name}</div>
                            <div class="companion-class">Lv.${companion.level} ${this.getClassName(companion.class)}</div>
                        </div>
                    ` : `
                        <div class="slot-icon">👥</div>
                        <div class="slot-name">空位 ${i}</div>
                    `}
                </div>
            `;
        }

        // 添加队伍槽位点击事件
        this.setupTeamSlotEvents();
    }

    // 修改队伍槽位事件设置
    setupTeamSlotEvents() {
        const teamSlots = document.querySelectorAll('.team-slot');
        teamSlots.forEach(slot => {
            slot.onclick = () => {
                const position = parseInt(slot.dataset.position);
                
                // 不允许点击队长位置
                if (position === 0) return;
                
                // 如果槽位有伙伴，则移除
                if (slot.classList.contains('occupied')) {
                    const companionId = this.currentTeam[position - 1];
                    if (companionId) {
                        // 移除队伍成员
                        this.removeTeamMember(companionId);
                        
                        // 更新伙伴卡片状态
                        const companionCard = document.querySelector(`.companion-card[data-companion-id="${companionId}"]`);
                        if (companionCard) {
                            companionCard.classList.remove('selected');
                            companionCard.dataset.inTeam = 'false';
                        }
                        
                        // 获取伙伴数据显示提示
                        const companion = this.companions.find(c => c.id === companionId);
                        if (companion) {
                            gameManager.showFloatingTip(`${companion.name} 已离开队伍`, 'info');
                        }
                    }
                }
            };
        });
    }

    // 设置事件监听
    setupEventListeners() {
        // 招募按钮点击事件
        const recruitBtn = document.querySelector('.recruit-btn');
        if (recruitBtn) {
            recruitBtn.onclick = () => this.showRecruitDialog();
        }
    }

    // 修改显示招募对话框方法
    showRecruitDialog() {
        const player = gameManager.currentPlayer;
        if (!player) {
            console.error('No player found');
            return;
        }

        // 初始化玩家伙伴数据
        if (!player.teamData) {
            this.initializePlayerData(player);
        }

        const dialog = document.createElement('div');
        dialog.className = 'recruit-dialog';
        
        // 更新对话框内容的函数
        const updateDialogContent = () => {
            dialog.innerHTML = `
                <div class="recruit-dialog-content">
                    <div class="panel-header">
                        <h3>招募伙伴</h3>
                        <button class="close-panel-btn">×</button>
                    </div>
                    <div class="panel-content">
                        <div class="recruit-header">
                            <div class="player-gold">
                                <span class="gold-icon">💰</span>
                                <span class="gold-amount">${gameManager.currentPlayer.gold || 0} 金币</span>
                            </div>
                            <button class="refresh-btn">
                                <span class="refresh-icon">🔄</span>
                                刷新候选 (${this.getCurrentRefreshCost()} 金币)
                            </button>
                        </div>
                        <div class="npc-list">
                            ${this.recruitableNPCs.map(npc => {
                                const qualityConfig = this.QUALITY_CONFIG[npc.quality];
                                return `
                                    <div class="npc-card" data-npc-id="${npc.id}" data-quality="${npc.quality}">
                                        <div class="npc-avatar" style="border: 2px solid ${qualityConfig.color}">
                                            ${npc.icon}
                                        </div>
                                        <div class="npc-info">
                                            <div class="npc-name">
                                                ${npc.name}
                                                <span class="quality-badge" style="background: ${qualityConfig.color}">
                                                    ${qualityConfig.name}
                                                </span>
                                            </div>
                                            <div class="npc-class">
                                                ${this.getClassName(npc.class)} Lv.${npc.level}
                                            </div>
                                            <div class="npc-description">${npc.description}</div>
                                        </div>
                                        ${npc.skills.length > 0 ? `
                                            <div class="companion-skills">
                                                ${npc.skills.map(skill => `
                                                    <span class="skill-icon" title="${skill.name}">
                                                        ${skill.icon}
                                                        <div class="skill-tooltip">
                                                            <div class="skill-name">${skill.name}</div>
                                                            <div class="skill-desc">${skill.description}</div>
                                                        </div>
                                                    </span>
                                                `).join('')}
                                            </div>
                                        ` : ''}
                                        <div class="npc-cost">
                                            <span class="gold-icon">💰</span>
                                            ${this.QUALITY_COST[npc.quality]} 金币
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                </div>
            `;

            // 重新添加事件监听
            setupEventListeners();
        };

        // 设置事件监听的函数
        const setupEventListeners = () => {
            // 添加刷新按钮事件
            const refreshBtn = dialog.querySelector('.refresh-btn');
            if (refreshBtn) {
                refreshBtn.onclick = () => {
                    const refreshCost = this.getCurrentRefreshCost();
                    if (gameManager.currentPlayer.gold >= refreshCost) {
                        gameManager.currentPlayer.gold -= refreshCost;
                        this.refreshCount++;
                        this.refreshRecruitableNPCs();
                        updateDialogContent(); // 更新对话框内容
                        gameManager.showFloatingTip('刷新成功！', 'success');
                    } else {
                        gameManager.showFloatingTip('金币不足！', 'error');
                    }
                };
            }

            // 修改 NPC 卡片点击事件
            const npcCards = dialog.querySelectorAll('.npc-card');
            npcCards.forEach(card => {
                card.onclick = () => {
                    const npcId = card.dataset.npcId;
                    const npc = this.recruitableNPCs.find(n => n.id === npcId);
                    if (!npc) return;

                    const cost = this.QUALITY_COST[npc.quality];
                    if (player.gold >= cost) {
                        // 扣除金币
                        player.gold -= cost;
                        
                        // 招募伙伴
                        const result = this.recruitCompanion(npc, gameManager.currentPlayer);
                        if (result) {
                            // 从可招募列表中移除该 NPC
                            this.recruitableNPCs = this.recruitableNPCs.filter(n => n.id !== npcId);
                            
                            // 生成一个新的 NPC 补充
                            const newNpc = this.generateSingleNPC();
                            this.recruitableNPCs.push(newNpc);
                            
                            // 更新招募界面显示
                            updateDialogContent();
                            
                            // 更新伙伴列表显示
                            this.updateCompanionsDisplay();
                            
                            gameManager.showFloatingTip(`成功招募 ${npc.name}！`, 'success');
                        }
                    } else {
                        gameManager.showFloatingTip('金币不足！', 'error');
                    }
                };
            });

            // 添加关闭按钮事件
            const closeBtn = dialog.querySelector('.close-panel-btn');
            if (closeBtn) {
                closeBtn.onclick = () => {
                    document.body.removeChild(dialog);
                };
            }

            // 添加技能图标的鼠标事件监听
            const skillIcons = dialog.querySelectorAll('.skill-icon');
            skillIcons.forEach(icon => {
                const tooltip = icon.querySelector('.skill-tooltip');
                
                icon.addEventListener('mouseenter', (e) => {
                    if (tooltip) {
                        tooltip.style.position = 'fixed';
                        tooltip.style.zIndex = '10000';
                        this.showSkillTooltip(e, tooltip);
                        tooltip.style.opacity = '1';
                        tooltip.style.visibility = 'visible';
                    }
                });

                icon.addEventListener('mousemove', (e) => {
                    if (tooltip) {
                        this.showSkillTooltip(e, tooltip);
                    }
                });
                
                icon.addEventListener('mouseleave', () => {
                    if (tooltip) {
                        tooltip.style.opacity = '0';
                        tooltip.style.visibility = 'hidden';
                    }
                });
            });
        };

        // 初始化对话框内容
        updateDialogContent();
        document.body.appendChild(dialog);
    }

    // 刷新可招募的NPC列表
    refreshRecruitableNPCs() {
        this.recruitableNPCs = [];
        const classes = ['warrior', 'mage', 'monk', 'taoist'];
        
        // 生成3-5个可招募NPC
        const count = Math.floor(Math.random() * 3) + 3;
        
        for (let i = 0; i < count; i++) {
            const characterClass = classes[Math.floor(Math.random() * classes.length)];
            const quality = this.generateRandomQuality();
            const skills = this.getRandomSkills(characterClass, quality);
            
            const npc = {
                id: `npc_${Date.now()}_${i}`,
                name: this.generateRandomName(),
                class: characterClass,
                level: 1,
                quality: quality,
                icon: Character.getClassIcon(characterClass),
                description: Character.getClassDescription(characterClass),
                skills: skills,
                cost: this.QUALITY_COST[quality]
            };
            
            this.recruitableNPCs.push(npc);
        }
    }

    // 生成随机NPC
    generateRandomNPC() {
        const classes = ['warrior', 'mage', 'monk', 'taoist'];
        const randomClass = classes[Math.floor(Math.random() * classes.length)];
        const quality = this.generateRandomQuality();
        const icons = {
            warrior: '⚔️',
            mage: '🔮',
            monk: '🥋',
            taoist: '☯️'
        };

        // 随机选择技能
        const skills = this.getRandomSkills(randomClass, quality);

        return {
            id: 'npc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
            name: this.generateRandomName(),
            class: randomClass,
            level: 1,
            quality: quality,
            icon: icons[randomClass],
            description: this.getRandomDescription(randomClass),
            skills: skills  // 添加技能列表
        };
    }

    // 取随机描述
    getRandomDescription(characterClass) {
        const descriptions = {
            warrior: [
                '身经百战的战士，擅长近身搏斗。',
                '铁血战士，为荣誉而战。',
                '沙场老将，经验丰富。'
            ],
            mage: [
                '精通法术的智者，掌握强大魔法。',
                '神秘的魔法师，操控元素之力。',
                '博学多才的法师，精通各类法术。'
            ],
            monk: [
                '修炼多年的武僧，身手敏捷。',
                '武艺高强的武者，擅长格斗技巧。',
                '追求武道极致的武者。'
            ],
            taoist: [
                '修真得道的方士，精通符咒。',
                '游历四方的道士，法力高深。',
                '潜心修炼的道士，道法自然。'
            ]
        };

        const descList = descriptions[characterClass];
        return descList[Math.floor(Math.random() * descList.length)];
    }

    // 计算当前刷新费用
    getCurrentRefreshCost() {
        return this.REFRESH_COST * Math.pow(1.5, this.refreshCount);
    }

    // 获取职业中文名称
    getClassName(characterClass) {
        const classNames = {
            mage: '法师',
            warrior: '战士',
            monk: '武者',
            taoist: '道士'
        };
        return classNames[characterClass] || characterClass;
    }

    // 在TeamSystem类中修改显示离去确认对话框的方法
    showLeaveConfirmDialog(companion) {
        const dialog = document.createElement('div');
        dialog.className = 'leave-confirm-dialog';
        const qualityConfig = this.QUALITY_CONFIG[companion.quality];
        
        dialog.innerHTML = `
            <div class="leave-confirm-content">
                <div class="leave-confirm-header">
                    <h3>伙伴离去</h3>
                    <button class="close-dialog-btn">×</button>
                </div>
                <div class="leave-confirm-body">
                    <div class="companion-preview">
                        <div class="companion-avatar" style="border: 2px solid ${qualityConfig.color}">
                            ${companion.icon}
                        </div>
                        <div class="companion-info">
                            <div class="companion-name-row">
                                <span class="companion-name">${companion.name}</span>
                                <span class="quality-badge" style="background: ${qualityConfig.color}">
                                    ${qualityConfig.name}
                                </span>
                            </div>
                            <div class="companion-class">
                                ${this.getClassName(companion.class)} Lv.${companion.level}
                            </div>
                        </div>
                    </div>
                    <div class="leave-message">
                        <p>确定要让 <span class="highlight">${companion.name}</span> 离开队伍吗？</p>
                        <p class="warning">注意：离去后将无法恢复！</p>
                    </div>
                </div>
                <div class="leave-confirm-buttons">
                    <button class="confirm-btn confirm-leave">
                        <span class="btn-icon">🚪</span>
                        确认离去
                    </button>
                    <button class="confirm-btn cancel-leave">
                        <span class="btn-icon">✖️</span>
                        取消
                    </button>
                </div>
            </div>
        `;

        // 添加关闭按钮事件
        const closeBtn = dialog.querySelector('.close-dialog-btn');
        const cancelBtn = dialog.querySelector('.cancel-leave');
        const confirmBtn = dialog.querySelector('.confirm-leave');

        const closeDialog = () => {
            dialog.classList.add('fade-out');
            setTimeout(() => document.body.removeChild(dialog), 300);
        };

        closeBtn.onclick = closeDialog;
        cancelBtn.onclick = closeDialog;

        confirmBtn.onclick = () => {
            // 如果伙伴在队伍中，先移除
            if (this.currentTeam.includes(companion)) {
                this.removeTeamMember(companion.id);
            }
            // 从伙伴列表中移除
            this.companions = this.companions.filter(c => c.id !== companion.id);
            this.updateCompanionsDisplay();
            gameManager.showFloatingTip(`${companion.name} 已离队伍`, 'info');
            closeDialog();
        };

        document.body.appendChild(dialog);
        // 添加淡入效果
        setTimeout(() => dialog.classList.add('show'), 10);
    }

    // 计算升级所需金币
    calculateLevelUpCost(companion) {
        const baseGold = 100; // 基础金币消耗
        const qualityMultiplier = {
            NORMAL: 1,
            RARE: 1.5,
            EPIC: 2,
            LEGENDARY: 3,
            MYTHIC: 5
        };
        return Math.floor(baseGold * companion.level * qualityMultiplier[companion.quality]);
    }

    // 修改计算下一级属性的方法
    calculateNextLevelStats(companion) {
        if (!companion || !companion.class || !companion.quality) {
            console.error('Invalid companion data:', companion);
            return null;
        }

        // 获取职业成长配置
        const classGrowth = this.CLASS_GROWTH[companion.class][companion.quality];
        if (!classGrowth) {
            console.error('Growth data not found for:', companion.class, companion.quality);
            return null;
        }

        const currentLevel = companion.level;
        const nextLevel = currentLevel + 1;

        // 计算当前等级属性
        const current = {
            strength: Math.floor(classGrowth.strength.base + classGrowth.strength.growth * (currentLevel - 1)),
            constitution: Math.floor(classGrowth.constitution.base + classGrowth.constitution.growth * (currentLevel - 1)),
            agility: Math.floor(classGrowth.agility.base + classGrowth.agility.growth * (currentLevel - 1)),
            wisdom: Math.floor(classGrowth.wisdom.base + classGrowth.wisdom.growth * (currentLevel - 1)),
            speed: Math.floor(classGrowth.speed.base + classGrowth.speed.growth * (currentLevel - 1))
        };

        // 计算下一级属性
        const next = {
            strength: Math.floor(classGrowth.strength.base + classGrowth.strength.growth * (nextLevel - 1)),
            constitution: Math.floor(classGrowth.constitution.base + classGrowth.constitution.growth * (nextLevel - 1)),
            agility: Math.floor(classGrowth.agility.base + classGrowth.agility.growth * (nextLevel - 1)),
            wisdom: Math.floor(classGrowth.wisdom.base + classGrowth.wisdom.growth * (nextLevel - 1)),
            speed: Math.floor(classGrowth.speed.base + classGrowth.speed.growth * (nextLevel - 1))
        };

        // 返回成长数据
        return {
            current: current,
            next: next,
            growth: {
                strength: classGrowth.strength.growth,
                constitution: classGrowth.constitution.growth,
                agility: classGrowth.agility.growth,
                wisdom: classGrowth.wisdom.growth,
                speed: classGrowth.speed.growth
            }
        };
    }

    // 在 TeamSystem 类中添加伙伴属性计算方法
    calculateCompanionStats(data) {
        const { class: characterClass, quality, level, growth } = data;
        
        // 获取基础成长数据
        const baseGrowth = this.CLASS_GROWTH[characterClass][quality];
        
        // 计算等级差
        const levelDiff = level - 1;
        
        // 计算当前属性
        const currentStats = {
            strength: Math.floor(baseGrowth.strength.base + baseGrowth.strength.growth * levelDiff),
            constitution: Math.floor(baseGrowth.constitution.base + baseGrowth.constitution.growth * levelDiff),
            agility: Math.floor(baseGrowth.agility.base + baseGrowth.agility.growth * levelDiff),
            wisdom: Math.floor(baseGrowth.wisdom.base + baseGrowth.wisdom.growth * levelDiff),
            speed: Math.floor(baseGrowth.speed.base + baseGrowth.speed.growth * levelDiff)
        };

        // 计算衍生属性
        return {
            hp: 100 + Math.floor(currentStats.constitution * 5),
            maxHp: 100 + Math.floor(currentStats.constitution * 5),
            mp: 100 + Math.floor(currentStats.wisdom * 3),
            maxMp: 100 + Math.floor(currentStats.wisdom * 3),
            attack: 10 + Math.floor(currentStats.strength * 1.5),
            defense: 10 + Math.floor(currentStats.constitution * 1.2),
            hit: Math.floor(currentStats.wisdom * 1.3),
            dodge: Math.floor(currentStats.agility * 1.2),
            crit: Math.floor(currentStats.agility * 0.5),
            critDmg: 150 + Math.floor(currentStats.strength * 0.8),
            drain: Math.floor(currentStats.wisdom * 0.3),
            speed: currentStats.speed
        };
    }

    // 修改显示培养界面的方法
    showTrainingDialog(companion) {
        const dialog = document.createElement('div');
        dialog.className = 'training-dialog';
        const qualityConfig = this.QUALITY_CONFIG[companion.quality];
        const stats = this.calculateNextLevelStats(companion);
        const currentStats = this.calculateCompanionStats(companion);
        const levelUpCost = this.calculateLevelUpCost(companion);
        
        dialog.innerHTML = `
            <div class="training-dialog-content">
                <div class="panel-header">
                    <h3>伙伴培养</h3>
                    <button class="close-panel-btn">×</button>
                </div>
                <div class="panel-content">
                    <div class="companion-preview">
                        <div class="companion-avatar" style="border: 2px solid ${qualityConfig.color}">
                            ${companion.icon}
                        </div>
                        <div class="companion-info">
                            <div class="companion-name-row">
                                <span class="companion-name">${companion.name}</span>
                                <span class="quality-badge" style="background: ${qualityConfig.color}">
                                    ${qualityConfig.name}
                                </span>
                            </div>
                            <div class="companion-class">
                                ${this.getClassName(companion.class)} Lv.${companion.level}
                            </div>
                        </div>
                    </div>

                    <!-- 添加状态条 -->
                    <div class="companion-status-bars">
                        <div class="status-bar">
                            <div class="status-label">
                                <span>生命值</span>
                                <span class="status-value">${currentStats.hp}/${currentStats.maxHp}</span>
                            </div>
                            <div class="status-progress">
                                <div class="status-fill hp-fill" style="width: ${(currentStats.hp/currentStats.maxHp)*100}%"></div>
                            </div>
                        </div>
                        <div class="status-bar">
                            <div class="status-label">
                                <span>法力值</span>
                                <span class="status-value">${currentStats.mp}/${currentStats.maxMp}</span>
                            </div>
                            <div class="status-progress">
                                <div class="status-fill mp-fill" style="width: ${(currentStats.mp/currentStats.maxMp)*100}%"></div>
                            </div>
                        </div>
                    </div>

                    <!-- 添加战斗属性 -->
                    <div class="companion-combat-stats">
                        <div class="stats-grid">
                            <div class="team-stat-item">
                                <span class="stat-label">攻击力</span>
                                <span class="stat-value">${currentStats.attack}</span>
                            </div>
                            <div class="team-stat-item">
                                <span class="stat-label">防御力</span>
                                <span class="stat-value">${currentStats.defense}</span>
                            </div>
                            <div class="team-stat-item">
                                <span class="stat-label">命中</span>
                                <span class="stat-value">${currentStats.hit}</span>
                            </div>
                            <div class="team-stat-item">
                                <span class="stat-label">闪避</span>
                                <span class="stat-value">${currentStats.dodge}%</span>
                            </div>
                            <div class="team-stat-item">
                                <span class="stat-label">暴击</span>
                                <span class="stat-value">${currentStats.crit}%</span>
                            </div>
                            <div class="team-stat-item">
                                <span class="stat-label">暴伤</span>
                                <span class="stat-value">${currentStats.critDmg}%</span>
                            </div>
                        </div>
                    </div>

                    <div class="training-stats">
                        <div class="stats-header">
                            <div class="stat-col">属性</div>
                            <div class="stat-col">当前</div>
                            <div class="stat-col next-level">下一级</div>
                            <div class="stat-col">成长</div>
                        </div>
                        ${this.generateStatsRows(stats)}
                    </div>
                </div>

                <!-- 新增固定底部区域 -->
                <div class="dialog-footer">
                    <div class="training-cost">
                        <div class="cost-info">
                            <span class="gold-icon">💰</span>
                            升级消耗: ${levelUpCost} 金币
                        </div>
                        <div class="player-gold">
                            <span class="gold-icon">💰</span>
                            拥有: ${gameManager.currentPlayer.gold || 0} 金币
                        </div>
                    </div>

                    <button class="level-up-btn" ${gameManager.currentPlayer.gold < levelUpCost ? 'disabled' : ''}>
                        <span class="btn-icon">⬆️</span>
                        升级 (${levelUpCost} 金币)
                    </button>
                </div>
            </div>
        `;

        // 添加事件监听
        const closeBtn = dialog.querySelector('.close-panel-btn');
        const levelUpBtn = dialog.querySelector('.level-up-btn');

        closeBtn.onclick = () => {
            dialog.classList.add('fade-out');
            setTimeout(() => document.body.removeChild(dialog), 300);
        };

        levelUpBtn.onclick = () => {
            if (gameManager.currentPlayer.gold >= levelUpCost) {
                // 扣除金币
                gameManager.currentPlayer.gold -= levelUpCost;
                // 升级伙伴
                companion.level++;
                // 更新显示
                this.updateCompanionsDisplay();
                // 关闭对话框并重新打开(显示新的属性)
                document.body.removeChild(dialog);
                this.showTrainingDialog(companion);
                // 显示成功提示
                gameManager.showFloatingTip(`${companion.name} 升级成功！`, 'success');
            } else {
                gameManager.showFloatingTip('金币不足！', 'error');
            }
        };

        document.body.appendChild(dialog);
        setTimeout(() => dialog.classList.add('show'), 10);
    }

    // 生成属性行HTML
    generateStatsRows(stats) {
        const attributes = [
            { key: 'strength', name: '力道' },
            { key: 'constitution', name: '根骨' },
            { key: 'agility', name: '身法' },
            { key: 'wisdom', name: '悟性' },
            { key: 'speed', name: '速度' }
        ];

        return attributes.map(attr => `
            <div class="stat-row">
                <div class="stat-col">${attr.name}</div>
                <div class="stat-col">${stats.current[attr.key]}</div>
                <div class="stat-col next-level">
                    ${stats.next[attr.key]}
                    <span class="stat-increase">+${stats.next[attr.key] - stats.current[attr.key]}</span>
                </div>
                <div class="stat-col">+${stats.growth[attr.key].toFixed(1)}</div>
            </div>
        `).join('');
    }

    // 随机选择技能
    getRandomSkills(characterClass, quality) {
        const skillPool = this.SKILL_POOLS[characterClass];
        if (!skillPool) return [];

        const { min, max } = this.QUALITY_SKILLS[quality];
        const numSkills = Math.floor(Math.random() * (max - min + 1)) + min;
        
        // 随机打乱技能池并选择指定数量的技能
        return [...skillPool]
            .sort(() => Math.random() - 0.5)
            .slice(0, numSkills);
    }

    // 在TeamSystem类中添加鼠标跟随提示框方法
    showSkillTooltip(e, tooltip) {
        if (!tooltip) return;

        // 获取鼠标位置
        const x = e.clientX;
        const y = e.clientY;
        
        // 获取视窗尺寸
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        // 设置提示框样式
        tooltip.style.position = 'fixed';
        tooltip.style.zIndex = '10000';
        tooltip.style.visibility = 'visible';
        tooltip.style.opacity = '1';

        // 获取提示框尺寸
        const tooltipRect = tooltip.getBoundingClientRect();
        
        // 计算位置，避免超出视窗
        let left = x + 10; // 默认在鼠标右侧10px
        let top = y + 10;  // 默认在鼠标下方10px

        // 如果会超出右边界，则显示在左侧
        if (left + tooltipRect.width > viewportWidth) {
            left = x - tooltipRect.width - 10;
        }

        // 如果会超出下边界，则显示在上方
        if (top + tooltipRect.height > viewportHeight) {
            top = y - tooltipRect.height - 10;
        }

        // 设置最终位置
        tooltip.style.left = `${left}px`;
        tooltip.style.top = `${top}px`;
    }

    // 修改生成技能图标的HTML
    generateSkillIcon(skill) {
        return `
            <span class="skill-icon">
                ${skill.icon}
                <div class="skill-tooltip">
                    <div class="skill-name">${skill.name}</div>
                    <div class="skill-desc">${skill.description}</div>
                </div>
            </span>
        `;
    }

    // 添加生成单个 NPC 的方法
    generateSingleNPC() {
        const classes = ['warrior', 'mage', 'monk', 'taoist'];
        const characterClass = classes[Math.floor(Math.random() * classes.length)];
        const quality = this.generateRandomQuality();
        const skills = this.getRandomSkills(characterClass, quality);
        
        return {
            id: `npc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: this.generateRandomName(),
            class: characterClass,
            level: 1,
            quality: quality,
            icon: Character.getClassIcon(characterClass),
            description: Character.getClassDescription(characterClass),
            skills: skills,
            cost: this.QUALITY_COST[quality]
        };
    }

    // 修改 setupCompanionEvents 方法
    setupCompanionEvents() {
        const companionsList = document.querySelector('.companions-list');
        if (!companionsList) return;

        companionsList.addEventListener('click', (e) => {
            const companionCard = e.target.closest('.companion-card');
            if (!companionCard) return;

            const companionId = companionCard.dataset.id;
            const companion = this.companions.find(c => c.id === companionId);
            
            if (!companion) return;

            // 检查该伙伴是否已在队伍中
            const isInTeam = this.currentTeam.includes(companionId);
            
            if (isInTeam) {
                // 如果已在队伍中,则移除
                this.removeFromTeam(companionId);
                companionCard.classList.remove('selected');
                gameManager.showFloatingTip(`${companion.name} 已离开队伍`, 'info');
            } else {
                // 检查队伍是否已满
                if (this.currentTeam.length >= this.maxTeamSize) {
                    gameManager.showFloatingTip('队伍已满!', 'error');
                    return;
                }
                
                // 添加到队伍
                this.addToTeam(companionId);
                companionCard.classList.add('selected');
                gameManager.showFloatingTip(`${companion.name} 已加入队伍`, 'success');
            }

            // 更新显示
            this.updateTeamDisplay();
        });
    }

    // 添加检查重复伙伴的方法
    checkDuplicateCompanion(companion) {
        return this.currentTeam.some(memberId => {
            const member = this.companions.find(c => c.id === memberId);
            return member && member.id === companion.id;
        });
    }

    // 修改 addToTeam 方法
    addToTeam(companionId) {
        // 检查是否已在队伍中
        if (this.currentTeam.includes(companionId)) {
            return false;
        }
        
        // 检查队伍是否已满
        if (this.currentTeam.length >= this.maxTeamSize) {
            return false;
        }

        // 获取伙伴数据
        const companion = this.companions.find(c => c.id === companionId);
        if (!companion) return false;

        // 检查是否重复添加
        if (this.checkDuplicateCompanion(companion)) {
            return false;
        }

        // 添加到队伍
        this.currentTeam.push(companionId);
        
        // 保存角色数据
        if (gameManager.currentPlayer) {
            gameManager.currentPlayer.teamData = {
                companions: this.companions,
                currentTeam: this.currentTeam,
                maxTeamSize: this.maxTeamSize,
                maxCompanions: this.maxCompanions
            };
            saveCharacter(gameManager.currentPlayer);
        }

        return true;
    }
}

// 创建全局队伍系统实例
const teamSystem = new TeamSystem();

// 当页面加载完成后初始化队伍系统
document.addEventListener('DOMContentLoaded', () => {
    teamSystem.initialize();
}); 