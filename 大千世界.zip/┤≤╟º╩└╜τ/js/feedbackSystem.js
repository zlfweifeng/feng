class FeedbackSystem {
    constructor() {
        this.feedbackTypes = {
            suggestion: {
                icon: '💡',
                name: '建议',
                placeholder: '请详细描述您的建议...'
            },
            bug: {
                icon: '🐛',
                name: 'BUG反馈',
                placeholder: '请描述BUG出现的步骤和现象...'
            }
        };
    }

    showFeedbackDialog() {
        const dialog = document.createElement('div');
        dialog.className = 'feedback-dialog';
        
        dialog.innerHTML = `
            <div class="feedback-content">
                <div class="dialog-header">
                    <h3>反馈建议</h3>
                    <button class="close-dialog-btn">×</button>
                </div>
                <div class="dialog-body">
                    <div class="feedback-type-selector">
                        <button class="type-btn active" data-type="suggestion">
                            <span class="type-icon">💡</span>
                            <span class="type-text">建议</span>
                        </button>
                        <button class="type-btn" data-type="bug">
                            <span class="type-icon">🐛</span>
                            <span class="type-text">BUG反馈</span>
                        </button>
                    </div>
                    
                    <div class="feedback-form">
                        <div class="form-group">
                            <label>标题</label>
                            <input type="text" class="feedback-title" placeholder="请输入标题">
                        </div>
                        <div class="form-group">
                            <label>详细内容</label>
                            <textarea class="feedback-content" rows="6" placeholder="请详细描述您的建议..."></textarea>
                        </div>
                        <div class="form-group">
                            <label>联系方式（选填）</label>
                            <input type="text" class="feedback-contact" placeholder="QQ/微信/邮箱，方便我们联系您">
                        </div>
                    </div>

                    <div class="feedback-actions">
                        <button class="submit-btn">
                            <span class="btn-icon">📤</span>
                            提交反馈
                        </button>
                    </div>
                </div>
            </div>
        `;

        // 添加关闭按钮事件
        const closeBtn = dialog.querySelector('.close-dialog-btn');
        closeBtn.onclick = () => {
            dialog.classList.add('fade-out');
            setTimeout(() => {
                document.body.removeChild(dialog);
            }, 300);
        };

        // 添加类型切换事件
        const typeBtns = dialog.querySelectorAll('.type-btn');
        const textarea = dialog.querySelector('.feedback-content');
        typeBtns.forEach(btn => {
            btn.onclick = () => {
                // 更新按钮状态
                typeBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                // 更新文本框提示
                const type = btn.dataset.type;
                textarea.placeholder = this.feedbackTypes[type].placeholder;
            };
        });

        // 添加提交事件
        const submitBtn = dialog.querySelector('.submit-btn');
        submitBtn.onclick = () => {
            this.submitFeedback(dialog);
        };

        document.body.appendChild(dialog);
        setTimeout(() => dialog.classList.add('show'), 10);
    }

    submitFeedback(dialog) {
        // 获取表单元素
        const titleInput = dialog.querySelector('.feedback-title');
        const contentTextarea = dialog.querySelector('textarea.feedback-content');
        const contactInput = dialog.querySelector('.feedback-contact');
        const typeBtn = dialog.querySelector('.type-btn.active');

        // 检查元素是否存在
        if (!titleInput || !contentTextarea || !contactInput || !typeBtn) {
            console.error('找不到必要的表单元素');
            gameManager.showFloatingTip('提交失败：表单元素缺失', 'error');
            return;
        }

        // 获取表单值
        const title = titleInput.value.trim();
        const content = contentTextarea.value.trim();
        const contact = contactInput.value.trim();
        const type = typeBtn.dataset.type;

        // 验证输入
        if (!title) {
            gameManager.showFloatingTip('请输入标题！', 'error');
            return;
        }
        if (!content) {
            gameManager.showFloatingTip('请输入详细内容！', 'error');
            return;
        }

        // 显示提交中状态
        const submitBtn = dialog.querySelector('.submit-btn');
        const originalBtnText = submitBtn.innerHTML;
        submitBtn.innerHTML = `
            <span class="btn-icon">⏳</span>
            提交中...
        `;
        submitBtn.disabled = true;

        // 发送到服务器
        fetch('http://localhost:3000/api/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title,
                content,
                contact,
                type
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                gameManager.showFloatingTip('感谢您的反馈！', 'success');
                dialog.classList.add('fade-out');
                setTimeout(() => {
                    if (dialog.parentNode) {
                        dialog.parentNode.removeChild(dialog);
                    }
                }, 300);
            } else {
                throw new Error(data.message || '提交失败');
            }
        })
        .catch(error => {
            console.error('提交反馈失败:', error);
            gameManager.showFloatingTip(error.message || '提交失败，请稍后重试', 'error');
            // 恢复按钮状态
            submitBtn.innerHTML = originalBtnText;
            submitBtn.disabled = false;
        });
    }
}

// 创建全局实例
const feedbackSystem = new FeedbackSystem(); 