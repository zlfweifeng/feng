class UpdateLogSystem {
    constructor() {
        this.updateLogs = [
            {
                version: "1.2.1",
                date: "2024-11-07",
                type: "update",
                title: "系统优化更新",
                changes: [
                    {
                        category: "背包系统",
                        items: [
                            "扩充基础背包容量",
                            "修复批量出售物品显示不完整的问题"
                        ]
                    },
                    {
                        category: "战斗系统",
                        items: [
                            "新增战斗设置功能 设置里面打开",
                            "添加战斗物品过滤功能",
                            "优化物品掉落生成机制",
                            "修复了战斗结束不会恢复状态的问题",
                            "实装了群攻技能的效果",
                            "下调了新手区怪物属性"
                        ]
                    },
                    {
                        category: "商店系统",
                        items: [
                            "调整商店装备价格",
                            "提高高品质装备价值"
                        ]
                    }
                ]
            },
            {
                version: "1.2.0",
                date: "2024-11-06",
                type: "feature",
                title: "技能系统扩展",
                changes: [
                    {
                        category: "技能更新",
                        items: [
                            "新增高级技能",
                            "技能升级系统优化",
                            "技能效果强化",
                            "被动技能系统"
                        ]
                    },
                    {
                        category: "怪物系统",
                        items: [
                            "新增精英怪物类型",
                            "增加多个等级段的怪物",
                            "怪物掉落物品调整"
                        ]
                    },
                    {
                        category: "自动战斗",
                        items: [
                            "新增自动战斗功能",
                            "支持选择目标怪物自动战斗",
                            "开启后2秒自动进入战斗",
                            "战斗结束5秒后自动开始下一场战斗",
                            "可随时开启/关闭自动战斗",
                            "开启自动战斗时锁定怪物选择，关闭后解锁"
                        ]
                    },
                    {
                        category: "背包优化",
                        items: [
                            "新增批量出售功能",
                            "支持多选物品同时出售",
                            "优化背包界面布局",
                            "添加批量操作按钮"
                        ]
                    }
                ]
            },
            {
                version: "1.1.0",
                date: "2024-11-05",
                type: "feature",
                title: "商店系统更新",
                changes: [
                    {
                        category: "商店功能",
                        items: [
                            "装备商店系统",
                            "消耗品商店",
                            "特殊道具商店",
                            "商品刷新机制"
                        ]
                    }
                ]
            },
            {
                version: "1.0.0",
                date: "2024-11-04",
                type: "major",
                title: "游戏正式游玩",
                changes: [
                    {
                        category: "核心系统",
                        items: [
                            "角色创建系统",
                            "四大职业: 法师、战士、武者、道士",
                            "属性与技能系统",
                            "背包与装备系统",
                            "战斗系统"
                        ]
                    },
                    {
                        category: "战斗系统",
                        items: [
                            "回合制战斗机制",
                            "技能连击系统",
                            "暴击与闪避机制",
                            "战斗奖励系统"
                        ]
                    },
                    {
                        category: "装备系统",
                        items: [
                            "五种装备品质: 普通、稀有、史诗、传说、神话",
                            "装备强化系统",
                            "装备属性随机系统",
                            "套装效果系统"
                        ]
                    },
                    {
                        category: "伙伴系统",
                        items: [
                            "伙伴招募功能",
                            "伙伴培养系统",
                            "队伍编成系统",
                            "伙伴技能系统"
                        ]
                    },
                    {
                        category: "地图系统",
                        items: [
                            "多区域地图",
                            "节点移动系统",
                            "随机事件系统",
                            "地图探索奖励"
                        ]
                    }
                ]
            }
        ];
    }

    // 显示更新日志
    showUpdateLog() {
        const dialog = document.createElement('div');
        dialog.className = 'gx_update-log-dialog';
        
        dialog.innerHTML = `
            <div class="gx_update-log-content">
                <div class="panel-header">
                    <h3>更新公告</h3>
                    <button class="close-panel-btn">×</button>
                </div>
                <div class="panel-content">
                    ${this.generateUpdateLogHTML()}
                </div>
            </div>
        `;

        // 添加关闭按钮事件
        const closeBtn = dialog.querySelector('.close-panel-btn');
        closeBtn.onclick = () => {
            dialog.classList.add('gx_fade-out');
            setTimeout(() => {
                document.body.removeChild(dialog);
            }, 300);
        };

        document.body.appendChild(dialog);
        requestAnimationFrame(() => dialog.classList.add('gx_show'));
    }

    // 生成更新日志HTML
    generateUpdateLogHTML() {
        return this.updateLogs.map(log => `
            <div class="gx_update-log-item">
                <div class="gx_log-header ${log.type}">
                    <div class="gx_version-info">
                        <span class="gx_version">v${log.version}</span>
                        <span class="gx_date">${log.date}</span>
                    </div>
                    <h4 class="gx_log-title">${log.title}</h4>
                </div>
                <div class="gx_log-content">
                    ${log.changes.map(category => `
                        <div class="gx_change-category">
                            <h5>${category.category}</h5>
                            <ul>
                                ${category.items.map(item => `
                                    <li>${item}</li>
                                `).join('')}
                            </ul>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }
}

// 创建全局更新日志系统实例
const updateLogSystem = new UpdateLogSystem();