class SaveManager {
    constructor() {
        this.MAX_SAVES = 5; // 最大存档数量
    }

    // 保存角色数据
    saveCharacter(character) {
        // 验证角色数据
        if (!character || !character.name || !character.class) {
            console.error('Invalid character data:', character);
            return null;
        }

        try {
            let saves = this.loadSaves();
            
            // 检查是否存在同名角色的存档
            const existingIndex = saves.findIndex(save => 
                save && save.character && save.character.name === character.name
            );

            // 创建完整的存档数据
            const newSave = {
                id: existingIndex !== -1 ? saves[existingIndex].id : Date.now(),
                timestamp: new Date().toLocaleString(),
                character: {
                    // 基本信息
                    name: character.name,
                    class: character.class,
                    level: character.level || 1,
                    exp: character.exp || 0,
                    gold: character.gold || 0,  // 保存金币
                    
                    // 属性
                    attributes: character.attributes || {},
                    stats: character.stats || {},
                    
                    // 技能系统
                    skills: character.skills || {},
                    skillPoints: character.skillPoints || 0,
                    
                    // 背包系统
                    inventory: {
                        items: character.inventory?.items || [],
                        equipped: character.inventory?.equipped || {},
                        maxSlots: character.inventory?.maxSlots || 20
                    },
                    
                    // 战斗状态
                    hp: character.stats?.hp || 100,
                    maxHp: character.stats?.maxHp || 100,
                    mp: character.stats?.mp || 50,
                    maxMp: character.stats?.maxMp || 50,
                    
                    // 其他状态
                    status: {
                        buffs: character.status?.buffs || [],
                        debuffs: character.status?.debuffs || [],
                        effects: character.status?.effects || []
                    },
                    
                    // 游戏进度
                    progress: {
                        completedQuests: character.progress?.completedQuests || [],
                        unlockedAreas: character.progress?.unlockedAreas || [],
                        achievements: character.progress?.achievements || []
                    },

                    // 添加伙伴和队伍数据
                    teamData: {
                        companions: character.teamData?.companions || [],
                        currentTeam: character.teamData?.currentTeam || [],
                        maxTeamSize: character.teamData?.maxTeamSize || 4,
                        maxCompanions: character.teamData?.maxCompanions || 6
                    }
                },

                // 存档元数据
                lastSaved: new Date().getTime(),
                version: '1.0.0'
            };

            if (existingIndex !== -1) {
                // 如果存在同名角色，替换该存档
                //console.log('Replacing existing save for character:', character.name);
                saves[existingIndex] = newSave;
            } else {
                // 如果不存在同名角色，检查存档数量
                if (saves.length >= this.MAX_SAVES) {
                    // 如果存档已满，提示用户
                    if (!confirm(`存档数量已达到上限(${this.MAX_SAVES}个)，是否删除最早的存档？`)) {
                        return null;
                    }
                    // 删除最早的存档
                    saves = saves.sort((a, b) => b.lastSaved - a.lastSaved);
                    saves.pop();
                }
                saves.push(newSave);
            }

            // 按最后保存时间排序
            saves = saves.sort((a, b) => b.lastSaved - a.lastSaved);
            
            // 过滤掉无效的存档
            saves = saves.filter(save => save && save.character && save.character.name);
            
            // 确保存档数量不超过限制
            if (saves.length > this.MAX_SAVES) {
                saves = saves.slice(0, this.MAX_SAVES);
            }
            
            // 保存到localStorage
            localStorage.setItem('gameSaves', JSON.stringify(saves));
            
            //console.log('Save successful:', newSave);
            return newSave;
        } catch (error) {
            console.error('Error saving character:', error);
            return null;
        }
    }

    // 加载存档
    loadSave(saveId) {
        try {
            const saves = this.loadSaves();
            const save = saves.find(save => String(save.id) === String(saveId));
            
            if (!save) {
                console.error('Save not found:', saveId);
                return null;
            }

            // 创建新的Character实例
            const character = new Character(save.character.name, save.character.class);
            
            // 恢复所有保存的数据
            Object.assign(character, {
                level: save.character.level,
                exp: save.character.exp,
                gold: save.character.gold,
                attributes: save.character.attributes,
                stats: save.character.stats,
                skills: save.character.skills,
                skillPoints: save.character.skillPoints,
                inventory: save.character.inventory,
                status: save.character.status,
                progress: save.character.progress,
                teamData: save.character.teamData // 恢复伙伴和队伍数据
            });

            // 重新计算衍生属性
            character.stats = character.calculateStats();

            // 恢复队伍系统数据
            if (character.teamData) {
                teamSystem.companions = character.teamData.companions || [];
                teamSystem.currentTeam = character.teamData.currentTeam || [];
                teamSystem.maxTeamSize = character.teamData.maxTeamSize || 4;
                teamSystem.maxCompanions = character.teamData.maxCompanions || 6;
            }
            
            //console.log('Loading save:', save);
            return character;
        } catch (error) {
            console.error('Error loading save:', error);
            return null;
        }
    }

    // 加载所有存档
    loadSaves() {
        try {
            const saves = JSON.parse(localStorage.getItem('gameSaves') || '[]');
            return Array.isArray(saves) ? saves.filter(save => save && save.character) : [];
        } catch (error) {
            console.error('Error loading saves:', error);
            return [];
        }
    }

    // 删除存档
    deleteSave(saveId) {
        try {
            let saves = this.loadSaves();
            const originalLength = saves.length;
            
            // 确保使用字符串比较
            saves = saves.filter(save => String(save.id) !== String(saveId));
            
            // 检查是否真的删除了存档
            if (saves.length === originalLength) {
                //console.log('No save was deleted');
                return false;
            }
            
            localStorage.setItem('gameSaves', JSON.stringify(saves));
            return true;
        } catch (error) {
            console.error('Error deleting save:', error);
            return false;
        }
    }

    // 获取存档数量
    getSaveCount() {
        return this.loadSaves().length;
    }

    // 检查是否存在同名角色存档
    hasSameNameSave(characterName) {
        if (!characterName) return false;
        const saves = this.loadSaves();
        return saves.some(save => 
            save && save.character && save.character.name === characterName
        );
    }
}

// 创建全局存档管理器实例
const saveManager = new SaveManager();

// 修改原有的存档相关函数，使用新的存档管理器
function saveCharacter(character) {
    if (!character) {
        console.error('No character data provided');
        return null;
    }
    return saveManager.saveCharacter(character);
}

function loadSaves() {
    return saveManager.loadSaves();
}

function loadSave(saveId) {
    return saveManager.loadSave(saveId);
}

function deleteSave(saveId) {
    return saveManager.deleteSave(saveId);
} 