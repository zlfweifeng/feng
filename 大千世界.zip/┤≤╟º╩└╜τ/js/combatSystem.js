class CombatSystem {
    constructor() {
        this.isInCombat = false;
        this.currentTurn = 0;
        this.turnOrder = [];
        this.playerTeam = [];
        this.enemies = [];
        this.summons = new Map(); // 存储召唤物，key为召唤者ID，value为召唤物数组
        this.activeEffects = new Map(); // 存储战斗中的buff/debuff效果
        this.autoFightInterval = null; // 自动战斗的定时器
        
        // 战斗状态
        this.combatState = {
            isPlayerTurn: true,
            currentActor: null,
            phase: 'IDLE' // IDLE, EXECUTING_ACTION
        };

        this.attackLock = false; // 添加攻击锁定状态
        this.actionQueue = []; // 添加动作队列
        this.isEnding = false; // 添加结算标志位

        // 添加状态效果追踪
        this.statusEffects = new Map();
        
        // 添加动画效果配置
        this.ANIMATION_CONFIG = {
            // 基础攻击动画
            basic_attack: {
                class: 'attack-animation',
                duration: 500,
                text: '⚔️'
            },
            
            // Buff效果动画
            buff: {
                class: 'buff-animation',
                duration: 800,
                text: '⬆️'
            },
            
            debuff: {
                class: 'debuff-animation',
                duration: 800,
                text: '⬇️'
            },
            
            // 控制效果动画
            stun: {
                class: 'stun-animation',
                duration: 1000,
                text: '💫'
            },
            
            slow: {
                class: 'slow-animation',
                duration: 800,
                text: '🐌'
            },
            
            poison: {
                class: 'poison-animation',
                duration: 800,
                text: '☠️'
            },
            
            bleed: {
                class: 'bleed-animation',
                duration: 800,
                text: '🩸'
            },
            
            // 治疗效果动画
            heal: {
                class: 'heal-animation',
                duration: 800,
                text: '💚'
            },
            
            // 特殊效果动画
            petrify: {
                class: 'petrify-animation',
                duration: 1200,
                text: '🗿'
            },
            
            drain: {
                class: 'drain-animation',
                duration: 800,
                text: '💫'
            },
            paralyze: {
                class: 'paralyze-animation',
                duration: 1000,
                text: '⚡'
            },
            
            drain_hp: {
                class: 'drain-hp-animation',
                duration: 800,
                text: '💚'
            },
            
            drain_mp: {
                class: 'drain-mp-animation',
                duration: 800,
                text: '💙'
            }
        };

        // 添加品质名称映射
        this.QUALITY_NAMES = {
            legendary: '传说',
            epic: '史诗',
            rare: '稀有',
            uncommon: '优秀',
            common: '普通'
        };

        this.battleStartTime = null; // 添加战斗开始时间
        this.battleTimer = null; // 添加计时器
    }

    // 初始化战斗
    initiateCombat(enemies) {
        // 检查玩家血量
        const player = gameManager.currentPlayer;
        if (!player || player.stats.hp <= 0) {
            // 显示提示
            gameManager.showFloatingTip('血量过低，不适合战斗！', 'error');
            return false;
        }

        this.isInCombat = true;
        this.currentTurn = 0;

        // 初始化战斗时间
        this.battleStartTime = Date.now();
        this.startBattleTimer();
        
        // 为主要敌人生成伙伴
        this.enemies = this.generateEnemyTeam(enemies[0]).map(enemy => ({
            ...enemy,
            type: 'enemy', // 确保设置正确的类型
            actionBar: 0
        }));
        //console.log('敌人队伍:', this.enemies);
        
        // 获取玩家和队伍数据
        if (!player) {
           // console.error('No player found');
            return false;
        }

        // 初始化玩家队伍
        this.playerTeam = [{
            id: 'player_main',
            name: player.name,
            icon: Character.getClassIcon(player.class),
            class: player.class,
            level: player.level,
            stats: player.stats,
            skills: player.skills || [], // 确保正确复制技能数据
            type: 'player'
        }];

        // 添加队伍成员
        if (player.teamData && player.teamData.currentTeam) {
            // 获取所有有效的伙伴
            const companions = player.teamData.currentTeam
                .map(companionId => {
                    const companion = player.teamData.companions.find(c => c.id === companionId);
                    if (companion) {
                        // 使用 teamSystem 的方法计算伙伴属性
                        const stats = teamSystem.calculateCompanionStats({
                            class: companion.class,
                            quality: companion.quality,
                            level: companion.level
                        });

                        return {
                            ...companion,
                            stats: stats
                        };
                    }
                    return null;
                })
                .filter(companion => companion !== null);

            // 将伙伴添加到战斗队伍中
            companions.forEach(companion => {
                this.playerTeam.push({
                    id: companion.id,
                    name: companion.name,
                    icon: companion.icon,
                    class: companion.class,
                    level: companion.level,
                    quality: companion.quality,
                    stats: companion.stats,
                    skills: companion.skills || [],
                    type: 'companion'
                });
            });
        }

        // 清空召唤物和效果
        this.summons.clear();
        this.activeEffects.clear();

        // 计算战斗顺序
        this.calculateTurnOrder();
        
        // 显示战斗界面
        this.showCombatUI();

        // 开始自动战斗
        this.startAutoFight();

        // 重置结算标志
        this.isEnding = false;

        return true;
    }

    // 开始自动战斗
    startAutoFight() {
        if (this.autoFightInterval) {
            clearInterval(this.autoFightInterval);
        }

        this.autoFightInterval = setInterval(() => {
            this.executeTurn();
        }, 100); // 每100ms更新一次行动条
    }

    // 停止自动战斗
    stopAutoFight() {
        if (this.autoFightInterval) {
            clearInterval(this.autoFightInterval);
            this.autoFightInterval = null;
        }
    }

    // 执行回合
    executeTurn() {
        if (!this.isInCombat) return;

        // 遍历所有单位，根据速度计算行动条
        this.turnOrder.forEach(unit => {
            if (!unit.actionBar) {
                unit.actionBar = 0;
            }
            
            // 只有存活的单位才能行
            if (unit.stats.hp > 0) {
                // 根据速度计算行动条增加值
                // 基础速度2秒一次，每10点速度减少0.1，最低0.3秒
                const baseInterval = 2000; // 基础间隔2秒
                const speedReduction = Math.floor(unit.stats.speed / 10) * 100; // 每10点速度减少100ms
                const actualInterval = Math.max(300, baseInterval - speedReduction); // 最低不低于300ms
                
                // 将时间间隔为行动条增加值
                // 100是满行动条的值，乘以刷新间隔(100ms)除以实际行动间隔
                const actionBarIncrease = (100 * 100) / actualInterval;
                
                // 增加行动条，但不超过100
                unit.actionBar = Math.min(100, unit.actionBar + actionBarIncrease);
                
                // 当行动条达到100时可以行动
                if (unit.actionBar >= 100) {
                    //console.log(`【战斗】${unit.name} 行动条已满，开始行动 (速度:${unit.stats.speed}, 间隔:${actualInterval}ms)`);
                    
                    // 检查是否可以行动
                    if (this.canAct(unit)) {
                        this.executeAction(unit);
                    }
                    
                    // 重置行动条
                    unit.actionBar = 0;
                }
            }
        });

        // 更新界面
        this.updateCombatUI();

        // 检查战斗是否结束
        this.checkCombatEnd();
    }

    // 检查单位是否可以行动
    canAct(unit) {
        // 检查单位是否存活
        if (unit.stats.hp <= 0) {
            //console.log(`【战斗】${unit.name} 已阵亡，无法行动`);
            return false;
        }

        // 查是否被麻痹
        if (unit.isParalyzed) {
            // 被麻痹时有50%概率无法行动
            if (Math.random() < 0.5) {
                this.showFloatingText(unit, '麻痹', 'paralyze');
                return false;
            }
        }

        // 检查是否有控制效果
        if (this.hasControlEffect(unit)) {
            //console.log(`【战斗】${unit.name} 被控制，无法行动`);
            return false;
        }

        // 检查是否处于攻击锁定状态
        if (this.attackLock) {
            //console.log(`【战斗】${unit.name} 攻击被锁定，等待上一次攻击完成`);
            return false;
        }

        return true;
    }

    // 检查是否有控制效果
    hasControlEffect(unit) {
        const effects = this.activeEffects.get(unit.id) || [];
        return effects.some(effect => effect.type === 'CONTROL');
    }

    // 执行行动
    executeAction(actor) {
        // 获取可用技能
        const availableSkills = skillEffectSystem.getAvailableSkills(actor);
        //console.log(`${actor.name} 可用技能:`, availableSkills.map(s => s.name));
        
        // 选择目标
        const targets = this.selectTargets(actor);
        if (!targets.length) {
            //console.log(`【战斗】${actor.name} 没有可目标`);
            actor.actionBar = 0;
            return;
        }

        // 如果有可用技能,随机选择一个使用
        if (availableSkills.length > 0) {
            const randomSkill = availableSkills[Math.floor(Math.random() * availableSkills.length)];
            //console.log(`【战斗】${actor.name} 使用技能: ${randomSkill.name}`);
            this.executeSkill(actor, targets[0], randomSkill);
        } else {
            // 没有可用技能时使用普通攻击
            //console.log(`【战斗】${actor.name} 使用普通攻击(所有技能冷却中)`);
            this.executeAttack(actor, targets[0]);
        }
    }

    // 执行敌人行动
    executeEnemyAction(enemy) {
        // 获可用技能
        const availableSkills = this.getAvailableSkills(enemy);
        
        // 选择目标
        const targets = this.selectTargets(enemy);
        if (!targets.length) return;

        // 随机选择一个技能或普通攻击
        const action = this.selectEnemyAction(enemy, availableSkills);
        
        // 执技能或攻击
        if (action.type === 'SKILL') {
            this.executeSkill(enemy, targets, action.skill);
        } else {
            this.executeAttack(enemy, targets[0]);
        }
    }

    // 执行玩家行动
    executePlayerAction(player) {
        // 选择一个存活的敌人作为目标
        const targets = this.selectTargets(player);
        if (!targets.length) return;

        // 执行普通攻击
        this.executeAttack(player, targets[0]);
    }

    // 选择敌人行动
    selectEnemyAction(enemy, availableSkills) {
        // 如果MP足够且有可用技能，有30%概率使用技能
        if (availableSkills.length > 0 && Math.random() < 0.3) {
            const skill = availableSkills[Math.floor(Math.random() * availableSkills.length)];
            return { type: 'SKILL', skill };
        }
        return { type: 'ATTACK' };
    }

    // 选择玩家行动
    selectPlayerAction(player, availableSkills) {
        // 这里可以实现更复杂的AI决策逻辑
        // 现在简单实现：优先使用技能，没有技能就普通攻击
        if (availableSkills.length > 0) {
            const skill = availableSkills[0];
            const targets = this.selectTargetsForSkill(skill);
            return { type: 'SKILL', skill, targets };
        }
        return { type: 'ATTACK' };
    }

    // 获取可用技能
    getAvailableSkills(actor) {
        if (!actor.skills || !Array.isArray(actor.skills)) {
            console.warn('角色没有技能或技能数据格式错误:', actor);
            return [];
        }

        // 过滤出可用的技能
        const availableSkills = actor.skills.filter(skill => {
            // 获取技能配置
            const skillConfig = skillEffectSystem.SKILL_EFFECTS[skill.id];
            if (!skillConfig) {
                console.warn('未找到技能配置:', skill.id);
                return false;
            }

            // 检查MP是否足够
            if (skillConfig.mpCost && actor.stats.mp < skillConfig.mpCost) {
                return false;
            }

            // 检查是否在冷却中
            if (this.isSkillOnCooldown(actor.id, skill.id)) {
                return false;
            }

            return true;
        });

        /*console.log('可用技能:', {
            角色: actor.name,
            技能列表: availableSkills
        });*/

        return availableSkills;
    }

    // 选择技能目标
    selectTargetsForSkill(skill) {
        // 根据技能类型选择目标
        switch(skill.targetType) {
            case 'SINGLE_ENEMY':
                return [this.selectBestTarget()];
            case 'ALL_ENEMIES':
                return this.enemies.filter(e => e.stats.hp > 0);
            case 'SINGLE_ALLY':
                return [this.selectWeakestAlly()];
            case 'ALL_ALLIES':
                return this.playerTeam.filter(p => p.stats.hp > 0);
            default:
                return [];
        }
    }

    // 选择最佳目标
    selectBestTarget() {
        // 优先选择血量最低的敌人
        return this.enemies
            .filter(e => e.stats.hp > 0)
            .sort((a, b) => a.stats.hp - b.stats.hp)[0];
    }

    // 选择最虚弱的队友
    selectWeakestAlly() {
        return this.playerTeam
            .filter(p => p.stats.hp > 0)
            .sort((a, b) => (a.stats.hp / a.stats.maxHp) - (b.stats.hp / b.stats.maxHp))[0];
    }

    // 更新战斗界面
    updateCombatUI() {
        // 更新战斗时间显示
        const turnIndicator = document.querySelector('.turn-indicator');
        if (turnIndicator) {
            const currentTime = Date.now();
            const battleDuration = Math.floor((currentTime - this.battleStartTime) / 1000);
            const minutes = Math.floor(battleDuration / 60);
            const seconds = battleDuration % 60;
            turnIndicator.textContent = `战斗时间: ${minutes}:${seconds.toString().padStart(2, '0')}`;
        }

        // 更新单位状态
        this.updateUnitsStatus();

        // 更新战斗日志
        this.updateCombatLog();

        // 更新技能图标
        const units = [...this.playerTeam, ...this.enemies];
        units.forEach(unit => {
            const unitElement = document.querySelector(`[data-unit-id="${unit.id}"]`);
            if (!unitElement) return;

            const skillsContainer = unitElement.querySelector('.skill-icons');
            if (skillsContainer && unit.skills) {
                skillsContainer.innerHTML = unit.skills.map(skill => 
                    this.createSkillIcon(skill, unit)
                ).join('');
            }
        });
    }

    // 更新单位状态
    updateUnitsStatus() {
        // 更新玩家队伍状态
        const playerArea = document.querySelector('.player-area');
        if (playerArea) {
            playerArea.innerHTML = this.renderPlayerTeam();
        }

        // 更新敌人状态
        const enemyArea = document.querySelector('.enemy-area');
        if (enemyArea) {
            enemyArea.innerHTML = this.renderEnemies();
        }

        // 更新召唤物状态
        this.updateSummons();
    }

    // 更新召唤物状态
    updateSummons() {
        const summonArea = document.querySelector('.summon-area');
        if (!summonArea) return;

        let summonHTML = '';
        this.summons.forEach((summonList, ownerId) => {
            summonList.forEach(summon => {
                summonHTML += this.renderSummon(summon, ownerId);
            });
        });

        summonArea.innerHTML = summonHTML;
    }

    // 渲染召唤物
    renderSummon(summon, ownerId) {
        return `
            <div class="summon-unit" data-unit-id="${summon.id}" data-owner="${ownerId}">
                <div class="unit-icon">${summon.icon}</div>
                <div class="unit-info">
                    <div class="unit-name">${summon.name}</div>
                    <div class="combat-hp-bar">
                        <div class="hp-fill" style="width: ${(summon.stats.hp / summon.stats.maxHp) * 100}%"></div>
                        <span class="hp-text">${summon.stats.hp}/${summon.stats.maxHp}</span>
                    </div>
                </div>
            </div>
        `;
    }

    // 添加显示战斗界面的方法
    showCombatUI() {
        const combatScreen = document.createElement('div');
        combatScreen.className = 'combat-screen';
        
        combatScreen.innerHTML = `
            <div class="combat-container">
                <div class="combat-header">
                    <div class="turn-indicator">战斗时间: 0:00</div>
                </div>
                
                <div class="combat-field">
                    <div class="enemy-area">
                        ${this.renderEnemies()}
                    </div>
                    <div class="summon-area">
                        ${this.renderSummons()}
                    </div>
                    <div class="player-area">
                        ${this.renderPlayerTeam()}
                    </div>
                </div>
                
                <div class="combat-log">
                    <div class="log-content"></div>
                </div>
            </div>
        `;

        document.body.appendChild(combatScreen);

        // 为每个单位添加技能图标
        const units = document.querySelectorAll('.player-unit, .enemy-unit');
        units.forEach(unit => {
            const unitId = unit.dataset.unitId;
            const unitData = [...this.playerTeam, ...this.enemies].find(u => u.id === unitId);
            if (unitData && unitData.skills) {
                const skillsContainer = document.createElement('div');
                skillsContainer.className = 'skill-icons';
                
                unitData.skills.forEach(skill => {
                    skillsContainer.innerHTML += this.createSkillIcon(skill, unitData);
                });
                
                unit.appendChild(skillsContainer);
            }
        });
    }

    // 添加渲染敌人的方法
    renderEnemies() {
        return this.enemies.map((enemy, index) => {
            const isCompanion = enemy.type === 'enemy_companion';
            // 确保血量和最大血量是有效数字
            enemy.stats.hp = this.validateNumber(enemy.stats.hp, 0);
            enemy.stats.maxHp = this.validateNumber(enemy.stats.maxHp, 100);
            enemy.stats.mp = this.validateNumber(enemy.stats.mp, 0);
            enemy.stats.maxMp = this.validateNumber(enemy.stats.maxMp, 50);

            const hpPercent = Math.min(100, Math.max(0, (enemy.stats.hp / enemy.stats.maxHp) * 100));
            const mpPercent = Math.min(100, Math.max(0, (enemy.stats.mp / enemy.stats.maxMp) * 100));

            return `
                <div class="enemy-unit ${isCompanion ? 'companion' : 'main'}" 
                     data-enemy-id="${enemy.id}" 
                     data-index="${index}">
                    <div class="unit-icon ${isCompanion ? 'companion-icon' : ''}">${enemy.icon}</div>
                    <div class="unit-info">
                        <div class="unit-name">
                            ${enemy.name} Lv.${enemy.level}
                            ${isCompanion ? '<span class="companion-badge">随从</span>' : ''}
                        </div>
                        ${this.renderActionBar(enemy)}
                        <div class="combat-hp-bar">
                            <div class="hp-fill" style="width: ${hpPercent}%"></div>
                            <span class="hp-text">${this.formatNumber(enemy.stats.hp)}/${this.formatNumber(enemy.stats.maxHp)}</span>
                        </div>
                        <div class="combat-mp-bar">
                            <div class="mp-fill" style="width: ${mpPercent}%"></div>
                            <span class="mp-text">${this.formatNumber(enemy.stats.mp)}/${this.formatNumber(enemy.stats.maxMp)}</span>
                        </div>
                        <div class="skill-icons">
                            ${this.renderSkillIcons(enemy)}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // 修改渲染玩家队伍的方法
    renderPlayerTeam() {
        return this.playerTeam.map(member => {
            const stats = member.stats;
            // 确保血量和最大血量是有效数字
            stats.hp = this.validateNumber(stats.hp, 0);
            stats.maxHp = this.validateNumber(stats.maxHp, 100);
            stats.mp = this.validateNumber(stats.mp, 0);
            stats.maxMp = this.validateNumber(stats.maxMp, 50);

            const hpPercent = Math.min(100, Math.max(0, (stats.hp / stats.maxHp) * 100));
            const mpPercent = Math.min(100, Math.max(0, (stats.mp / stats.maxMp) * 100));

            // 根据成员类型设置不同的样式
            const borderColor = member.type === 'player' ? '#ffd700' : 
                (member.quality ? teamSystem.QUALITY_CONFIG[member.quality].color : '#4CAF50');

            // 修改这里，确保主玩家使用固定的 data-unit-id="player_main"
            const unitId = member.type === 'player' ? 'player_main' : member.id;

            return `
                <div class="player-unit" 
                     data-unit-id="${unitId}" 
                     data-type="${member.type}">
                    <div class="unit-icon" style="border-color: ${borderColor}">
                        ${member.icon}
                    </div>
                    <div class="unit-info">
                        <div class="unit-name">
                            ${member.name} Lv.${member.level}
                            ${member.type === 'companion' ? 
                                `<span class="quality-badge" style="background: ${borderColor}">
                                    ${teamSystem.QUALITY_CONFIG[member.quality].name}
                                </span>` : 
                                ''}
                        </div>
                        ${this.renderActionBar(member)}
                        <div class="combat-hp-bar">
                            <div class="hp-fill" style="width: ${hpPercent}%"></div>
                            <span class="hp-text">${this.formatNumber(stats.hp)}/${this.formatNumber(stats.maxHp)}</span>
                        </div>
                        <div class="combat-mp-bar">
                            <div class="mp-fill" style="width: ${mpPercent}%"></div>
                            <span class="mp-text">${this.formatNumber(stats.mp)}/${this.formatNumber(stats.maxMp)}</span>
                        </div>
                        <div class="skill-icons">
                            ${this.renderSkillIcons(member)}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // 添加计算战斗顺序的方法
    calculateTurnOrder() {
        //console.log('计算战斗顺序...');
        
        // 合并所有参战单位
        const allUnits = [...this.playerTeam, ...this.enemies];
        //console.log('所有参战单位:', allUnits);
        
        // 根据速度属性排序
        this.turnOrder = allUnits.sort((a, b) => {
            const speedA = a.stats?.speed || 0;
            const speedB = b.stats?.speed || 0;
            return speedB - speedA;
        });

        //console.log('战斗顺序已确定:', this.turnOrder);
    }

    // 加判断是否为敌人的方法
    isEnemy(unit) {
        return this.enemies.includes(unit);
    }

    // 修改选择目标的方法
    selectTargets(actor) {
        let availableTargets;
        
        // 根据actor类型选择目标
        if (actor.type === 'enemy' || actor.type === 'enemy_companion') {
            // 敌人选择玩家队伍中的活着的成员
            availableTargets = this.playerTeam.filter(member => member.stats.hp > 0);
        } else {
            // 玩家选择活着的敌人
            availableTargets = this.enemies.filter(enemy => enemy.stats.hp > 0);
        }

        // 如果有可用目标,随机选择一个
        if (availableTargets.length > 0) {
            const randomIndex = Math.floor(Math.random() * availableTargets.length);
            return [availableTargets[randomIndex]]; // 返回包含随机目标的数组
        }

        return []; // 没有可用目标时返回空数组
    }

    // 修改执行攻击方法
    executeAttack(attacker, target) {
        if (!attacker || !target) {
            console.error('Invalid attacker or target:', { attacker, target });
            return;
        }

        // 确保攻击力和防御力是正数
        const attackValue = Math.abs(attacker.stats.attack || 0);
        const defenseValue = Math.abs(target.stats.defense || 0);

        /*console.log(`【战斗】${attacker.name} 攻击 ${target.name}`);
        console.log('攻击者属性:', {
            attack: attacker.stats.attack,
            type: attacker.type
        });
        console.log('防御者属性:', {
            defense: target.stats.defense,
            currentHp: target.stats.hp,
            maxHp: target.stats.maxHp,
            type: target.type
        });*/

        // 显示技能名称动画
        this.showSkillNameAnimation(attacker, '普通攻击');

        // 计算伤害
        let damage = Math.floor(Math.max(1, Math.abs(attackValue - defenseValue)));
        
        // 确保伤害不会超过目标的最大生命值
        const maxDamage = target.stats.maxHp || target.stats.hp;
        damage = Math.min(damage, maxDamage);

        /*console.log('伤害计算详情:', {
            攻击力: attackValue,
            防御力: defenseValue,
            计算伤害: damage,
            目标最大生命: maxDamage
        });*/

        // 应用伤害前的血量
        const beforeHp = target.stats.hp;

        // 应用伤害
        target.stats.hp = Math.max(0, target.stats.hp - damage);
        
        // 记录扣血后的血量
        const afterHp = target.stats.hp;
        /*console.log('血量变化:', {
            之前: beforeHp,
            之后: afterHp,
            减少了: Math.min(beforeHp, damage) // 确保显示的减少量不超过之前的血量
        });*/

        // 显示伤害动画
        this.showDamageAnimation(target, damage, false);
        
        // 更新战斗UI
        this.updateCombatUI();
        
        // 添加战斗日志
        this.addCombatLog(`${attacker.name} 对 ${target.name} 造成了 ${damage} 点伤害`);

        // 检查战斗是否结束
        this.checkCombatEnd();

        // 如果目标是玩家，更新主界面
        if (target.type === 'player' && gameManager && gameManager.currentPlayer) {
            // 同步玩家状态
            gameManager.currentPlayer.stats.hp = target.stats.hp;
            gameManager.currentPlayer.stats.mp = target.stats.mp;
            
            // 更新主界面显示
            gameManager.updateStatBars();
            
            // 更新角色面板(如果打开的话)
            const characterPanel = document.getElementById('character-panel');
            if (characterPanel && characterPanel.style.display === 'block') {
                gameManager.showCharacterPanel();
            }

            // 更新背包界面(如果打开的话)
            const inventoryPanel = document.getElementById('inventory-panel');
            if (inventoryPanel && inventoryPanel.style.display === 'block') {
                inventorySystem.updateInventoryDisplay(gameManager.currentPlayer);
            }
        }
    }

    // 修改显示伤害动画方法
    showDamageAnimation(target, damage, isCritical) {
        // 确保伤害值为有效的正整数
        let displayDamage = Math.abs(Math.floor(damage));
        if (isNaN(displayDamage) || !isFinite(displayDamage)) {
            console.warn('检测到无效的伤害值:', damage, '使用默认值1');
            displayDamage = 1;
        }

        // 修改选择器以适应不同类型的目标
        let targetElement;
        if (target.type === 'enemy' || target.type === 'enemy_companion') {
            // 修改这里，使用 data-enemy-id 或 data-index 来查找敌人单位
            targetElement = document.querySelector(`.enemy-unit[data-enemy-id="${target.id}"], .enemy-unit[data-index="${target.id}"]`);
            
            // 如果还是找不到，尝试使用其他选择器
            if (!targetElement) {
                /*console.log('尝试查找敌人元素:', {
                    目标类型: target.type,
                    目标ID: target.id,
                    可用元素: document.querySelectorAll('.enemy-unit').length
                });*/
                // 遍历所有敌人单位，查找匹配的ID
                document.querySelectorAll('.enemy-unit').forEach(el => {
                    if (el.dataset.enemyId === target.id || el.dataset.index === target.id) {
                        targetElement = el;
                    }
                });
            }
        } else if (target.type === 'player') {
            // 对于主玩家，使用特殊的选择器
            targetElement = document.querySelector(`.player-unit[data-unit-id="player_main"]`);
        } else {
            // 对于其他玩家单位（如伙伴）
            targetElement = document.querySelector(`.player-unit[data-unit-id="${target.id}"]`);
        }

        if (!targetElement) {
            console.warn(`【提示】未找到目标元素，目标类型: ${target.type}, ID: ${target.id}`);
            // 输出更多调试信息
            /*console.log('当前DOM中的敌人单位:', {
                敌人单位数量: document.querySelectorAll('.enemy-unit').length,
                所有敌人ID: Array.from(document.querySelectorAll('.enemy-unit')).map(el => ({
                    'data-enemy-id': el.dataset.enemyId,
                    'data-index': el.dataset.index
                }))
            });*/
            return;
        }

        // 检查目标是否仍然存活
        if (target.stats.hp <= 0) return;

        // 添加受击动画
        targetElement.classList.add('being-hit');
        targetElement.style.backgroundColor = 'rgba(255, 0, 0, 0.2)';
        
        setTimeout(() => {
            targetElement.classList.remove('being-hit');
            targetElement.style.backgroundColor = '';
        }, 300);

        // 创建伤害数字元素
        const damageNumber = document.createElement('div');
        damageNumber.className = `damage-number ${isCritical ? 'critical' : ''}`;
        damageNumber.textContent = `-${Math.floor(displayDamage)}`;
        
        // 添加到 body 而不是目标元素
        document.body.appendChild(damageNumber);

        // 获取目标元素位置
        const targetRect = targetElement.getBoundingClientRect();
        
        // 设置初始位置（右上角）
        damageNumber.style.position = 'fixed';
        damageNumber.style.left = `${targetRect.right - 40}px`;
        damageNumber.style.top = `${targetRect.top}px`;
        damageNumber.style.zIndex = '9999';
        
        // 添加动画
        requestAnimationFrame(() => {
            damageNumber.style.transition = 'all 1s ease-out';
            damageNumber.style.transform = 'translate(0, -30px)';
            damageNumber.style.opacity = '0';
        });

        // 移除伤害数字
        setTimeout(() => {
            if (damageNumber.parentNode) {
                damageNumber.parentNode.removeChild(damageNumber);
            }
        }, 1000);

        // 暴击特效
        if (isCritical) {
            const criticalFlash = document.createElement('div');
            criticalFlash.className = 'critical-flash';
            targetElement.appendChild(criticalFlash);

            setTimeout(() => {
                if (criticalFlash.parentNode) {
                    criticalFlash.parentNode.removeChild(criticalFlash);
                }
            }, 300);
        }
    }

    // 修改计算伤害的方法
    calculateDamage(attacker, defender) {
        // 基础伤害
        let damage = attacker.stats.attack - defender.stats.defense;
        
        // 确保最小伤害为1
        damage = Math.max(1, damage);
        
        // 暴击判定
        const isCritical = Math.random() < (attacker.stats.crit || 0) / 100;
        if (isCritical) {
            damage *= (attacker.stats.critDmg || 150) / 100;
        }
        
        // 返回整数伤害值
        return {
            damage: Math.floor(damage),
            isCritical
        };
    }

    // 修改添加战斗日志的方法
    addCombatLog(message) {
        const logContent = document.querySelector('.log-content');
        if (!logContent) return;

        const timestamp = new Date().toLocaleTimeString('zh-CN', { 
            hour12: false, 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        });

        const logEntry = document.createElement('div');
        logEntry.className = 'combat-message';
        logEntry.innerHTML = `<span class="log-time">[${timestamp}]</span> ${message}`;
        
        logContent.appendChild(logEntry);
        logContent.scrollTop = logContent.scrollHeight;
    }

    // 修改执行技能的方法
    executeSkill(actor, target, skill) {
        const skillConfig = skillEffectSystem.SKILL_EFFECTS[skill.id];
        if (!skillConfig) {
            console.warn('未找到技能配置:', skill.id);
            return;
        }

        // 显示技能名称动画
        this.showSkillNameAnimation(actor, skill.name);

        // 扣除MP
        if (skillConfig.mpCost) {
            actor.stats.mp -= skillConfig.mpCost;
        }

        try {
            // 执行技能效果
            const result = skillEffectSystem.executeSkill(skill.id, actor, target);
            if (!result) {
                console.warn('技能执行失败');
                return;
            }

            // 修改executeSkill方法中的群攻伤害处理部分
            if (result.aoe) {
                let targets = [];
                if (actor.type === 'enemy' || actor.type === 'enemy_companion') {
                    // 如果施法者是敌人，则目标是玩家队伍
                    targets = this.playerTeam.filter(p => p.stats.hp > 0);
                    //console.log(`【群攻】${actor.name} 对玩家队伍使用 ${skill.name}，目标数量: ${targets.length}`);
                } else {
                    // 如果施法者是玩家，则目标是敌人队伍
                    targets = this.enemies.filter(e => e.stats.hp > 0);
                    //console.log(`【群攻】${actor.name} 对敌人队伍使用 ${skill.name}，目标数量: ${targets.length}`);
                }

                // 添加群攻开始的战斗日志
                this.addCombatLog(`${actor.name} 使用群体技能 ${skill.name}！`);

                // 显示AOE动画效果
                const aoeType = skill.element || 'physical'; // 根据技能属性决定动画类型
                this.showAoeAnimation(targets, aoeType);

                // 对所有目标造成伤害
                targets.forEach((t, index) => {
                    // 对后续目标造成递减伤害
                    const damageReduction = result.chainDamageReduction || 0.2; // 默认衰减20%
                    // 修改衰减伤害的计算方式
                    const reductionMultiplier = Math.max(0.3, 1 - (index * damageReduction)); // 确保至少保留30%的伤害
                    const actualDamage = Math.floor(result.damage * reductionMultiplier);
                    
                    // 记录详细的伤害计算日志
                    //console.log(`【群攻伤害】目标${index + 1}: ${t.name}`);
                    //console.log(`- 基础伤害: ${result.damage}`);
                    //console.log(`- 衰减倍率: ${reductionMultiplier.toFixed(2)}`);
                    //console.log(`- 实际伤害: ${actualDamage}`);
                    
                    // 应用伤害
                    const beforeHp = t.stats.hp;
                    t.stats.hp = Math.max(0, t.stats.hp - actualDamage);
                    const afterHp = t.stats.hp;
                    
                    // 显示伤害动画
                    this.showDamageAnimation(t, actualDamage, false);
                    
                    // 应用效果
                    if (result.effects) {
                        result.effects.forEach(effect => {
                            this.applyEffect(t, effect);
                            //console.log(`- 附加效果: ${effect.type}`);
                        });
                    }

                    // 添加详细的战斗日志
                    this.addCombatLog(`➢ ${t.name} 受到 ${actualDamage} 点伤害 (${beforeHp} → ${afterHp})`);
                    
                    // 如果目标死亡，添加额外日志
                    if (afterHp <= 0) {
                        //console.log(`【击杀】${t.name} 被击败！`);
                        this.addCombatLog(`${t.name} 被击败！`);
                    }
                });

                // 添加群攻结束的战斗日志
                this.addCombatLog(`${actor.name} 的群体攻击结束！`);
                //console.log(`【群攻结束】${actor.name} 的 ${skill.name} 攻击完成`);
            } else {
                // 单体技能的原有逻辑
                if (result.damage) {
                    const maxDamage = target.stats.maxHp || 1;
                    const actualDamage = Math.min(Math.floor(result.damage), maxDamage);
                    
                    target.stats.hp = Math.max(0, target.stats.hp - actualDamage);
                    this.showDamageAnimation(target, actualDamage, false);
                }

                // 应用效果
                if (result.effects) {
                    result.effects.forEach(effect => {
                        this.applyEffect(target, effect);
                    });
                }

                // 添加战斗日志
                this.addCombatLog(`${actor.name} 使用 ${skill.name} 对 ${target.name} 造成了 ${Math.floor(result.damage || 0)} 点伤害`);
            }

            // 设置技能冷却
            if (skillConfig.cooldown) {
                this.setSkillCooldown(actor, skill.id);
            }

            // 更新战斗UI
            this.updateCombatUI();

            // 检查战斗是否结束
            this.checkCombatEnd();

            // 如果目标是玩家，更新主界面
            if (target.type === 'player' && gameManager && gameManager.currentPlayer) {
                this.updatePlayerInterface(target);
            }
        } catch (error) {
            console.error('执行技能时出错:', error, {
                施法者: actor,
                目标: target,
                技能: skill
            });
        }
    }

    // 添加显示AOE技能动画的方法
    showAoeAnimation(targets, type) {
        targets.forEach(target => {
            let targetElement;
            if (target.type === 'enemy' || target.type === 'enemy_companion') {
                targetElement = document.querySelector(`.enemy-unit[data-enemy-id="${target.id}"]`);
            } else if (target.type === 'player') {
                targetElement = document.querySelector(`.player-unit[data-unit-id="player_main"]`);
            } else {
                targetElement = document.querySelector(`.player-unit[data-unit-id="${target.id}"]`);
            }

            if (!targetElement) {
                console.warn(`【提示】AOE动画: 未找到目标元素，目标类型: ${target.type}, ID: ${target.id}`);
                return;
            }

            // 创建AOE动画元素
            const aoeEffect = document.createElement('div');
            aoeEffect.className = `aoe-animation ${type}-aoe`;
            
            // 设置动画位置
            const rect = targetElement.getBoundingClientRect();
            aoeEffect.style.left = `${rect.left + rect.width / 2}px`;
            aoeEffect.style.top = `${rect.top + rect.height / 2}px`;
            
            document.body.appendChild(aoeEffect);

            // 添加受击动画类
            targetElement.classList.add('being-hit');
            setTimeout(() => {
                targetElement.classList.remove('being-hit');
            }, 300);
            
            // 动画结束后移除元素
            setTimeout(() => {
                if (aoeEffect.parentNode) {
                    aoeEffect.parentNode.removeChild(aoeEffect);
                }
            }, 1000);
        });
    }

    // 添加更新玩家界面的辅助方法
    updatePlayerInterface(target) {
        // 同步玩家状态
        gameManager.currentPlayer.stats.hp = target.stats.hp;
        gameManager.currentPlayer.stats.mp = target.stats.mp;
        
        // 更新主界面显示
        gameManager.updateStatBars();
        
        // 更新角色面板(如果打开的话)
        const characterPanel = document.getElementById('character-panel');
        if (characterPanel && characterPanel.style.display === 'block') {
            gameManager.showCharacterPanel();
        }

        // 更新背包界面(如果打开的话)
        const inventoryPanel = document.getElementById('inventory-panel');
        if (inventoryPanel && inventoryPanel.style.display === 'block') {
            inventorySystem.updateInventoryDisplay(gameManager.currentPlayer);
        }
    }

    // 修改显示技能名字动画的方法
    showSkillNameAnimation(caster, skillName) {
        const casterElement = document.querySelector(`[data-unit-id="${caster.id}"]`);
        if (!casterElement) return;

        // 创建技能名称元素
        const skillNameElement = document.createElement('div');
        skillNameElement.className = 'skill-name-animation';
        skillNameElement.textContent = skillName;
        
        // 获取施法者位置
        const casterRect = casterElement.getBoundingClientRect();
        
        // 置初始位置
        skillNameElement.style.position = 'fixed';
        skillNameElement.style.left = `${casterRect.left + casterRect.width/2}px`;
        skillNameElement.style.top = `${casterRect.top}px`;
        skillNameElement.style.transform = 'translate(-50%, 0)';
        
        // 添加到body
        document.body.appendChild(skillNameElement);
        
        // 移除元素
        setTimeout(() => {
            if (skillNameElement.parentNode) {
                skillNameElement.parentNode.removeChild(skillNameElement);
            }
        }, 800);
    }

    // 修改设置技能冷却的方法
    setSkillCooldown(caster, skillId) {
        const skill = skillEffectSystem.SKILL_EFFECTS[skillId];
        if (!skill || !skill.cooldown) return;

        // 初始化冷却时间追踪
        if (!caster.skillCooldowns) {
            caster.skillCooldowns = {};
        }

        // 设置冷却时间
        caster.skillCooldowns[skillId] = skill.cooldown;

        // 始冷却倒计时
        const cooldownInterval = setInterval(() => {
            if (caster.skillCooldowns[skillId] > 0) {
                caster.skillCooldowns[skillId]--;
                
                // 更新技能图标显示
                const skillIcon = document.querySelector(`[data-unit-id="${caster.id}"] [data-skill-id="${skillId}"]`);
                if (skillIcon) {
                    // 更新冷却遮罩高度
                    const cooldownOverlay = skillIcon.querySelector('.cooldown-overlay');
                    if (cooldownOverlay) {
                        const percentage = (caster.skillCooldowns[skillId] / skill.cooldown) * 100;
                        cooldownOverlay.style.height = `${percentage}%`;
                    }

                    // 更新冷却文字
                    const cooldownText = skillIcon.querySelector('.cooldown-text');
                    if (cooldownText) {
                        cooldownText.textContent = caster.skillCooldowns[skillId];
                    }

                    // 更新技能状态
                    skillIcon.classList.toggle('on-cooldown', caster.skillCooldowns[skillId] > 0);
                }

                // 如果冷却结束，移除遮罩和文字
                if (caster.skillCooldowns[skillId] === 0) {
                    if (skillIcon) {
                        skillIcon.innerHTML = this.getSkillIcon(skillId);
                        skillIcon.classList.remove('on-cooldown');
                    }
                    clearInterval(cooldownInterval);
                }
            } else {
                clearInterval(cooldownInterval);
            }
        }, 1000);
    }

    // 修渲染技能图标的方法
    renderSkillIcons(unit) {
        if (!unit.skills) return '';
        
        // 过滤掉普通攻击，只显示特殊技能
        const specialSkills = unit.skills.filter(skill => skill.id !== 'basic_attack');
        
        return specialSkills.map(skill => {
            const skillEffect = skillEffectSystem.SKILL_EFFECTS[skill.id];
            if (!skillEffect) return '';

            const cooldown = unit.skillCooldowns?.[skill.id] || 0;
            const isOnCooldown = cooldown > 0;
            const hasEnoughMp = unit.stats.mp >= (skillEffect.mpCost || 0);

            // 根据技能类型设置图标
            const skillIcon = this.getSkillIcon(skill.id);

            return `
                <div class="skill-icon ${isOnCooldown ? 'on-cooldown' : ''} ${!hasEnoughMp ? 'no-mp' : ''}" 
                     data-skill-id="${skill.id}" 
                     title="${skillEffect.name}">
                    ${skillIcon}
                    ${isOnCooldown ? `
                        <div class="cooldown-overlay" style="height: ${(cooldown / skillEffect.cooldown) * 100}%"></div>
                        <span class="cooldown-text">${cooldown}</span>
                    ` : ''}
                    <span class="mp-cost">${skillEffect.mpCost || 0}</span>
                </div>
            `;
        }).join('');
    }

    // 添加获取技能图标的方法
    getSkillIcon(skillId) {
        const iconMap = {
            // 战士技能
            heavy_strike: '🗡️',
            shield_wall: '🛡️',
            battle_cry: '📢',
            whirlwind: '🌪️',

            // 法师技能
            fireball: '🔥',
            frost_nova: '❄️',
            arcane_missile: '✨',
            mana_shield: '🌟',
            meteor: '☄️',

            // 武僧技能
            palm_strike: '🤚',
            flying_kick: '🦶',
            chi_burst: '💫',
            meditation: '🧘',
            dragon_punch: '🐉',

            // 道士技能
            thunder_strike: '⚡',
            healing_talisman: '📜',
            spirit_summon: '🐲',
            soul_drain: '👻',
            divine_seal: '🔯',

            // 怪物技能
            counter_attack: '↩️',
            iron_defense: '🛡️',
            quick_strike: '⚔️',
            intimidate: '😱',
            paralyze: '⚡'
        };

        return iconMap[skillId] || '⚔️'; // 如果没有找到对应图标，返回默认图标
    }

    // 添加渲染召唤物的方法
    renderSummons() {
        let summonHTML = '';
        this.summons.forEach((summonList, ownerId) => {
            summonList.forEach(summon => {
                summonHTML += `
                    <div class="summon-unit" data-unit-id="${summon.id}" data-owner="${ownerId}">
                        <div class="unit-icon">${summon.icon}</div>
                        <div class="unit-info">
                            <div class="unit-name">${summon.name}</div>
                            <div class="combat-hp-bar">
                                <div class="hp-fill" style="width: ${(summon.stats.hp / summon.stats.maxHp) * 100}%"></div>
                                <span class="hp-text">${summon.stats.hp}/${summon.stats.maxHp}</span>
                            </div>
                        </div>
                    </div>
                `;
            });
        });
        return summonHTML || '<div class="empty-summon-area">无召唤物</div>';
    }

    // 添加更新战斗日志的方法
    updateCombatLog() {
        const logContent = document.querySelector('.log-content');
        if (!logContent) return;

        // 保持最新的10条日志
        while (logContent.children.length > 10) {
            logContent.removeChild(logContent.firstChild);
        }

        // 滚动到最新日志
        logContent.scrollTop = logContent.scrollHeight;
    }

    // 修改检查战斗结束的方法
    checkCombatEnd() {
        // 如果已经在结算中，直接返回
        if (this.isEnding) return false;

        // 检查敌人是否全部阵亡
        const allEnemiesDead = this.enemies.every(enemy => enemy.stats.hp <= 0);
        if (allEnemiesDead) {
            this.isEnding = true; // 设置结算标志
            this.endCombat('victory');
            return true;
        }

        // 检查玩家队伍是否全部阵亡
        const allPlayersDead = this.playerTeam.every(player => player.stats.hp <= 0);
        if (allPlayersDead) {
            this.isEnding = true; // 设置算标志
            this.endCombat('defeat');
            return true;
        }

        return false;
    }

    // 修改结束战斗的方法
    endCombat(result) {
        // 如果已经不在战斗中，直接返回
        if (!this.isInCombat) return;

        //console.log('战斗结束，结果:', result);
        this.isInCombat = false;
        this.stopAutoFight();
        
        if (result === 'victory') {
            this.handleVictory();
        } else {
            this.handleDefeat();
        }
        
        // 更新主界面状态
        if (gameManager && gameManager.currentPlayer) {
            // 同步玩家状态
            gameManager.currentPlayer.stats = this.playerTeam[0].stats;
            // 恢复玩家满状态
            gameManager.currentPlayer.stats.hp = gameManager.currentPlayer.stats.maxHp;
            gameManager.currentPlayer.stats.mp = gameManager.currentPlayer.stats.maxMp;
            
            // 强制重新计算属性
            gameManager.currentPlayer.stats = gameManager.currentPlayer.calculateStats();
            
            // 更新主界面显示
            gameManager.updatePlayerInfo();
            
            // 更新角色面板(如果打开的话)
            const characterPanel = document.getElementById('character-panel');
            if (characterPanel && characterPanel.style.display === 'block') {
                gameManager.showCharacterPanel();
            }

            // 更新背包界面(如果打开的话)
            const inventoryPanel = document.getElementById('inventory-panel');
            if (inventoryPanel && inventoryPanel.style.display === 'block') {
                inventorySystem.updateInventoryDisplay(gameManager.currentPlayer);
            }

            // 保存角色数据
            saveCharacter(gameManager.currentPlayer);
        }
        
        // 移除战斗界面
        const combatScreen = document.querySelector('.combat-screen');
        if (combatScreen) {
            document.body.removeChild(combatScreen);
        }

        // 重置结算标志
        this.isEnding = false;

        // 停止战斗计时器
        if (this.battleTimer) {
            clearInterval(this.battleTimer);
            this.battleTimer = null;
        }

        // 添加战斗日志
        this.addCombatLog('战斗结束！状态已恢复！');
    }

    // 修改 handleVictory 方法
    handleVictory() {
        const exp = this.calculateExp();
        const gold = this.calculateGold();
        
        // 使用 itemGenerator 生成战利品
        let loot = itemGenerator.generateCombatLoot(this.enemies, this.playerTeam[0].level);
        
        // 应用过滤规则
        let filteredLoot = [];
        let autoSellGold = 0;
        
        loot.forEach(item => {
            if (combatSettings.shouldFilterItem(item)) {
                // 自动出售被过滤的物品
                autoSellGold += Math.floor((item.price || 10) * 0.5);
            } else {
                filteredLoot.push(item);
            }
        });
        
        // 给玩家添加经验值和金币
        if (gameManager && gameManager.currentPlayer) {
            const player = gameManager.currentPlayer;
            player.exp += exp;
            player.gold += gold + autoSellGold; // 加上自动出售的金币
            
            // 添加未被过滤的战利品到玩家背包
            filteredLoot.forEach(item => {
                if (player.inventory.items.length < player.inventory.maxSlots) {
                    player.inventory.items.push(item);
                }
            });
            
            // 检查升级
            const maxExp = gameManager.getExpForNextLevel(player.level);
            if (player.exp >= maxExp) {
                player.levelUp();
                gameManager.showFloatingTip(`恭喜升级到 ${player.level} 级！`, 'success');
            }
            
            // 保存角色数据
            saveCharacter(player);
        }
        
        // 显示战结算界面，包含自动出售信息
        this.showCombatResult({
            result: 'victory',
            exp: exp,
            gold: gold,
            autoSellGold: autoSellGold,
            loot: filteredLoot
        });
    }

    // 修改计算金币奖励的方法
    calculateGold() {
        // 获取玩家等级
        const playerLevel = this.playerTeam[0].level;
        
        // 计算所有敌人的金币总和
        return this.enemies.reduce((total, enemy) => {
            // 获取怪物的基础金币
            let gold = 0;
            
            if (enemy.type === 'enemy') {
                gold = enemy.goldReward || 0;
            } else if (enemy.type === 'enemy_companion') {
                // 如果是随从，获得30%的金币
                gold = Math.floor((enemy.goldReward || 0) * 0.3);
            }

            // 根据等级差异调整金币
            const levelDiff = enemy.level - playerLevel;
            let levelMultiplier = 1;

            if (levelDiff <= -5) {
                // 怪物等级比玩家低5级以上，大幅减少金币
                levelMultiplier = 0.1;
            } else if (levelDiff < 0) {
                // 怪物等级比玩家低，线性减少金币
                levelMultiplier = 0.7 + (levelDiff * 0.06);
            } else if (levelDiff > 0) {
                // 怪物等级比玩家高，适度增加金币
                levelMultiplier = 1 + (levelDiff * 0.1);
            }

            // 限制金币倍率范围
            levelMultiplier = Math.max(0.1, Math.min(1.5, levelMultiplier));

            // 添加随机波动 (±10%)
            const randomFactor = 0.9 + Math.random() * 0.2;
            gold = Math.floor(gold * levelMultiplier * randomFactor);

            // 根据玩家等级段位进行额外调整
            if (playerLevel >= 20) {
                gold = Math.floor(gold * 0.8); // 20级以上金币减少20%
            }
            if (playerLevel >= 30) {
                gold = Math.floor(gold * 0.7); // 30级以上金币再减少30%
            }
            if (playerLevel >= 40) {
                gold = Math.floor(gold * 0.6); // 40级以上金币再减少40%
            }

            // 确保最小金币数
            gold = Math.max(1, gold);

            /*console.log('单个敌人金币计算:', {
                名字: enemy.name,
                类型: enemy.type,
                等级: enemy.level,
                玩家等级: playerLevel,
                等级差: levelDiff,
                等级倍率: levelMultiplier,
                基础奖励: enemy.goldReward,
                最终奖励: gold
            });*/
            
            return total + gold;
        }, 0);
    }

    // 修改显示战斗结算的方法
    showCombatResult(result) {
        const resultScreen = document.createElement('div');
        resultScreen.className = 'combat-result';
        
        // 根据物品品质获取颜色
        const getQualityColor = (quality) => {
            const qualityColors = {
                legendary: '#FFD700', // 金色
                epic: '#A335EE',     // 紫色
                rare: '#0070DD',     // 蓝色
                uncommon: '#1EFF00', // 绿色
                common: '#FFFFFF'    // 白色
            };
            return qualityColors[quality] || '#FFFFFF';
        };

        // 生成物品显示HTML
        const generateItemHTML = (item) => {
            const quality = item.quality || 'common';
            const color = getQualityColor(quality);
            const typeNames = {
                WEAPON: '武器',
                HEAD: '头部',
                BODY: '衣服',
                HANDS: '手部',
                LEGS: '裤子',
                FEET: '鞋子',
                material: '材料',
                consumable: '消耗品',
                book: '书籍'
            };
            
            // 获取装备类型显示名称
            const getTypeName = (item) => {
                if (item.type in typeNames) {
                    return typeNames[item.type];
                }
                return item.type;
            };

            return `
                <li class="loot-item">
                    <span class="item-icon" style="color: ${color}">${item.icon}</span>
                    <div class="item-info">
                        <span class="item-name" style="color: ${color}">${item.name}</span>
                        <span class="item-type">${getTypeName(item)}</span>
                        ${item.stats ? `
                            <div class="item-stats">
                                ${Object.entries(item.stats)
                                    .map(([stat, value]) => {
                                        const statConfig = itemGenerator.STAT_POOL[stat];
                                        if (!statConfig) return '';
                                        return `<span>${statConfig.name}: +${value}${statConfig.format === 'percentage' ? '%' : ''}</span>`;
                                    })
                                    .join(' ')}
                            </div>
                        ` : ''}
                    </div>
                    ${item.count ? `<span class="item-count">x${item.count}</span>` : ''}
                    ${quality !== 'common' ? `
                        <span class="item-quality" style="background: ${color}20; color: ${color}">
                            ${this.QUALITY_NAMES[quality] || quality}
                        </span>
                    ` : ''}
                </li>
            `;
        };

        resultScreen.innerHTML = `
            <div class="result-content">
                <h2>${result.result === 'victory' ? '战斗胜利！' : '战斗失败'}</h2>
                ${result.result === 'victory' ? `
                    <div class="rewards">
                        <div class="reward-exp">
                            <span class="reward-icon">📈</span>
                            <span>获得经验值：${result.exp}</span>
                        </div>
                        <div class="reward-gold">
                            <span class="reward-icon">💰</span>
                            <span>获得金币：${result.gold}</span>
                        </div>
                        ${result.autoSellGold > 0 ? `
                            <div class="reward-auto-sell">
                                <span class="reward-icon">🔄</span>
                                <span>过滤出售获得：${result.autoSellGold} 金币</span>
                                <div class="auto-sell-tip">已自动出售低品质物品</div>
                            </div>
                        ` : ''}
                        <div class="reward-total-gold">
                            <span class="reward-icon">💎</span>
                            <span>总计获得：${result.gold + (result.autoSellGold || 0)} 金币</span>
                        </div>
                        ${result.loot.length > 0 ? `
                            <div class="reward-items">
                                <div class="items-header">
                                    <span class="reward-icon">🎁</span>
                                    <span>获得物品：</span>
                                </div>
                                <ul class="items-list">
                                    ${result.loot.map(item => generateItemHTML(item)).join('')}
                                </ul>
                            </div>
                        ` : ''}
                    </div>
                ` : `
                    <div class="defeat-message">
                        <span>战斗失败了...</span>
                        <div class="consolation-reward">
                            <span class="reward-icon">📈</span>
                            <span>获得安慰经验值：${result.exp}</span>
                        </div>
                    </div>
                `}
                <button class="close-result-btn">确定</button>
            </div>
        `;

        // 添加相应的CSS样式
        const style = document.createElement('style');
        style.textContent = `
            .reward-auto-sell {
                background: rgba(76, 175, 80, 0.1);
                padding: 10px;
                border-radius: 8px;
                margin: 10px 0;
                border: 1px solid #4CAF50;
            }

            .auto-sell-tip {
                font-size: 0.9em;
                color: #666;
                margin-top: 5px;
            }

            .reward-total-gold {
                font-weight: bold;
                padding: 10px;
                background: rgba(255, 193, 7, 0.1);
                border-radius: 8px;
                margin: 10px 0;
                border: 1px solid #FFC107;
            }
        `;
        document.head.appendChild(style);

        // 添加自动战斗处理
        if (document.querySelector('.auto-combat-checkbox')?.checked) {
            setTimeout(() => {
                // 关闭结算界面
                const resultScreen = document.querySelector('.combat-result');
                if (resultScreen) {
                    resultScreen.parentNode.removeChild(resultScreen);
                }
                // 开始下一场战斗
                setTimeout(() => {
                    mapSystem.startNextAutoCombat();
                }, 500);
            }, 5000);
        }

        document.body.appendChild(resultScreen);

        // 添加关闭按钮事件
        resultScreen.querySelector('.close-result-btn').onclick = () => {
            document.body.removeChild(resultScreen);
        };
    }

    // 修改 handleDefeat 方法
    handleDefeat() {
        // 计算基础经验值的5%,但不超过10点
        const baseExp = this.calculateExp();
        const defeatExp = Math.min(10, Math.floor(baseExp * 0.05)); // 失败获得5%经验值,最多10点

        // 给玩家添加经验值
        if (gameManager && gameManager.currentPlayer) {
            const player = gameManager.currentPlayer;
            player.exp += defeatExp;

            // 检查是否升级
            const maxExp = gameManager.getExpForNextLevel(player.level);
            if (player.exp >= maxExp) {
                player.levelUp();
                gameManager.showFloatingTip(`虽然失败了，但是升级到了 ${player.level} 级！`, 'success');
            }

            // 保存角色数据
            saveCharacter(player);
        }

        // 显示失败界面，包含获得的经验值
        this.showCombatResult({
            result: 'defeat',
            exp: defeatExp
        });
    }

    // 修改计算经验值的方法
    calculateExp() {
        // 获取玩家等级
        const playerLevel = this.playerTeam[0].level;
        
        // 计算基础经验值
        const baseExp = this.enemies.reduce((total, enemy) => {
            // 获取怪物的基础经验值配置
            let exp = 0;
            if (enemy.type === 'enemy') {
                // 主要怪物，从配置中获取基础经验
                const monsterType = Object.values(entityGenerator.MONSTER_TYPES)
                    .find(type => type.name === enemy.name);
                if (monsterType) {
                    exp = monsterType.baseExp || 0;
                }
            } else if (enemy.type === 'enemy_companion') {
                // 伙伴怪物，经验值为主要怪物的30%
                const mainEnemy = this.enemies.find(e => e.type === 'enemy');
                if (mainEnemy) {
                    const monsterType = Object.values(entityGenerator.MONSTER_TYPES)
                        .find(type => type.name === mainEnemy.name);
                    if (monsterType) {
                        exp = Math.floor((monsterType.baseExp || 0) * 0.3);
                    }
                }
            }
            
            // 根据等级差异调整经验值
            const levelDiff = enemy.level - playerLevel;
            let levelMultiplier = 1;

            if (levelDiff <= -5) {
                // 怪物等级比玩家低5级以上，大幅减少经验
                levelMultiplier = 0.1;
            } else if (levelDiff < 0) {
                // 怪物等级比玩家低，线性减少经验
                levelMultiplier = 0.7 + (levelDiff * 0.06);
            } else if (levelDiff > 0) {
                // 物等级比玩家高，度增加经验
                levelMultiplier = 1 + (levelDiff * 0.1);
            }

            // 限制经验倍率范围
            levelMultiplier = Math.max(0.1, Math.min(1.5, levelMultiplier));
            
            // 计算最终经验值
            exp = Math.floor(exp * levelMultiplier);
            
            /*console.log('经验值计算:', {
                怪物: enemy.name,
                怪物等级: enemy.level,
                玩家等级: playerLevel,
                等级差: levelDiff,
                基础经验: exp,
                等级倍率: levelMultiplier,
                最终经验: exp
            });*/
            
            return total + exp;
        }, 0);

        // 计算伙伴加成（降低伙伴经验加成）
        const companionCount = this.enemies.filter(enemy => enemy.type === 'enemy_companion').length;
        const companionBonus = 1 + (companionCount * 0.1); // 每个伙伴只增加10%经验

        // 计算最终经验值
        let finalExp = Math.floor(baseExp * companionBonus);

        // 根据玩家等级段位进行额外调整
        if (playerLevel >= 20) {
            finalExp = Math.floor(finalExp * 0.8); // 20级以上经验减少20%
        }
        if (playerLevel >= 30) {
            finalExp = Math.floor(finalExp * 0.7); // 30级以上经验再减少30%
        }
        if (playerLevel >= 40) {
            finalExp = Math.floor(finalExp * 0.6); // 40级以上经验再减少40%
        }

        // 确保最小经验值
        finalExp = Math.max(1, finalExp);

        /*console.log('最终经验值计算:', {
            基础经验: baseExp,
            伙伴数量: companionCount,
            伙伴加成倍率: companionBonus,
            玩家等级: playerLevel,
            最终经验: finalExp
        });*/

        return finalExp;
    }

    // 修改生成战利品的方法
    generateLoot() {
        let loot = [];
        
        // 遍历所有敌人的掉落表
        this.enemies.forEach(enemy => {
            if (!enemy.drops || enemy.type === 'enemy_companion') return;
            
            enemy.drops.forEach(dropConfig => {
                // 检查掉落概率
                if (Math.random() < dropConfig.chance) {
                    let item;
                    
                    switch(dropConfig.type) {
                        case 'weapon':
                        case 'armor':
                        case 'shield':
                            // 生成装备
                            item = this.generateEquipmentDrop(dropConfig, enemy.level);
                            break;
                            
                        case 'material':
                        case 'consumable':
                        case 'book':
                            // 生成普通物品
                            item = this.generateItemDrop(dropConfig);
                            break;
                    }
                    
                    if (item) {
                        // 检查玩家背包是否有空间
                        if (gameManager.currentPlayer.inventory.items.length < gameManager.currentPlayer.inventory.maxSlots) {
                            // 添加到玩家背包
                            gameManager.currentPlayer.inventory.items.push(item);
                            // 添加到掉列表用于显示
                            loot.push(item);
                        }
                    }
                }
            });
        });

        // 添加随机装备掉落
        const mainEnemy = this.enemies.find(e => e.type === 'enemy');
        if (mainEnemy && Math.random() < 0.3) { // 30%概率掉落随机装备
            const equipmentTypes = Object.keys(itemGenerator.EQUIPMENT_TYPES);
            const randomType = equipmentTypes[Math.floor(Math.random() * equipmentTypes.length)];
            
            // 生成随机装备，装备等级略低于怪物等级
            const equipment = itemGenerator.generateEquipment(
                randomType, 
                Math.max(1, mainEnemy.level - 2)
            );

            // 检查背包空间
            if (gameManager.currentPlayer.inventory.items.length < gameManager.currentPlayer.inventory.maxSlots) {
                // 添加到玩家背包
                gameManager.currentPlayer.inventory.items.push(equipment);
                // 添加到掉落列表
                loot.push(equipment);
            }
        }
        
        return loot;
    }

    // 添加生成装备掉落的方法
    generateEquipmentDrop(dropConfig, enemyLevel) {
        // 计算品质概率
        const qualityRoll = Math.random();
        let quality;
        
        if (qualityRoll < 0.01) {          // 1% 概率
            quality = 'legendary';
        } else if (qualityRoll < 0.05) {   // 4% 概率
            quality = 'epic';
        } else if (qualityRoll < 0.15) {   // 10% 概率
            quality = 'rare';
        } else if (qualityRoll < 0.35) {   // 20% 概率
            quality = 'uncommon';
        } else {                           // 65% 概率
            quality = 'common';
        }

        // 生成装备
        return {
            id: `${dropConfig.id}_${Date.now()}`,
            name: dropConfig.name,
            type: dropConfig.type,
            icon: dropConfig.icon || '⚔️',
            quality: quality,
            levelReq: Math.max(1, enemyLevel - 2), // 装备等级要求比怪物等级低2级
            stats: this.generateEquipmentStats(dropConfig.type, quality, enemyLevel),
            value: dropConfig.value
        };
    }

    // 添加生成装备属性的方法
    generateEquipmentStats(type, quality, level) {
        const qualityMultipliers = {
            common: 1,
            uncommon: 1.2,
            rare: 1.5,
            epic: 2,
            legendary: 3
        };
        
        const multiplier = qualityMultipliers[quality];
        const levelMultiplier = 1 + (level * 0.1); // 每级增加10%属性
        
        const stats = {};
        
        // 根据装备类型生成基础属性
        switch(type) {
            case 'weapon':
                stats.attack = Math.floor(10 * multiplier * levelMultiplier);
                if (Math.random() < 0.3) stats.critRate = Math.floor(5 * multiplier);
                if (Math.random() < 0.3) stats.critDamage = Math.floor(20 * multiplier);
                break;
                
            case 'armor':
                stats.defense = Math.floor(8 * multiplier * levelMultiplier);
                stats.hp = Math.floor(50 * multiplier * levelMultiplier);
                if (Math.random() < 0.3) stats.dodge = Math.floor(3 * multiplier);
                break;
                
            case 'shield':
                stats.defense = Math.floor(12 * multiplier * levelMultiplier);
                if (Math.random() < 0.3) stats.hp = Math.floor(30 * multiplier * levelMultiplier);
                break;
        }
        
        return stats;
    }

    // 添加生成普通物品掉落的方法
    generateItemDrop(dropConfig) {
        // 如果配置了数量范围，随机生成数量
        let count = 1;
        if (dropConfig.count && Array.isArray(dropConfig.count)) {
            const [min, max] = dropConfig.count;
            count = Math.floor(Math.random() * (max - min + 1)) + min;
        }
        
        return {
            id: `${dropConfig.id}_${Date.now()}`,
            name: dropConfig.name,
            type: dropConfig.type,
            count: count,
            value: dropConfig.value,
            icon: dropConfig.icon || '📦'
        };
    }

    // 添加治疗动画方法
    showHealAnimation(target, amount) {
        /*console.log('【动画】显示治疗动画:', {
            目标: target.name,
            治疗量: amount
        });*/

        // 创建治疗数元素
        const healNumber = document.createElement('div');
        healNumber.className = 'combat-number heal';
        healNumber.textContent = `+${Math.floor(amount)}`;
        healNumber.style.color = '#4CAF50'; // 使用绿色

        // 获取目标单位的DOM元素
        const targetElement = document.querySelector(`[data-unit-id="${target.id}"]`);
        if (!targetElement) return;

        // 设置初始位置
        const rect = targetElement.getBoundingClientRect();
        healNumber.style.left = `${rect.left + rect.width / 2}px`;
        healNumber.style.top = `${rect.top + rect.height / 2}px`;

        // 添加到文档中
        document.body.appendChild(healNumber);

        // 添加动画结束监听器
        healNumber.addEventListener('animationend', () => {
            if (healNumber.parentNode) {
                healNumber.parentNode.removeChild(healNumber);
            }
        });
    }

    // 添加生成敌人队伍的方法
    generateEnemyTeam(mainEnemy) {
        const team = [mainEnemy]; // 主要人
        
        // 随机决伙伴数量 (1-3)
        const companionCount = Math.floor(Math.random() * 3) + 1;
        
        // 生成伙伴
        for (let i = 0; i < companionCount; i++) {
            const companion = this.generateEnemyCompanion(mainEnemy);
            if (companion) {
                team.push(companion);
            }
        }

        return team;
    }

    // 修改生成敌人伙伴的方法
    generateEnemyCompanion(mainEnemy) {
        // 基于主要敌人的等级范围生成伙伴
        const levelRange = 2; // 伙伴等级范围：主要敌人等级 ±2
        const level = mainEnemy.level + Math.floor(Math.random() * (levelRange * 2 + 1)) - levelRange;
        
        // 随机选择伙伴类型
        const companionTypes = [
            { name: '小弟', icon: '👻', multiplier: 0.8 },
            { name: '护卫', icon: '💂', multiplier: 0.9 },
            { name: '随从', icon: '🤺', multiplier: 0.85 }
        ];
        
        const companionType = companionTypes[Math.floor(Math.random() * companionTypes.length)];

        // 创建伙伴数据
        const companion = {
            id: `companion_${Date.now()}`,  // 简化ID格式
            name: `${mainEnemy.name}的${companionType.name}`,
            icon: companionType.icon,
            level: Math.max(1, level),
            type: 'enemy_companion',
            stats: this.calculateEnemyCompanionStats(mainEnemy.stats, companionType.multiplier),
            goldReward: Math.floor(mainEnemy.goldReward * 0.3), // 设置金币奖励为主要敌人的30%
            skills: [
                {
                    id: 'basic_attack',
                    name: '普通攻击',
                    type: 'physical',
                    damageMultiplier: 1.0,
                    mpCost: 0,
                    cooldown: 0
                }
            ]
        };

        return companion;
    }

    // 添加计算敌人伙伴属性的方法
    calculateEnemyCompanionStats(baseStats, multiplier) {
        const stats = {};
        
        // 复制并调整基础属性
        for (const [key, value] of Object.entries(baseStats)) {
            stats[key] = Math.floor(value * multiplier);
        }

        // 确保最小值
        stats.hp = Math.max(50, stats.hp);
        stats.maxHp = stats.hp;
        stats.attack = Math.max(5, stats.attack);
        stats.defense = Math.max(3, stats.defense);
        stats.speed = Math.max(5, stats.speed);

        return stats;
    }

    // 添加显示行动条的方法
    renderActionBar(unit) {
        const actionBarWidth = (unit.actionBar || 0);
        return `
            <div class="action-bar">
                <div class="action-bar-fill" style="width: ${actionBarWidth}%"></div>
            </div>
        `;
    }

    // 添加数字验证方法
    validateNumber(value, defaultValue = 0) {
        if (isNaN(value) || value === undefined || value === null) {
            console.warn('检测到无效的数值:', value, '使用默认值:', defaultValue);
            return defaultValue;
        }
        return Number(value);
    }

    // 添加数字格式化方法
    formatNumber(value) {
        value = this.validateNumber(value);
        return Number(value.toFixed(1));
    }

    // 添加创建技能图标的方法
    createSkillIcon(skill, unit) {
        const skillConfig = skillEffectSystem.SKILL_EFFECTS[skill.id];
        if (!skillConfig) return '';

        const cooldown = unit.skillCooldowns?.[skill.id] || 0;
        const isCooldown = cooldown > 0;
        const hasEnoughMp = !skillConfig.mpCost || unit.stats.mp >= skillConfig.mpCost;

        return `
            <div class="skill-icon ${isCooldown ? 'on-cooldown' : ''} ${!hasEnoughMp ? 'no-mp' : ''}" 
                 data-skill-id="${skill.id}">
                ${skill.icon || '⚔️'}
                ${isCooldown ? `
                    <div class="cooldown-overlay" style="height: ${(cooldown / skillConfig.cooldown) * 100}%"></div>
                    <div class="cooldown-text">${cooldown}</div>
                ` : ''}
                ${skillConfig.mpCost ? `<div class="mp-cost">${skillConfig.mpCost}</div>` : ''}
            </div>
        `;
    }

    // 修改应用效果的方法
    applyEffect(target, effect) {
        if (!target || !effect) {
            console.warn('无效的目标或效果:', { target, effect });
            return;
        }

        // 如果目标没有效果列表，创建一个
        if (!target.effects) {
            target.effects = [];
        }

        // 根据效果类型应用不同效果
        switch (effect.type) {
            case 'buff':
                // 确保effect有stats属性
                if (!effect.stats) {
                    effect.stats = {};
                }
                this.applyBuff(target, effect);
                break;
            case 'debuff':
                // 确保effect有stats属性
                if (!effect.stats) {
                    effect.stats = {};
                }
                this.applyDebuff(target, effect);
                break;
            case 'dot':
                // 持续伤害
                this.applyDot(target, effect);
                break;
            case 'heal':
                // 治疗效果
                this.applyHeal(target, effect);
                break;
            case 'stun':
                // 眩晕效果
                this.applyStun(target, effect);
                break;
            case 'shield':
                // 护盾效果
                this.applyShield(target, effect);
                break;
            case 'knockup': // 添加击飞效果
                this.applyKnockup(target, effect);
                break;
            case 'paralyze':
                // 麻痹效果
                this.applyParalyze(target, effect);
                break;
            case 'drain':
                this.applyDrainEffect(effect.source, target, effect);
                break;
            default:
                console.warn('未知的效果类型:', effect.type);
        }

        // 添加效果到目标的效果列表
        target.effects.push({
            ...effect,
            startTime: Date.now(),
            endTime: Date.now() + (effect.duration * 1000 || 0)
        });

        // 更新UI显示
        this.updateEffectDisplay(target);
    }

    // 修改应用buff的方法
    applyBuff(target, effect) {
        if (!target || !effect) return;

        const buffId = `buff_${Date.now()}`;
        const buffEffect = {
            id: buffId,
            stats: effect.stats || {},
            duration: effect.duration || 3,
            name: effect.name || 'Buff'
        };
        
        // 应用属性加成
        if (buffEffect.stats) {
            for (const [stat, value] of Object.entries(buffEffect.stats)) {
                if (!target.stats[stat]) {
                    target.stats[stat] = 0;
                }
                target.stats[stat] += value;
            }
        }
        
        // 记录buff
        this.statusEffects.set(buffId, {
            target: target,
            effect: buffEffect,
            endTime: Date.now() + (effect.duration * 1000)
        });
        
        // 显示buff提示
        this.showFloatingText(target, `${effect.name} +`, 'buff');
        
        // 设置buff结束时间
        setTimeout(() => {
            this.removeBuff(target, buffId);
        }, effect.duration * 1000);
    }

    // 修改 applyDebuff 方法
    applyDebuff(target, effect) {
        if (!effect || !effect.stats) {
            console.warn('无效的 debuff 效果:', effect);
            return;
        }

        const debuffId = `debuff_${Date.now()}`;
        const debuffEffect = {
            id: debuffId,
            stats: effect.stats,
            duration: effect.duration || 3, // 添加默认持续时间
            name: effect.name || 'Debuff'   // 添加默认名称
        };
        
        try {
            // 应用属性减益
            for (const [stat, value] of Object.entries(effect.stats)) {
                if (!target.stats[stat]) {
                    target.stats[stat] = 0; // 初始化不存在的属性
                }
                target.stats[stat] = (target.stats[stat] || 0) + value;
            }
            
            // 记录debuff
            this.statusEffects.set(debuffId, {
                target: target,
                effect: debuffEffect,
                endTime: Date.now() + (effect.duration * 1000)
            });
            
            // 显示debuff提示
            this.showFloatingText(target, `${effect.name} -`, 'debuff');
            
            // 设置debuff结束时间
            setTimeout(() => {
                this.removeDebuff(target, debuffId);
            }, effect.duration * 1000);

            /*console.log('功应用debuff:', {
                目标: target.name,
                效果: effect,
                持续时间: effect.duration
            });*/
        } catch (error) {
            console.error('应用debuff时出错:', error, {
                目标: target,
                效果: effect
            });
        }
    }

    // 添加持续伤害方法
    applyDot(target, effect) {
        const dotId = `dot_${Date.now()}`;
        let tickCount = 0;
        
        const dotInterval = setInterval(() => {
            if (tickCount >= effect.duration) {
                clearInterval(dotInterval);
                return;
            }
            
            // 造成伤害
            target.stats.hp -= effect.damage;
            
            // 显示伤害提示
            this.showFloatingText(target, effect.damage, 'dot');
            
            tickCount++;
        }, 1000);
        
        // 记录dot效果
        this.statusEffects.set(dotId, {
            target: target,
            interval: dotInterval,
            endTime: Date.now() + (effect.duration * 1000)
        });
    }

    // 添加治疗果方法
    applyHeal(target, effect) {
        const healAmount = effect.heal;
        target.stats.hp = Math.min(target.stats.hp + healAmount, target.stats.maxHp);
        
        // 显示治疗提示
        this.showFloatingText(target, `+${healAmount}`, 'heal');
    }

    // 添加眩晕效果方法
    applyStun(target, effect) {
        const stunId = `stun_${Date.now()}`;
        
        // 设置目标为眩晕状态
        target.isStunned = true;
        
        // 记录眩晕效果
        this.statusEffects.set(stunId, {
            target: target,
            duration: effect.duration,
            endTime: Date.now() + (effect.duration * 1000)
        });
        
        // 显示眩晕提示
        this.showFloatingText(target, '眩晕', 'stun');
        
        // 设置眩晕结束时间
        setTimeout(() => {
            target.isStunned = false;
            this.statusEffects.delete(stunId);
        }, effect.duration * 1000);
    }

    // 添加护盾效果方法
    applyShield(target, effect) {
        if (!target.shield) target.shield = 0;
        target.shield += effect.value;
        
        this.addCombatLog(`${target.name} 获得了 ${effect.value} 点护盾`);
        
        setTimeout(() => {
            target.shield = Math.max(0, target.shield - effect.value);
            this.addCombatLog(`${target.name} 的护盾效果结束`);
            this.updateEffectDisplay(target);
        }, effect.duration * 1000);
    }

    // 添加击飞效果方法
    applyKnockup(target, effect) {
        target.isKnockedUp = true;
        this.addCombatLog(`${target.name} 被击飞了`);
        
        // 添加击飞动画
        const targetElement = document.querySelector(`[data-unit-id="${target.id}"]`);
        if (targetElement) {
            targetElement.style.transform = 'translateY(-20px)';
            targetElement.style.transition = 'transform 0.3s ease-out';
            
            setTimeout(() => {
                targetElement.style.transform = 'translateY(0)';
            }, 300);
        }
        
        setTimeout(() => {
            target.isKnockedUp = false;
            this.addCombatLog(`${target.name} 的击飞效果结束`);
            this.updateEffectDisplay(target);
        }, effect.duration * 1000);
    }

    // 添加更新效果显示的方法
    updateEffectDisplay(target) {
        const targetElement = document.querySelector(`[data-unit-id="${target.id}"]`);
        if (!targetElement) return;

        // 更新效果图标显示
        const effectsContainer = targetElement.querySelector('.status-effects');
        if (!effectsContainer) {
            const newEffectsContainer = document.createElement('div');
            newEffectsContainer.className = 'status-effects';
            targetElement.appendChild(newEffectsContainer);
        }

        // 清理过期效果
        if (target.effects) {
            target.effects = target.effects.filter(effect => 
                effect.endTime > Date.now()
            );
        }

        // 更新效果图标
        const container = effectsContainer || targetElement.querySelector('.status-effects');
        container.innerHTML = this.generateEffectIcons(target);
    }

    // 添加生成效果图标的方法
    generateEffectIcons(target) {
        if (!target.effects || target.effects.length === 0) return '';

        return target.effects.map(effect => {
            const remainingTime = Math.ceil((effect.endTime - Date.now()) / 1000);
            const icon = this.getEffectIcon(effect.type);
            
            return `
                <div class="effect-icon" title="${this.getEffectDescription(effect)}">
                    ${icon}
                    <div class="effect-duration">${remainingTime}s</div>
                </div>
            `;
        }).join('');
    }

    // 添加获取效果图标的方法
    getEffectIcon(effectType) {
        const icons = {
            buff: '⬆️',
            debuff: '⬇️',
            dot: '💀',
            heal: '💚',
            stun: '💫',
            shield: '🛡️',
            knockup: '↗️',
            paralyze: '⚡'
        };
        return icons[effectType] || '❓';
    }

    // 添加获取效果描述的方法
    getEffectDescription(effect) {
        switch(effect.type) {
            case 'buff':
                return `增加 ${effect.value}% ${effect.stat}`;
            case 'debuff':
                return `降低 ${effect.value}% ${effect.stat}`;
            case 'dot':
                return `每秒受到 ${Math.floor(effect.damage)} 点伤害`;
            case 'heal':
                return `恢复 ${Math.floor(effect.value)} 点生命值`;
            case 'stun':
                return '被眩晕';
            case 'shield':
                return `获得 ${Math.floor(effect.value)} 点护盾`;
            case 'knockup':
                return '被击';
            case 'paralyze':
                return '被麻痹';
            default:
                return '未知效果';
        }
    }

    // 修改 applyDamage 方法，添加吸血效果的显示
    applyDamage(target, damage, attacker = null) {
        // 确保伤害是有效数字
        if (isNaN(damage) || !isFinite(damage)) {
            console.warn('检测到无效的伤害值，使用默认值0');
            damage = 0;
        }

        // 确保目标有效的生命值和最大生命值
        if (!target.stats.hp || isNaN(target.stats.hp)) {
            target.stats.hp = target.stats.maxHp || 100;
        }
        if (!target.stats.maxHp || isNaN(target.stats.maxHp)) {
            target.stats.maxHp = 100;
        }

        // 确保当前生命值不超过最大值
        target.stats.hp = Math.min(target.stats.hp, target.stats.maxHp);

        // 应用伤害
        const actualDamage = Math.max(0, damage); // 确保伤害不为负数
        target.stats.hp = Math.max(0, Math.min(target.stats.maxHp, target.stats.hp - actualDamage));

        // 显示伤害动画
        if (actualDamage > 0) {
            this.showDamageAnimation(target, actualDamage);
        }

        // 处理吸血效果
        if (attacker && attacker.stats.drain > 0 && actualDamage > 0) {
            const drainAmount = Math.floor(actualDamage * (attacker.stats.drain / 100));
            if (drainAmount > 0) {
                // 确保不会超过最大生命值
                const currentHp = attacker.stats.hp || 0;
                const maxHp = attacker.stats.maxHp || 100;
                const newHp = Math.min(maxHp, currentHp + drainAmount);
                const actualHeal = newHp - currentHp;

                // 只有在实际恢复生命值时才应用效果
                if (actualHeal > 0) {
                    attacker.stats.hp = newHp;
                    // 显示吸血回复动画
                    this.showHealAnimation(attacker, actualHeal);
                }
            }
        }

        // 更新界面显示
        this.updateUnitDisplay(target);
        if (attacker) {
            this.updateUnitDisplay(attacker);
        }
    }

    // 添加更新单位显示的方法
    updateUnitDisplay(unit) {
        const unitElement = document.querySelector(`[data-unit-id="${unit.id}"]`);
        if (!unitElement) return;

        // 更新生命值显示
        const hpBar = unitElement.querySelector('.hp-bar');
        if (hpBar) {
            const maxHp = unit.stats.maxHp || 100;
            const currentHp = Math.min(unit.stats.hp || 0, maxHp);
            const hpPercentage = (currentHp / maxHp) * 100;
            
            hpBar.querySelector('.bar-fill').style.width = `${hpPercentage}%`;
            hpBar.querySelector('.bar-text').textContent = `${Math.floor(currentHp)}/${maxHp}`;
        }
    }

    // 添加应用技能效果的方法
    applySkillEffect(caster, target, effect) {
        if (!effect) return;

        // 创建动画效果
        this.showSkillAnimation(target, effect);

        // 处理不同类型的效果
        switch (effect.type) {
            case 'buff':
                this.applyBuff(target, effect);
                break;
            case 'debuff':
                this.applyDebuff(target, effect);
                break;
            case 'dot':
                this.applyDotEffect(target, effect);
                break;
            case 'heal':
                this.applyHealEffect(target, effect);
                break;
            case 'stun':
                this.applyStunEffect(target, effect);
                break;
            case 'slow':
                this.applySlowEffect(target, effect);
                break;
            case 'drain':
                this.applyDrainEffect(caster, target, effect);
                break;
            case 'paralyze':
                this.applyParalyzeEffect(target, effect);
                break;
            // ... 其他效果类型
        }
    }

    // 显示技能动画
    showSkillAnimation(target, effect) {
        const animConfig = this.ANIMATION_CONFIG[effect.type] || this.ANIMATION_CONFIG.basic_attack;
        
        const animation = document.createElement('div');
        animation.className = `skill-animation ${animConfig.class}`;
        animation.textContent = animConfig.text;
        
        // 获取目标的位置
        const targetElement = document.querySelector(`[data-entity-id="${target.id}"]`);
        if (!targetElement) return;
        
        const rect = targetElement.getBoundingClientRect();
        
        // 设置动画位置
        animation.style.position = 'absolute';
        animation.style.left = `${rect.left + rect.width / 2}px`;
        animation.style.top = `${rect.top + rect.height / 2}px`;
        
        document.body.appendChild(animation);
        
        // 添加画结束后移除元素
        setTimeout(() => {
            animation.remove();
        }, animConfig.duration);
    }

    // 应用增益效果
    applyBuff(target, effect) {
        const buffId = `buff_${Date.now()}`;
        const buffEffect = {
            id: buffId,
            stats: effect.stats,
            duration: effect.duration,
            name: effect.name
        };
        
        // 应用属性加成
        for (const [stat, value] of Object.entries(effect.stats)) {
            target.stats[stat] = (target.stats[stat] || 0) + value;
        }
        
        // 记录buff
        this.statusEffects.set(buffId, {
            target: target,
            effect: buffEffect,
            endTime: Date.now() + (effect.duration * 1000)
        });
        
        // 显示buff提示
        this.showFloatingText(target, `${effect.name} +`, 'buff');
        
        // 设置buff结束时间
        setTimeout(() => {
            this.removeBuff(target, buffId);
        }, effect.duration * 1000);
    }

    // 应用减益效果
    applyDebuff(target, effect) {
        const debuffId = `debuff_${Date.now()}`;
        const debuffEffect = {
            id: debuffId,
            stats: effect.stats,
            duration: effect.duration,
            name: effect.name
        };
        
        // 应用属性减益
        for (const [stat, value] of Object.entries(effect.stats)) {
            target.stats[stat] = (target.stats[stat] || 0) + value;
        }
        
        // 记录debuff
        this.statusEffects.set(debuffId, {
            target: target,
            effect: debuffEffect,
            endTime: Date.now() + (effect.duration * 1000)
        });
        
        // 显示debuff提示
        this.showFloatingText(target, `${effect.name} -`, 'debuff');
        
        // 设置debuff结束时间
        setTimeout(() => {
            this.removeDebuff(target, debuffId);
        }, effect.duration * 1000);
    }

    // 应用持续伤害效果
    applyDotEffect(target, effect) {
        const dotId = `dot_${Date.now()}`;
        let tickCount = 0;
        
        const dotInterval = setInterval(() => {
            if (tickCount >= effect.duration) {
                clearInterval(dotInterval);
                return;
            }
            
            // 造成伤害
            target.stats.hp -= effect.damage;
            
            // 显示伤害提示
            this.showFloatingText(target, effect.damage, 'dot');
            
            tickCount++;
        }, 1000);
        
        // 记录dot效果
        this.statusEffects.set(dotId, {
            target: target,
            interval: dotInterval,
            endTime: Date.now() + (effect.duration * 1000)
        });
    }

    // 应用治疗效果
    applyHealEffect(target, effect) {
        const healAmount = effect.heal;
        target.stats.hp = Math.min(target.stats.hp + healAmount, target.stats.maxHp);
        
        // 显示治疗提示
        this.showFloatingText(target, `+${healAmount}`, 'heal');
    }

    // 应用减速效果
    applySlowEffect(target, effect) {
        const slowId = `slow_${Date.now()}`;
        const originalSpeed = target.stats.speed;
        
        // 减少目标速度
        target.stats.speed *= (1 - effect.value);
        
        // 记录减速效果
        this.statusEffects.set(slowId, {
            target: target,
            originalSpeed: originalSpeed,
            endTime: Date.now() + (effect.duration * 1000)
        });
        
        // 显示减速提示
        this.showFloatingText(target, '减速', 'slow');
        
        // 设置减速结束时间
        setTimeout(() => {
            target.stats.speed = originalSpeed;
            this.statusEffects.delete(slowId);
        }, effect.duration * 1000);
    }

    // 修改吸取效果的实现方法
    applyDrainEffect(source, target, effect) {
        if (!source || !target || !effect) return;

        // 处理生命值吸取
        if (effect.drainHp) {
            const drainAmount = Math.floor(effect.drainHp);
            if (drainAmount > 0) {
                // 从目标扣除生命值，但不超过目标当前生命值
                const actualDrain = Math.min(target.stats.hp, drainAmount);
                target.stats.hp = Math.max(0, target.stats.hp - actualDrain);

                // 给施法者恢复生命值，但不超过最大生命值
                const maxHealPossible = source.stats.maxHp - source.stats.hp;
                const actualHeal = Math.min(maxHealPossible, actualDrain);
                source.stats.hp = Math.min(source.stats.maxHp, source.stats.hp + actualHeal);

                // 显示吸取动画和数字
                this.showDrainAnimation(source, target, actualDrain, 'hp');
                this.showFloatingNumber(target, -actualDrain, 'drain_hp');
                if (actualHeal > 0) {
                    this.showFloatingNumber(source, actualHeal, 'heal');
                }
            }
        }

        // 处理法力值吸取
        if (effect.drainMp) {
            const drainAmount = Math.floor(effect.drainMp);
            if (drainAmount > 0) {
                // 从目标扣除法力值，但不超过目标当前法力值
                const actualDrain = Math.min(target.stats.mp, drainAmount);
                target.stats.mp = Math.max(0, target.stats.mp - actualDrain);

                // 给施法者恢复法力值，但不超过最大法力值
                const maxMpPossible = source.stats.maxMp - source.stats.mp;
                const actualRestore = Math.min(maxMpPossible, actualDrain);
                source.stats.mp = Math.min(source.stats.maxMp, source.stats.mp + actualRestore);

                // 显示吸取动画和数字
                this.showDrainAnimation(source, target, actualDrain, 'mp');
                this.showFloatingNumber(target, -actualDrain, 'drain_mp');
                if (actualRestore > 0) {
                    this.showFloatingNumber(source, actualRestore, 'restore_mp');
                }
            }
        }

        // 更新战斗界面
        this.updateCombatUI();
    }

    // 移除buff效果
    removeBuff(target, buffId) {
        const buffData = this.statusEffects.get(buffId);
        if (!buffData) return;
        
        // 移除属性加成
        for (const [stat, value] of Object.entries(buffData.effect.stats)) {
            target.stats[stat] -= value;
        }
        
        // 移除buff记录
        this.statusEffects.delete(buffId);
        
        // 显示buff结束提示
        this.showFloatingText(target, `${buffData.effect.name}结束`, 'buff-end');
    }

    // 移除debuff效果
    removeDebuff(target, debuffId) {
        const debuffData = this.statusEffects.get(debuffId);
        if (!debuffData) return;
        
        // 恢复属性
        for (const [stat, value] of Object.entries(debuffData.effect.stats)) {
            target.stats[stat] -= value;
        }
        
        // 移除debuff记录
        this.statusEffects.delete(debuffId);
        
        // 显示debuff结束提示
        this.showFloatingText(target, `${debuffData.effect.name}结束`, 'debuff-end');
    }

    // 显示浮动文字
    showFloatingText(target, text, type) {
        const floatingText = document.createElement('div');
        floatingText.className = `floating-text ${type}`;
        floatingText.textContent = text;
        
        // 获取目标位置
        const targetElement = document.querySelector(`[data-entity-id="${target.id}"]`);
        if (!targetElement) return;
        
        const rect = targetElement.getBoundingClientRect();
        
        // 设置文字位置
        floatingText.style.position = 'absolute';
        floatingText.style.left = `${rect.left + rect.width / 2}px`;
        floatingText.style.top = `${rect.top}px`;
        
        document.body.appendChild(floatingText);
        
        // 添加动画结束后移除元素
        setTimeout(() => {
            floatingText.remove();
        }, 1000);
    }

    // 添加战斗计时器方法
    startBattleTimer() {
        // 清除可能存在的旧计时器
        if (this.battleTimer) {
            clearInterval(this.battleTimer);
        }

        // 更新时间显示
        const updateTimer = () => {
            const turnIndicator = document.querySelector('.turn-indicator');
            if (!turnIndicator) return;

            const currentTime = Date.now();
            const battleDuration = Math.floor((currentTime - this.battleStartTime) / 1000); // 转换为秒
            
            // 格式化时间显示
            const minutes = Math.floor(battleDuration / 60);
            const seconds = battleDuration % 60;
            turnIndicator.textContent = `战斗时间: ${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            // 添加动画效果
            if (seconds === 0 && battleDuration > 0) {
                turnIndicator.classList.add('minute-change');
                setTimeout(() => {
                    turnIndicator.classList.remove('minute-change');
                }, 500);
            }
        };

        // 立即更新一次
        updateTimer();
        
        // 每秒更新一次
        this.battleTimer = setInterval(updateTimer, 1000);
    }

    // 添加麻痹效果的实现方法
    applyParalyze(target, effect) {
        const paralyzeId = `paralyze_${Date.now()}`;
        
        // 设置目标为麻痹状态
        target.isParalyzed = true;
        
        // 降低目标速度
        const originalSpeed = target.stats.speed;
        target.stats.speed = Math.floor(target.stats.speed * 0.5); // 降低50%速度
        
        // 记录麻痹效果
        this.statusEffects.set(paralyzeId, {
            target: target,
            effect: {
                id: paralyzeId,
                name: effect.name || '麻痹',
                duration: effect.duration || 3,
                originalSpeed: originalSpeed
            },
            endTime: Date.now() + (effect.duration * 1000)
        });
        
        // 显示麻痹提示
        this.showFloatingText(target, effect.name || '麻痹', 'paralyze');
        
        // 添加视觉效果
        const targetElement = document.querySelector(`[data-unit-id="${target.id}"]`);
        if (targetElement) {
            targetElement.classList.add('paralyzed');
        }
        
        // 设置麻痹结束时间
        setTimeout(() => {
            // 移除麻痹状态
            target.isParalyzed = false;
            // 恢复原速度
            target.stats.speed = originalSpeed;
            // 移除视觉效果
            if (targetElement) {
                targetElement.classList.remove('paralyzed');
            }
            // 移除状态效果记录
            this.statusEffects.delete(paralyzeId);
            // 更新效果显示
            this.updateEffectDisplay(target);
            // 添加战斗日
            this.addCombatLog(`${target.name} 的麻痹效果结束了`);
        }, effect.duration * 1000);
        
        // 添加战斗日志
        this.addCombatLog(`${target.name} 被麻痹了，速度降低50%`);
    }

    // 添加显示吸取动画的方法
    showDrainAnimation(source, target, amount, type) {
        const targetElement = document.querySelector(`[data-unit-id="${target.id}"]`);
        const sourceElement = document.querySelector(`[data-unit-id="${source.id}"]`);
        
        if (!targetElement || !sourceElement) return;

        // 创建吸取效果线
        const drainLine = document.createElement('div');
        drainLine.className = `drain-line ${type === 'mp' ? 'drain-mp' : 'drain-hp'}`;
        
        // 获取元素位置
        const targetRect = targetElement.getBoundingClientRect();
        const sourceRect = sourceElement.getBoundingClientRect();
        
        // 设置线的起点和终点
        const startX = targetRect.left + targetRect.width / 2;
        const startY = targetRect.top + targetRect.height / 2;
        const endX = sourceRect.left + sourceRect.width / 2;
        const endY = sourceRect.top + sourceRect.height / 2;
        
        // 计算角度和距离
        const angle = Math.atan2(endY - startY, endX - startX);
        const distance = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
        
        // 设置线的样式
        drainLine.style.left = `${startX}px`;
        drainLine.style.top = `${startY}px`;
        drainLine.style.width = `${distance}px`;
        drainLine.style.transform = `rotate(${angle}rad)`;
        
        document.body.appendChild(drainLine);
        
        // 移除动画元素
        setTimeout(() => {
            drainLine.remove();
        }, 500);
    }

    // 添加显示浮动数字的方法
    showFloatingNumber(target, value, type) {
        const element = document.querySelector(`[data-unit-id="${target.id}"]`);
        if (!element) return;

        const floatingNumber = document.createElement('div');
        floatingNumber.className = `floating-number ${type}`;
        
        // 设置数字颜色和前缀
        if (type === 'drain_hp' || type === 'drain_mp') {
            floatingNumber.textContent = value;
            floatingNumber.style.color = type === 'drain_mp' ? '#2196F3' : '#4CAF50';
        } else if (type === 'heal' || type === 'restore_mp') {
            floatingNumber.textContent = `+${value}`;
            floatingNumber.style.color = type === 'restore_mp' ? '#2196F3' : '#4CAF50';
        }

        const rect = element.getBoundingClientRect();
        floatingNumber.style.left = `${rect.left + rect.width / 2}px`;
        floatingNumber.style.top = `${rect.top}px`;

        document.body.appendChild(floatingNumber);

        setTimeout(() => {
            floatingNumber.remove();
        }, 1000);
    }
}

// 创建全局战斗系统实例
const combatSystem = new CombatSystem(); 