// 页面切换函数
function showPage(pageId) {
    const currentPage = document.querySelector('.page.active');
    const nextPage = document.getElementById(pageId);
    
    if (currentPage && nextPage) {
        // 当前页面淡出
        currentPage.classList.add('fade-out');
        currentPage.addEventListener('animationend', function handler() {
            currentPage.classList.remove('active', 'fade-out');
            currentPage.removeEventListener('animationend', handler);
        });

        // 下一个页面淡入
        setTimeout(() => {
            nextPage.classList.add('active', 'fade-in');
            nextPage.addEventListener('animationend', function handler() {
                nextPage.classList.remove('fade-in');
                nextPage.removeEventListener('animationend', handler);
            });
        }, 300);
    }
}

// 页面加载完成后的初始化
document.addEventListener('DOMContentLoaded', () => {
    // 新游戏按钮点击事件
    const newGameBtn = document.getElementById('new-game');
    if (newGameBtn) {
        newGameBtn.addEventListener('click', () => {
            showPage('character-creation');
        });
    }

    // 读取存档按钮点击事件
    const loadGameBtn = document.getElementById('load-game-btn');
    if (loadGameBtn) {
        loadGameBtn.addEventListener('click', () => {
            showPage('load-game-page');
        });
    }

    // 更新公告按钮点击事件
    const updateLogBtn = document.getElementById('update-log-btn');
    if (updateLogBtn) {
        updateLogBtn.addEventListener('click', () => {
            updateLogSystem.showUpdateLog();
        });
    }

    // 返回按钮点击事件
    const backButton = document.getElementById('back-to-main');
    if (backButton) {
        backButton.addEventListener('click', () => {
            showPage('start-page');
        });
    }
}); 