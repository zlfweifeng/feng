class MapSystem {
    constructor() {
        this.maps = {
            city: {
                name: '主城',
                icon: '🏰',
                startNode: 'a',
                nodes: {
                    a: { 
                        name: '武庙', 
                        x: 1, 
                        y: 2, 
                        connections: ['b', 'e', 'h', 'f'],
                        description: '古老的武庙，供奉着历代武学大师，空气中弥漫着檀香的气息。',
                        monsters: [
                            { 
                                type: 'WOODEN_DUMMY',
                                name: '木人桩',
                                icon: '🪱',
                                level: 1,
                                description: '用于练功的木人桩，偶尔会产生反应'
                            },
                            {
                                type: 'IRON_DUMMY',
                                name: '铁人桩',
                                icon: '⚔️',
                                level: 3,
                                description: '坚固的铁制木人桩，具有更强的反击能力'
                            }
                        ]
                    },
                    b: { 
                        name: '武街', 
                        x: 1, 
                        y: 1, 
                        connections: ['a', 'c', 'k', 'd'],
                        description: '热闹的街道，两旁是各种武馆和装备店铺。',
                        monsters: [
                            {
                                type: 'STREET_THUG',
                                name: '街头混混',
                                icon: '👤',
                                level: 5,
                                description: '在武街闲逛的混混，喜欢挑衅路人'
                            },
                            {
                                type: 'MARTIAL_STUDENT',
                                name: '武馆学徒',
                                icon: '🥋',
                                level: 7,
                                description: '正在习武的学徒，掌握了基本的武学招式'
                            }
                        ]
                    },
                    c: { 
                        name: '武会', 
                        x: 0, 
                        y: 1, 
                        connections: ['b', 'f', 'g'],
                        description: '热闹的庙会，香客络绎不绝，小贩叫卖声此起彼伏。',
                        monsters: [
                            {
                                type: 'MERCHANT_GUARD',
                                name: '商队护卫',
                                icon: '💂',
                                level: 10,
                                description: '保护商队的护卫，身手不错'
                            },
                            {
                                type: 'APPRENTICE_MAGE',
                                name: '见习巫师',
                                icon: '🧙',
                                level: 12,
                                description: '正在学习法术的巫师学徒'
                            }
                        ]
                    },
                    d: { 
                        name: '巫师会客室', 
                        x: 1, 
                        y: 0, 
                        connections: ['g', 'j', 'b', 'k'],
                        description: '神秘的会客室，墙上挂满了各种奇异的符文。',
                        monsters: []
                    },
                    e: { 
                        name: '武馆', 
                        x: 1, 
                        y: 3, 
                        connections: ['a', 'h'],
                        description: '气势恢宏的武馆，经常能听到习武之人的喝声。',
                        monsters: [
                            {
                                type: 'MERCHANT_GUARD',
                                name: '商队护卫',
                                icon: '💂',
                                level: 10,
                                description: '保护商队的护卫，身手不错'
                            },
                            {
                                type: 'APPRENTICE_MAGE',
                                name: '见习巫师',
                                icon: '🧙',
                                level: 12,
                                description: '正在学习法术的巫师学徒'
                            }
                        ]
                    },
                    f: { 
                        name: '武馆分部', 
                        x: 0, 
                        y: 2, 
                        connections: ['c', 'a'],
                        description: '武馆的分部，规模较小但五脏俱全。',
                        monsters: []
                    },
                    g: { 
                        name: '巫师塔', 
                        x: 0, 
                        y: 0, 
                        connections: ['d', 'c'],
                        description: '高耸的巫师塔，塔顶经常闪烁着神秘的光芒。',
                        monsters: []
                    },
                    h: { 
                        name: '集市', 
                        x: 2, 
                        y: 2, 
                        connections: ['a', 'l', 'e', 'i'],
                        description: '繁华的集市，各种商品琳琅满目。',
                        monsters: []
                    },
                    i: { 
                        name: '北街', 
                        x: 2, 
                        y: 1, 
                        connections: ['k', 'l', 'h', 'j'],
                        description: '通往城北的主要街道，行人熙熙攘攘。',
                        monsters: []
                    },
                    j: { 
                        name: '名人堂', 
                        x: 2, 
                        y: 0, 
                        connections: ['d', 'k', 'i'],
                        description: '记载着各路名人事迹的大厅，金碧辉煌。',
                        monsters: []
                    },
                    k: { 
                        name: '中心广场', 
                        x: 1, 
                        y: 1, 
                        connections: ['b', 'i', 'j', 'd'],
                        description: '城市的中心广场，是重要的信息交汇处。',
                        monsters: [
                            {
                                type: 'STREET_THUG',
                                name: '街头混混',
                                icon: '👤',
                                level: 5,
                                description: '在武街闲逛的混混，喜欢挑衅路人'
                            },
                            {
                                type: 'MARTIAL_STUDENT',
                                name: '武馆学徒',
                                icon: '🥋',
                                level: 7,
                                description: '正在习武的学徒，掌握了基本的武学招式'
                            }
                        ]
                    },
                    l: { 
                        name: '南街', 
                        x: 2, 
                        y: 2, 
                        connections: ['h', 'i'],
                        description: '通往城南的主要街道，商贩的吆喝声不绝于耳。',
                        monsters: []
                    }
                },
                npcs: {
                    merchant: { 
                        node: 'h', 
                        name: '商人', 
                        icon: '💰', 
                        dialog: ['要买些什么吗？'],
                        description: '精明的商人，专门收购各种装备和材料'
                    },
                    elder: { 
                        node: 'a', 
                        name: '武馆长老', 
                        icon: '👴', 
                        dialog: ['年轻人，要勤加修炼。'],
                        description: '德高望重的馆长老，教导过无数武'
                    },
                    wizard: { 
                        node: 'g', 
                        name: '巫师', 
                        icon: '🧙', 
                        dialog: ['魔法是一门深奥的学问。'],
                        description: '神秘的巫师，精通各种法术'
                    }
                }
            },
            wild: {
                name: '幽暗森林',
                icon: '🌲',
                startNode: 'w1',
                nodes: {
                    w1: {
                        name: '森林入口',
                        x: 2,
                        y: 4,
                        connections: ['w2', 'w4', 'w5'],
                        description: '通往森林的入口，空气中弥漫着草木的清香。',
                        monsters: [
                            { 
                                type: 'WOLF',
                                name: '野狼', 
                                icon: '🐺', 
                                level: 15, 
                                description: '常见的野生猛兽，成群结队地活动' 
                            },
                            { 
                                type: 'FOREST_SNAKE',
                                name: '青竹蛇', 
                                icon: '🐍', 
                                level: 16, 
                                description: '潜伏在草丛中的小型蛇类' 
                            }
                        ]
                    },
                    w2: {
                        name: '密林深处',
                        x: 2,
                        y: 3,
                        connections: ['w1', 'w3', 'w6'],
                        description: '茂密的森林，阳光难以穿透树冠。',
                        monsters: [
                            { 
                                type: 'FOREST_SNAKE',
                                name: '森林巨蟒', 
                                icon: '🐍', 
                                level: 18, 
                                description: '盘踞在树上的大蛇，动作敏捷' 
                            },
                            { 
                                type: 'WOLF',
                                name: '森林狼王', 
                                icon: '🐺', 
                                level: 20, 
                                description: '狼群的首领，比普通野狼更加凶猛' 
                            }
                        ]
                    },
                    w3: {
                        name: '猎人小屋',
                        x: 3,
                        y: 3,
                        connections: ['w2', 'w7'],
                        description: '一间简陋的木屋，是猎人休息的地方。',
                        monsters: []
                    },
                    w4: {
                        name: '瀑布',
                        x: 1,
                        y: 4,
                        connections: ['w1', 'w8'],
                        description: '飞流直下的瀑布，水声轰鸣。',
                        monsters: [
                            { 
                                type: 'WATER_SPRITE',
                                name: '水灵', 
                                icon: '💧', 
                                level: 20, 
                                description: '由瀑布水汽凝聚而成的精灵' 
                            },
                            { 
                                type: 'FOREST_SNAKE',
                                name: '水蟒', 
                                icon: '🐍', 
                                level: 21, 
                                description: '栖息在瀑布附近的大型水蛇' 
                            }
                        ]
                    },
                    w5: {
                        name: '古树',
                        x: 2,
                        y: 5,
                        connections: ['w1', 'w9'],
                        description: '古老的树屋，树干上缠绕着神秘的符文。',
                        monsters: []
                    },
                    w6: {
                        name: '蘑菇林',
                        x: 2,
                        y: 2,
                        connections: ['w2', 'w10'],
                        description: '茂密的蘑菇林，空气中弥漫着蘑菇的香气。',
                        monsters: [
                            { 
                                type: 'WOLF',
                                name: '毒菌狼', 
                                icon: '🐺', 
                                level: 22, 
                                description: '常年生活在蘑菇林中的变异狼，带有毒性' 
                            },
                            { 
                                type: 'FOREST_SNAKE',
                                name: '菌蛇', 
                                icon: '🐍', 
                                level: 23, 
                                description: '以毒蘑菇为食的毒蛇' 
                            }
                        ]
                    },
                    w7: {
                        name: '兽穴',
                        x: 4,
                        y: 3,
                        connections: ['w3', 'w11'],
                        description: '阴森的兽穴，里面传来野兽的咆哮声。',
                        monsters: [
                            { 
                                type: 'WOLF',
                                name: '远古巨狼', 
                                icon: '🐺', 
                                level: 25, 
                                description: '体型巨大的远古狼族，极其危险' 
                            },
                            { 
                                type: 'ROCK_SPIDER',
                                name: '穴居蜘蛛', 
                                icon: '🕷️', 
                                level: 24, 
                                description: '在兽穴中筑巢的大型蜘蛛' 
                            }
                        ]
                    },
                    w8: {
                        name: '水潭',
                        x: 0,
                        y: 4,
                        connections: ['w4', 'w12'],
                        description: '清澈的水潭，潭底不时闪烁着神秘的光芒。',
                        monsters: [
                            { 
                                type: 'WATER_SPRITE',
                                name: '水潭精灵', 
                                icon: '💧', 
                                level: 23, 
                                description: '守护水潭的水元素生物' 
                            },
                            { 
                                type: 'FOREST_SNAKE',
                                name: '潭底巨蟒', 
                                icon: '🐍', 
                                level: 24, 
                                description: '潜伏在水潭底部的巨大水蛇' 
                            }
                        ]
                    },
                    w9: {
                        name: '树屋',
                        x: 2,
                        y: 6,
                        connections: ['w5', 'w13'],
                        description: '古老的树屋，树干上挂满了各种奇异的符文。',
                        monsters: []
                    },
                    w10: {
                        name: '迷雾谷',
                        x: 2,
                        y: 1,
                        connections: ['w6'],
                        description: '被迷雾笼罩的谷地，空气中弥漫着神秘的气息。',
                        monsters: [
                            { 
                                type: 'CLOUD_SPRITE',
                                name: '迷雾精灵', 
                                icon: '🧚', 
                                level: 26, 
                                description: '由迷雾凝聚而成的神秘生物' 
                            },
                            { 
                                type: 'WOLF',
                                name: '雾隐狼', 
                                icon: '🐺', 
                                level: 27, 
                                description: '善于利用迷雾隐藏身形的狼族' 
                            }
                        ]
                    },
                    w11: {
                        name: '狼窝',
                        x: 5,
                        y: 3,
                        connections: ['w7'],
                        description: '狼窝里传来野狼的嚎叫声，令人不寒而栗。',
                        monsters: [
                            { 
                                type: 'WOLF',
                                name: '狼王', 
                                icon: '🐺', 
                                level: 15, 
                                description: '狼群的首领，比普通野狼更加强大' 
                            }
                        ]
                    },
                    w12: {
                        name: '精灵泉',
                        x: 0,
                        y: 5,
                        connections: ['w8'],
                        description: '清澈的泉水，泉水里不时闪烁着神秘的光芒。',
                        monsters: [
                            { 
                                type: 'WATER_SPRITE',
                                name: '泉水精灵', 
                                icon: '💧', 
                                level: 14, 
                                description: '守护精灵泉的水灵' 
                            }
                        ]
                    },
                    w13: {
                        name: '枯木',
                        x: 3,
                        y: 6,
                        connections: ['w9'],
                        description: '枯木林里传来野兽的咆哮声，令人不寒而栗。',
                        monsters: []
                    }
                },
                npcs: {
                    hunter: {
                        node: 'w3',
                        name: '猎人',
                        icon: '🏹',
                        description: '经验丰富的猎人，对这片森林如指掌'
                    }
                }
            },
            mountain: {
                name: '云顶山脉',
                icon: '⛰️',
                startNode: 'm1',
                nodes: {
                    m1: { 
                        name: '山脚', 
                        x: 2, 
                        y: 4, 
                        connections: ['m2', 'm3', 'm4'],
                        description: '云顶山脉的入口，陡峭的山路向上延伸。空气清新，远处可以看到云雾缭绕的山峰。',
                        monsters: [
                            { 
                                type: 'MOUNTAIN_BANDIT',
                                name: '山贼', 
                                icon: '👤', 
                                level: 25, 
                                description: '在山间劫掠的强盗' 
                            },
                            { 
                                type: 'ROCK_SPIDER',
                                name: '岩蛛', 
                                icon: '🕷️', 
                                level: 27, 
                                description: '在峭壁上筑巢的巨型蜘蛛' 
                            }
                        ]
                    },
                    m2: { 
                        name: '石阶', 
                        x: 2, 
                        y: 3, 
                        connections: ['m1', 'm5', 'm6'],
                        description: '古老的石阶蜿蜒向上，两旁是陡峭的悬崖。石阶上布满了岁月的痕迹。',
                        monsters: [
                            { 
                                type: 'MOUNTAIN_BANDIT',
                                name: '山贼', 
                                icon: '👤', 
                                level: 18, 
                                description: '盘踞山间的强盗' 
                            }
                        ]
                    },
                    m3: { 
                        name: '悬崖', 
                        x: 1, 
                        y: 4, 
                        connections: ['m1', 'm7'],
                        description: '危险的悬崖峭壁，强风呼啸而过。需要小心谨慎地攀爬。',
                        monsters: [
                            { 
                                type: 'MOUNTAIN_EAGLE',
                                name: '山鹰', 
                                icon: '🦅', 
                                level: 30, 
                                description: '在悬崖间盘旋的猛禽' 
                            }
                        ]
                    },
                    m4: { 
                        name: '山洞', 
                        x: 3, 
                        y: 4, 
                        connections: ['m1', 'm8'],
                        description: '深邃的山洞，洞内阴暗潮湿。墙壁上有奇异的矿物闪烁。',
                        monsters: [
                            { 
                                type: 'CAVE_BAT',
                                name: '洞穴蝙蝠', 
                                icon: '🦇', 
                                level: 28, 
                                description: '成群结队的蝙蝠' 
                            },
                            { 
                                type: 'ROCK_GOLEM',
                                name: '岩石怪', 
                                icon: '🪨', 
                                level: 32, 
                                description: '由岩石构成的奇怪生物' 
                            }
                        ]
                    },
                    m5: { 
                        name: '云雾带', 
                        x: 2, 
                        y: 2, 
                        connections: ['m2', 'm9'],
                        description: '被浓密云雾笼罩的区域，能见度极低。云雾中传来神秘的声音。',
                        monsters: [
                            { 
                                type: 'CLOUD_SPRITE',
                                name: '云雾精灵', 
                                icon: '🧚', 
                                level: 35, 
                                description: '云雾中生存的神秘生物' 
                            }
                        ]
                    },
                    m6: { 
                        name: '古道', 
                        x: 3, 
                        y: 3, 
                        connections: ['m2', 'm10'],
                        description: '年代久远的山间古道，两旁是古老的石碑和雕像。',
                        monsters: [
                            { 
                                type: 'STONE_STATUE',
                                name: '石像怪', 
                                icon: '🗿', 
                                level: 19, 
                                description: '栩栩如生的石像突然活了过来' 
                            }
                        ]
                    },
                    m7: { 
                        name: '峭壁', 
                        x: 0, 
                        y: 4, 
                        connections: ['m3', 'm11'],
                        description: '几乎垂直的峭壁，攀爬难度极大。岩壁上有些许可以攀附的凸起。',
                        monsters: [
                            { 
                                type: 'ROCK_SPIDER',
                                name: '岩蛛', 
                                icon: '🕷️', 
                                level: 21, 
                                description: '在峭壁上筑巢的巨型蜘蛛' 
                            }
                        ]
                    },
                    m8: { 
                        name: '矿洞', 
                        x: 4, 
                        y: 4, 
                        connections: ['m4', 'm12'],
                        description: '废弃的矿洞，到处散落着矿石和工具。隐约可见矿脉的痕迹。',
                        monsters: [
                            { 
                                type: 'ROCK_GOLEM',
                                name: '矿洞守卫', 
                                icon: '🪨', 
                                level: 23, 
                                description: '守护矿洞的岩石怪物' 
                            }
                        ]
                    },
                    m9: { 
                        name: '山顶寺', 
                        x: 2, 
                        y: 1,
                        connections: ['m5'],
                        description: '云顶山脉最高处的古老寺庙，常年云雾缭绕。寺内钟声悠扬。',
                        monsters: [
                            { 
                                type: 'CLOUD_SPRITE',
                                name: '云雾武僧', 
                                icon: '🧚', 
                                level: 25, 
                                description: '修炼云雾之力的武僧' 
                            }
                        ]
                    },
                    m10: { 
                        name: '雪原', 
                        x: 4, 
                        y: 3, 
                        connections: ['m6'],
                        description: '终年积雪的高原，寒风刺骨。雪地上留有各种生物的足迹。',
                        monsters: [
                            { 
                                type: 'WOLF',
                                name: '雪原狼王', 
                                icon: '🐺', 
                                level: 24, 
                                description: '雪原上的狼群首领' 
                            }
                        ]
                    },
                    m11: { 
                        name: '鹰巢', 
                        x: 0, 
                        y: 3, 
                        connections: ['m7'],
                        description: '巨鹰在此筑巢，巢穴中散落着各种闪亮的物品。',
                        monsters: [
                            { 
                                type: 'MOUNTAIN_EAGLE',
                                name: '巨鹰', 
                                icon: '🦅', 
                                level: 26, 
                                description: '盘踞在此的远古巨鹰' 
                            }
                        ]
                    },
                    m12: { 
                        name: '地岩', 
                        x: 5, 
                        y: 4, 
                        connections: ['m8'],
                        description: '山脉深处的神秘洞穴，传说中蕴含着强大的力量。',
                        monsters: [
                            { 
                                type: 'ROCK_GOLEM',
                                name: '地岩守护者', 
                                icon: '🗿', 
                                level: 28, 
                                description: '守护地岩秘密的远古生物' 
                            }
                        ]
                    }
                },
                npcs: {
                    guide: {
                        node: 'm1',
                        name: '老向导',
                        icon: '👴',
                        description: '经验丰富的山路向导，对云顶山脉了如指掌',
                        dialog: ['这山路可不好走，要小心啊。', '我年轻时候没少在这山上跑。']
                    },
                    monk: {
                        node: 'm9',
                        name: '云顶禅师',
                        icon: '🧘',
                        description: '在山顶寺修行多年的得道高僧',
                        dialog: ['云来云去，皆是虚幻。', '悟道之路，贵在坚持。']
                    },
                    miner: {
                        node: 'm8',
                        name: '老矿工',
                        icon: '⛏️',
                        description: '在矿洞工作多年的矿工',
                        dialog: ['这矿洞里的宝贝可不少。', '小心点，洞里不太平。']
                    }
                }
            },
            desert: {
                name: '流沙荒漠',
                icon: '🏜️',
                startNode: 'd1',
                nodes: {
                    d1: { 
                        name: '绿洲', 
                        x: 2, 
                        y: 4, 
                        connections: ['d2', 'd3', 'd4'],
                        description: '沙漠中难得的绿洲，椰枣树环绕着清澈的水潭。这里是商队休息的驿站。',
                        monsters: [
                            { 
                                type: 'DESERT_LIZARD',
                                name: '沙蜥', 
                                icon: '🦎', 
                                level: 30, 
                                description: '适应沙漠环境的大型蜥蜴' 
                            },
                            {
                                type: 'WATER_SPRITE',
                                name: '绿洲精灵',
                                icon: '💧',
                                level: 31,
                                description: '守护绿洲水源的水元素生物'
                            }
                        ]
                    },
                    d2: { 
                        name: '沙丘', 
                        x: 2, 
                        y: 3, 
                        connections: ['d1', 'd5', 'd6'],
                        description: '连绵起伏的沙丘，金色的沙粒在阳光下闪闪发光。风吹过时，沙丘会发出低沉的呜咽声。',
                        monsters: [
                            { 
                                type: 'SAND_WORM',
                                name: '沙虫', 
                                icon: '🪱', 
                                level: 32, 
                                description: '潜伏在沙下的巨型虫类' 
                            },
                            {
                                type: 'DESERT_BANDIT',
                                name: '沙匪',
                                icon: '👥',
                                level: 33,
                                description: '在沙漠中劫掠商队的强盗'
                            }
                        ]
                    },
                    d3: { 
                        name: '遗迹', 
                        x: 1, 
                        y: 4, 
                        connections: ['d1', 'd7'],
                        description: '古老文明留下的建筑遗迹，大部分已被黄沙掩埋。墙壁上刻着神秘的符文。',
                        monsters: [
                            { 
                                type: 'STONE_GOLEM',
                                name: '守卫傀儡', 
                                icon: '🗿', 
                                level: 35, 
                                description: '守护遗迹的远古机关' 
                            },
                            {
                                type: 'DESERT_MAGE',
                                name: '遗迹法师',
                                icon: '🧙',
                                level: 36,
                                description: '研究古代魔法的法师'
                            }
                        ]
                    },
                    d4: { 
                        name: '蛇窟', 
                        x: 3, 
                        y: 4, 
                        connections: ['d1', 'd8'],
                        description: '盘踞着大量沙蛇的洞穴，地面上留有蜿蜒的痕迹。空气中弥漫着危险的气息。',
                        monsters: [
                            { 
                                type: 'DESERT_SNAKE',
                                name: '沙漠眼镜蛇', 
                                icon: '🐍', 
                                level: 33, 
                                description: '毒性剧烈的沙漠蛇类' 
                            },
                            {
                                type: 'DESERT_SNAKE',
                                name: '双头蝰蛇',
                                icon: '🐍',
                                level: 34,
                                description: '罕见的双头毒蛇，攻击极其致命'
                            }
                        ]
                    },
                    d5: { 
                        name: '流沙区', 
                        x: 2, 
                        y: 2, 
                        connections: ['d2', 'd9'],
                        description: '危险的流沙地带，稍有不慎就会被吞噬。地面不时传来诡异的震动。',
                        monsters: [
                            { 
                                type: 'SAND_SPIRIT',
                                name: '沙怪', 
                                icon: '👻', 
                                level: 36, 
                                description: '由流沙形成的神秘生物' 
                            },
                            {
                                type: 'SAND_WORM',
                                name: '噬沙巨虫',
                                icon: '🪱',
                                level: 37,
                                description: '能掀起沙暴的巨型沙虫'
                            }
                        ]
                    },
                    d6: { 
                        name: '骨骸谷', 
                        x: 3, 
                        y: 3, 
                        connections: ['d2', 'd10'],
                        description: '遍布着远古生物骨骸的峡谷，传说这里曾发生过惊天动的大战。',
                        monsters: [
                            { 
                                type: 'BONE_WARRIOR',
                                name: '骨骸守卫', 
                                icon: '💀', 
                                level: 38, 
                                description: '由骨骸复活的亡灵生物' 
                            },
                            {
                                type: 'BONE_MAGE',
                                name: '骨骸法师',
                                icon: '💀',
                                level: 39,
                                description: '掌握死灵魔法的骷髅法师'
                            }
                        ]
                    },
                    d7: { 
                        name: '古墓', 
                        x: 0, 
                        y: 4, 
                        connections: ['d3', 'd11'],
                        description: '古代帝王的陵墓，入口处雕刻着威严的石像。墓中暗藏机关，危机四伏。',
                        monsters: [
                            { 
                                type: 'MUMMY',
                                name: '木乃伊', 
                                icon: '🧟', 
                                level: 40, 
                                description: '被诅咒的古代遗体' 
                            },
                            {
                                type: 'MUMMY_PRIEST',
                                name: '木乃伊祭司',
                                icon: '🧟',
                                level: 41,
                                description: '掌握古代诅咒的木乃伊祭司'
                            }
                        ]
                    },
                    d8: { 
                        name: '沙暴眼', 
                        x: 4, 
                        y: 4, 
                        connections: ['d4', 'd12'],
                        description: '永不停息的沙暴中心，强大的风力能将一切撕碎。这里蕴含着神秘的力量。',
                        monsters: [
                            { 
                                type: 'WIND_ELEMENTAL',
                                name: '风元素', 
                                icon: '🌪️', 
                                level: 42, 
                                description: '由沙暴凝聚而成的元素生物' 
                            },
                            {
                                type: 'STORM_SPIRIT',
                                name: '沙暴之灵',
                                icon: '🌪️',
                                level: 43,
                                description: '操控沙暴的强大元素生物'
                            }
                        ]
                    },
                    d9: { 
                        name: '失落神殿', 
                        x: 2, 
                        y: 1, 
                        connections: ['d5'],
                        description: '沙漠深处的神秘神殿，据说供奉着远古的沙漠之神。神殿中藏有无价之宝。',
                        monsters: [
                            { 
                                type: 'TEMPLE_GUARDIAN',
                                name: '神殿守卫', 
                                icon: '👹', 
                                level: 45, 
                                description: '守护神殿的远古战士' 
                            },
                            {
                                type: 'TEMPLE_PRIEST',
                                name: '神殿祭司',
                                icon: '👳',
                                level: 46,
                                description: '侍奉沙漠之神的神秘祭司'
                            }
                        ]
                    },
                    d10: { 
                        name: '魔物巢穴', 
                        x: 4, 
                        y: 3, 
                        connections: ['d6'],
                        description: '沙漠魔物的老巢，空气中充满了邪恶的气息。这里是冒险者的禁地。',
                        monsters: [
                            { 
                                type: 'DESERT_DEMON',
                                name: '沙漠魔王', 
                                icon: '👿', 
                                level: 47, 
                                description: '统治沙漠魔物的首领' 
                            },
                            {
                                type: 'DEMON_GUARD',
                                name: '魔物守卫',
                                icon: '👹',
                                level: 46,
                                description: '效忠魔王的强大魔物'
                            }
                        ]
                    },
                    d11: { 
                        name: '地下城', 
                        x: 0, 
                        y: 3, 
                        connections: ['d7'],
                        description: '古墓下方的庞大地下城，错综复杂的通道中埋藏着无数秘密。',
                        monsters: [
                            { 
                                type: 'UNDEAD_WARRIOR',
                                name: '地下守卫', 
                                icon: '💂', 
                                level: 44, 
                                description: '守护地下城的永恒战士' 
                            },
                            {
                                type: 'UNDEAD_MAGE',
                                name: '地下法师',
                                icon: '🧙',
                                level: 45,
                                description: '掌握死灵法术的不死法师'
                            }
                        ]
                    },
                    d12: { 
                        name: '死亡峡谷', 
                        x: 5, 
                        y: 4, 
                        connections: ['d8'],
                        description: '沙漠中最危险的地方，传说这里是死亡之神的领域。鲜有人能活着离开。',
                        monsters: [
                            { name: '死亡使者', icon: '💀', level: 48, description: '死亡之神的仆从' }
                        ]
                    }
                },
                npcs: {
                    merchant: {
                        node: 'd1',
                        name: '沙漠商人',
                        icon: '👳',
                        description: '常年在沙漠中经商的老练商人',
                        dialog: ['这里的天气可真是糟糕。', '要买些防身的装备吗？']
                    },
                    guide: {
                        node: 'd2',
                        name: '沙漠向导',
                        icon: '🧔',
                        description: '熟悉沙漠地形的老向导',
                        dialog: ['小心流沙，它们比看起来要危险得多。', '跟着我的脚步走，我带你找到绿洲。']
                    },
                    archaeologist: {
                        node: 'd3',
                        name: '考古学者',
                        icon: '👨‍🔬',
                        description: '研究古代文明的学者',
                        dialog: ['这些遗迹中藏有惊人的秘密。', '你相信这片沙漠下曾经是一片繁华的城市吗？']
                    }
                }
            },
            dungeon: {
                name: '地下迷宫',
                icon: '🏛️',
                startNode: 'u1',
                nodes: {
                    u1: { 
                        name: '入口大厅', 
                        x: 2, 
                        y: 4, 
                        connections: ['u2', 'u3', 'u4'],
                        description: '宏伟的地下大厅，古老的石柱上刻满了神秘的符文。火把的光芒在墙上投下摇曳的影子。',
                        monsters: [
                            { 
                                type: 'STONE_GOLEM',
                                name: '石像鬼', 
                                icon: '👹', 
                                level: 50, 
                                description: '守护入口的魔物' 
                            },
                            {
                                type: 'UNDEAD_WARRIOR',
                                name: '地下守卫',
                                icon: '💂',
                                level: 51,
                                description: '巡逻的不死战士'
                            }
                        ]
                    },
                    u2: { 
                        name: '石像大厅', 
                        x: 2, 
                        y: 3, 
                        connections: ['u1', 'u5', 'u6'],
                        description: '摆放着众多栩栩如生的石像，每个石像都仿佛在注视着来访者。',
                        monsters: [
                            { 
                                type: 'STONE_STATUE',
                                name: '活化石像', 
                                icon: '🗿', 
                                level: 52, 
                                description: '突然活过来的石像' 
                            },
                            {
                                type: 'STONE_MAGE',
                                name: '石像法师',
                                icon: '🗿',
                                level: 53,
                                description: '操控石像的神秘法师'
                            }
                        ]
                    },
                    u3: { 
                        name: '藏宝室', 
                        x: 1, 
                        y: 4, 
                        connections: ['u1', 'u7'],
                        description: '堆满金币和宝物的房间，但大多数都是陷阱和幻象。',
                        monsters: [
                            { 
                                type: 'MIMIC',
                                name: '宝箱怪', 
                                icon: '📦', 
                                level: 54, 
                                description: '伪装成宝箱的危险魔物' 
                            },
                            {
                                type: 'TREASURE_GUARDIAN',
                                name: '财宝守护者',
                                icon: '🐉',
                                level: 55,
                                description: '守护财宝的远古生物'
                            }
                        ]
                    },
                    u4: { 
                        name: '机关室', 
                        x: 3, 
                        y: 4, 
                        connections: ['u1', 'u8'],
                        description: '布满各种致命机关的房间，地板上还留有冒险者的血迹。',
                        monsters: [
                            { 
                                type: 'MECHANICAL_GOLEM',
                                name: '机械傀儡', 
                                icon: '🤖', 
                                level: 53, 
                                description: '自动运转的古代机关' 
                            },
                            {
                                type: 'TRAP_SPIRIT',
                                name: '机关之灵',
                                icon: '👻',
                                level: 54,
                                description: '操控机关的神秘灵体'
                            }
                        ]
                    },
                    u5: { 
                        name: '祭坛', 
                        x: 2, 
                        y: 2, 
                        connections: ['u2', 'u9'],
                        description: '古老的祭祀场所，祭坛上还残留着不明的暗红色痕迹。',
                        monsters: [
                            { 
                                type: 'DARK_PRIEST',
                                name: '黑暗祭司', 
                                icon: '👻', 
                                level: 56, 
                                description: '执行黑暗仪式的亡灵' 
                            },
                            {
                                type: 'BLOOD_ELEMENTAL',
                                name: '血之精灵',
                                icon: '💉',
                                level: 57,
                                description: '由祭品之血凝聚而成的生物'
                            }
                        ]
                    },
                    u6: { 
                        name: '武器库', 
                        x: 3, 
                        y: 3, 
                        connections: ['u2', 'u10'],
                        description: '存放着各种古代武器的房间，大多数武器已经锈迹斑斑。',
                        monsters: [
                            { 
                                type: 'WEAPON_SPIRIT',
                                name: '武器之灵', 
                                icon: '⚔️', 
                                level: 55, 
                                description: '寄宿在古代武器中的灵魂' 
                            },
                            {
                                type: 'ARMOR_GOLEM',
                                name: '装甲守卫',
                                icon: '🛡️',
                                level: 56,
                                description: '由古代铠甲构成的守卫'
                            }
                        ]
                    },
                    u7: { 
                        name: '密室', 
                        x: 0, 
                        y: 4, 
                        connections: ['u3', 'u11'],
                        description: '隐藏着重要秘密的房间，墙上的壁画讲述着古老的预言。',
                        monsters: [
                            { 
                                type: 'SHADOW_ASSASSIN',
                                name: '暗影刺客', 
                                icon: '👥', 
                                level: 57, 
                                description: '潜伏在黑暗中的刺客' 
                            },
                            {
                                type: 'PROPHECY_KEEPER',
                                name: '预言守护者',
                                icon: '📜',
                                level: 58,
                                description: '守护古老预言的神秘存在'
                            }
                        ]
                    },
                    u8: { 
                        name: '陷阱走廊', 
                        x: 4, 
                        y: 4, 
                        connections: ['u4', 'u12'],
                        description: '长长的走廊布满了各种致命陷阱，需要小心谨慎地通过。',
                        monsters: [
                            { 
                                type: 'PHANTOM_BLADE',
                                name: '幻影刺客', 
                                icon: '🗡️', 
                                level: 58, 
                                description: '伪装成陷阱的刺客' 
                            },
                            {
                                type: 'CORRIDOR_WRAITH',
                                name: '走廊幽魂',
                                icon: '👻',
                                level: 59,
                                description: '徘徊在走廊中的不死亡灵'
                            }
                        ]
                    },
                    u9: { 
                        name: '魔法实验室', 
                        x: 2, 
                        y: 1, 
                        connections: ['u5'],
                        description: '进行黑暗魔法实验的场所，空气中充满了魔力的波动。',
                        monsters: [
                            { 
                                type: 'MAD_WIZARD',
                                name: '疯狂法师', 
                                icon: '🧙', 
                                level: 60, 
                                description: '陷入疯狂的实验法师' 
                            },
                            {
                                type: 'MAGIC_ABERRATION',
                                name: '魔法畸变体',
                                icon: '🧪',
                                level: 61,
                                description: '实验失败产生的可怕生物'
                            }
                        ]
                    },
                    u10: { 
                        name: '训练场', 
                        x: 4, 
                        y: 3, 
                        connections: ['u6'],
                        description: '古代战士训练的场所，地面上留有无数战斗的痕迹。',
                        monsters: [
                            { 
                                type: 'ETERNAL_SWORDSMAN',
                                name: '永恒剑士', 
                                icon: '⚔️', 
                                level: 59, 
                                description: '永远在训练的不死剑术大师' 
                            },
                            {
                                type: 'TRAINING_PHANTOM',
                                name: '训练幻影',
                                icon: '👤',
                                level: 60,
                                description: '由战士执念形成的幻影'
                            }
                        ]
                    },
                    u11: { 
                        name: '地牢', 
                        x: 0, 
                        y: 3, 
                        connections: ['u7'],
                        description: '关押犯人和怪物的地牢，充满了痛苦和绝望的气息。',
                        monsters: [
                            { 
                                type: 'PRISON_KEEPER',
                                name: '狱卒', 
                                icon: '👹', 
                                level: 61, 
                                description: '残暴的地牢看守' 
                            },
                            {
                                type: 'TORTURED_SOUL',
                                name: '受刑之魂',
                                icon: '👻',
                                level: 62,
                                description: '被折磨而扭曲的灵魂'
                            }
                        ]
                    },
                    u12: { 
                        name: '最终之间', 
                        x: 5, 
                        y: 4, 
                        connections: ['u8'],
                        description: '迷宫最深处的神秘房间，传说中封印着远古的邪恶。',
                        monsters: [
                            { 
                                type: 'DUNGEON_LORD',
                                name: '迷宫之主', 
                                icon: '👑', 
                                level: 65, 
                                description: '统治地下迷宫的最终boss' 
                            },
                            {
                                type: 'ANCIENT_EVIL',
                                name: '远古邪物',
                                icon: '👿',
                                level: 66,
                                description: '被封印的远古邪恶存在'
                            }
                        ]
                    }
                },
                npcs: {
                    explorer: {
                        node: 'u1',
                        name: '探险家',
                        icon: '🗺️',
                        description: '经验丰富的地下迷宫探险专家',
                        dialog: ['这个迷宫比我见过的都要危险。', '要小心那些看似静止的石像。']
                    },
                    wizard: {
                        node: 'u9',
                        name: '神秘法师',
                        icon: '🧙‍♂️',
                        description: '在实验室研究古代魔法的法师',
                        dialog: ['这里的魔法能量非常不稳定。', '你感觉到空气中的魔力波动了吗？']
                    },
                    ghost: {
                        node: 'u7',
                        name: '游魂',
                        icon: '👻',
                        description: '徘徊在迷宫中的古代灵魂',
                        dialog: ['我已经在这里徘徊了几个世纪...', '想知道这里的秘密吗？']
                    }
                }
            }
        };

        this.currentMap = 'city';
        this.currentNode = this.maps[this.currentMap].startNode;
        
        this.isDragging = false;
        this.dragStart = { x: 0, y: 0 };
        this.currentTranslate = { x: 0, y: 0 };
        this.previousTranslate = { x: 0, y: 0 };
        this.dragBounds = {
            minX: -500,
            maxX: 500,
            minY: -500,
            maxY: 500
        };

        this.isSpacePressed = false;

        this.startDragging = this.startDragging.bind(this);
        this.drag = this.drag.bind(this);
        this.stopDragging = this.stopDragging.bind(this);

        this.initialize();
    }

    initialize() {
        //console.log('Initializing MapSystem...');
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                //console.log('DOM Content Loaded - initializing map');
                this.renderMap();
                this.setupAllEvents();
            });
        } else {
            //console.log('DOM already loaded - initializing map');
            this.renderMap();
            this.setupAllEvents();
        }
    }

    renderMap() {
        const gameScene = document.querySelector('.game-scene');
        if (!gameScene) return;

        const currentTransform = { ...this.currentTranslate };

        gameScene.innerHTML = `
            <div class="map-container">
                <div class="map-switch">
                    <button class="map-switch-btn">
                        <span class="map-icon">${this.maps[this.currentMap].icon}</span>
                        <span class="map-name">${this.maps[this.currentMap].name}</span>
                    </button>
                    <div class="map-list">
                        ${Object.entries(this.maps).map(([id, map]) => `
                            <div class="map-item ${id === this.currentMap ? 'active' : ''}" 
                                 data-map="${id}">
                                <span class="map-icon">${map.icon}</span>
                                <span class="map-name">${map.name}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div class="map-grid">
                    ${this.generateMapNodes()}
                </div>
            </div>
            <div class="location-info">
                ${this.generateLocationInfo()}
            </div>
        `;

        this.updatePlayerPosition();
        this.renderNPCs();
        this.setupAllEvents();

        this.currentTranslate = currentTransform;
        this.applyTransform();

        requestAnimationFrame(() => {
            this.centerOnCurrentNode();
        });
    }

    generateLocationInfo() {
        const currentMap = this.getCurrentMapData();
        const currentLocation = currentMap.nodes[this.currentNode];
        const npcsHere = Object.entries(currentMap.npcs || {})
            .filter(([_, npc]) => npc.node === this.currentNode);
        const monstersHere = currentLocation.monsters || [];

        return `
            <div class="auto-combat-controls">
                <select class="monster-select">
                    <option value="">选择目标怪物...</option>
                    ${monstersHere.map((monster, index) => `
                        <option value="${index}">${monster.name} Lv.${monster.level}</option>
                    `).join('')}
                </select>
                <div class="auto-combat-toggle">
                    <label class="toggle-switch">
                        <input type="checkbox" class="auto-combat-checkbox">
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="toggle-label">自动战斗</span>
                </div>
            </div>
            <div class="location-header">
                <div class="location-title">
                    <div class="location-name">${currentLocation.name}</div>
                    <button class="close-location-btn">×</button>
                </div>
                <div class="location-description">${currentLocation.description}</div>
            </div>
            <div class="location-content">
                <div class="content-section">
                    <div class="section-title">
                        <span class="section-icon">👥</span>
                        NPC
                    </div>
                    <div class="entity-list">
                        ${npcsHere.map(([id, npc]) => `
                            <div class="entity-item" data-entity-type="npc" data-entity-id="${id}">
                                <div class="entity-icon">${npc.icon}</div>
                                <div class="entity-info">
                                    <div class="entity-name">${npc.name}</div>
                                    <div class="entity-description">${npc.description}</div>
                                </div>
                                <div class="entity-interact">👆</div>
                            </div>
                        `).join('') || '<div class="empty-message">这里没有NPC</div>'}
                    </div>
                </div>
                
                <div class="content-section">
                    <div class="section-title">
                        <span class="section-icon">👾</span>
                        怪物
                    </div>
                    <div class="entity-list">
                        ${monstersHere.map((monster, index) => `
                            <div class="entity-item" data-entity-type="monster" data-entity-id="${monster.id || index}">
                                <div class="entity-icon">${monster.icon}</div>
                                <div class="entity-info">
                                    <div class="entity-name">${monster.name} Lv.${monster.level}</div>
                                    <div class="entity-description">${monster.description}</div>
                                </div>
                                <div class="entity-interact">⚔️</div>
                            </div>
                        `).join('') || '<div class="empty-message">这里没有怪物</div>'}
                    </div>
                </div>
            </div>
        `;
    }

    generateMapNodes() {
        const currentMap = this.getCurrentMapData();
        let nodesHTML = '';
        
        //console.log('Generating map nodes for map:', this.currentMap);
        //console.log('Current node:', this.currentNode);
        
        for (const [id, node] of Object.entries(currentMap.nodes)) {
            const isCurrentNode = id === this.currentNode;
            const isConnected = currentMap.nodes[this.currentNode].connections.includes(id);
            
            //console.log('Node:', id, {
            //    isCurrent: isCurrentNode,
            //    isConnected: isConnected,
            //    connections: node.connections
            //});

            nodesHTML += `
                <div class="map-node ${isCurrentNode ? 'current' : ''} ${isConnected ? 'connected' : ''}" 
                     data-node-id="${id}" 
                     style="grid-column: ${node.x + 1}; grid-row: ${node.y + 1};"
                     title="${isConnected ? '点击移动到此处' : ''}">
                    <span class="node-name">${node.name}</span>
                    ${this.generateConnections(id, node)}
                </div>
            `;
        }
        return nodesHTML;
    }

    generateConnections(nodeId, node) {
        let connectionsHTML = '';
        node.connections.forEach(targetId => {
            const targetNode = this.maps[this.currentMap].nodes[targetId];
            if (targetNode) {
                const dx = targetNode.x - node.x;
                const dy = targetNode.y - node.y;
                
                const isAvailable = nodeId === this.currentNode;
                const availableClass = isAvailable ? 'available' : '';
                
                if (dx !== 0) {
                    connectionsHTML += `
                        <div class="map-connection horizontal ${availableClass}" 
                             style="left: ${dx > 0 ? '100%' : '-10px'}; top: 50%;">
                        </div>
                    `;
                }
                if (dy !== 0) {
                    connectionsHTML += `
                        <div class="map-connection vertical ${availableClass}" 
                             style="top: ${dy > 0 ? '100%' : '-10px'}; left: 50%;">
                        </div>
                    `;
                }
            }
        });
        return connectionsHTML;
    }

    updatePlayerPosition() {
        const currentNode = document.querySelector(`[data-node-id="${this.currentNode}"]`);
        if (!currentNode) return;

        const playerMarker = document.createElement('div');
        playerMarker.className = 'player-marker';
        playerMarker.innerHTML = gameManager.currentPlayer ? 
            Character.getClassIcon(gameManager.currentPlayer.class) : '👤';
        
        currentNode.appendChild(playerMarker);
    }

    renderNPCs() {
        Object.entries(this.maps[this.currentMap].npcs).forEach(([id, npc]) => {
            const node = document.querySelector(`[data-node-id="${npc.node}"]`);
            if (!node) return;

            const npcMarker = document.createElement('div');
            npcMarker.className = 'npc-marker';
            npcMarker.innerHTML = npc.icon;
            npcMarker.title = npc.name;
            
            const offset = 20;
            npcMarker.style.left = `${Math.random() * offset + 35}%`;
            npcMarker.style.top = `${Math.random() * offset + 35}%`;
            
            node.appendChild(npcMarker);
        });
    }

    setupEventListeners() {
        const mapContainer = document.querySelector('.map-container');
        if (mapContainer) {
            mapContainer.addEventListener('mousedown', this.startDragging.bind(this));
            document.addEventListener('mousemove', this.drag.bind(this));
            document.addEventListener('mouseup', this.stopDragging.bind(this));
            
            mapContainer.addEventListener('touchstart', this.startDragging.bind(this));
            document.addEventListener('touchmove', this.drag.bind(this));
            document.addEventListener('touchend', this.stopDragging.bind(this));
        }

        document.addEventListener('click', (e) => {
            if (this.isDragging) return;

            const node = e.target.closest('.map-node');
            if (!node) return;

            const nodeId = node.dataset.nodeId;
            if (!nodeId) return;

            if (this.canMoveTo(nodeId)) {
                this.moveToNode(nodeId);
            } else {
                gameManager.showFloatingTip('无法到达该位置！', 'error');
            }
        });
    }

    startDragging(e) {
        if (!this.isSpacePressed) return;

        //console.log('Start dragging with space pressed');
        
        this.isDragging = true;
        const mapContainer = document.querySelector('.map-container');
        if (mapContainer) {
            mapContainer.classList.add('grabbing');
        }

        this.dragStart = {
            x: e.clientX - this.currentTranslate.x,
            y: e.clientY - this.currentTranslate.y
        };
    }

    drag(e) {
        if (!this.isDragging) return;

        const newX = e.clientX - this.dragStart.x;
        const newY = e.clientY - this.dragStart.y;

        this.currentTranslate = {
            x: Math.max(this.dragBounds.minX, Math.min(this.dragBounds.maxX, newX)),
            y: Math.max(this.dragBounds.minY, Math.min(this.dragBounds.maxY, newY))
        };

        this.applyTransform();
    }

    stopDragging(e) {
        if (!this.isDragging) return;

        //console.log('Stop dragging');
        
        const mapContainer = document.querySelector('.map-container');
        if (mapContainer) {
            mapContainer.classList.remove('grabbing');
        }

        this.isDragging = false;
        this.previousTranslate = { ...this.currentTranslate };
    }

    canMoveTo(targetNodeId) {
        const currentMap = this.getCurrentMapData();
        const currentNode = currentMap.nodes[this.currentNode];
        const targetNode = currentMap.nodes[targetNodeId];

        // 检查节点是否存在
        if (!targetNode) {
            //console.log('Target node does not exist');
            return {
                canMove: false,
                reason: '目标位置不存在'
            };
        }

        // 检查是否是当前位置
        if (targetNodeId === this.currentNode) {
            //console.log('Already at this location');
            return {
                canMove: false,
                reason: '已经在该位置'
            };
        }

        // 检查是否有直接连接
        const isConnected = currentNode.connections.includes(targetNodeId);
        if (!isConnected) {
            //console.log('No direct path to target node');
            return {
                canMove: false,
                reason: '无法直接到达该位置'
            };
        }

        // 检查是否有特殊条件限制(可以根据需要添加更多条件)
        // 例如: 等级要求、任务要求等

        //console.log('Can move to node:', targetNodeId);
        return {
            canMove: true
        };
    }

    getClassName(characterClass) {
        const classNames = {
            mage: '法师',
            warrior: '战士',
            monk: '武者',
            taoist: '道士'
        };
        return classNames[characterClass] || characterClass;
    }

    moveToNode(nodeId) {
        //console.log('Moving to node:', nodeId);
        const currentMap = this.getCurrentMapData();
        const targetNode = currentMap.nodes[nodeId];

        // 更新当前位置
        this.currentNode = nodeId;

        // 立即居中显示新位置
        this.centerOnCurrentNode();

        // 显示到达提示
        gameManager.showFloatingTip(`已到达${targetNode.name}`, 'success');

        // 重新渲染地图以更新连接状态
        setTimeout(() => {
            this.renderMap();
            // 确保渲染后仍然居中
            requestAnimationFrame(() => {
                this.centerOnCurrentNode();
            });
        }, 500);
    }

    getCurrentMapData() {
        return this.maps[this.currentMap];
    }

    applyTransform() {
        const mapGrid = document.querySelector('.map-grid');
        if (mapGrid) {
            const transform = `translate(${this.currentTranslate.x}px, ${this.currentTranslate.y}px)`;
            mapGrid.style.transform = transform;
            //console.log('Applied transform:', transform);
        }
    }

    centerMap() {
        const container = document.querySelector('.map-container');
        const mapGrid = document.querySelector('.map-grid');
        if (!container || !mapGrid) return;

        requestAnimationFrame(() => {
            const containerRect = container.getBoundingClientRect();
            const mapRect = mapGrid.getBoundingClientRect();

            // 计算基础偏移，使地图居中
            const offsetX = (containerRect.width - mapRect.width) / 2;
            const offsetY = (containerRect.height - mapRect.height) / 2;

            // 不再添加额外的固定偏移
            this.currentTranslate = { 
                x: offsetX, 
                y: offsetY 
            };
            this.previousTranslate = { ...this.currentTranslate };

            this.applyTransform();

            const currentNode = document.querySelector(`[data-node-id="${this.currentNode}"]`);
            if (currentNode) {
                currentNode.classList.add('current');
            }
        });
    }

    setupDragEvents() {
        const mapContainer = document.querySelector('.map-container');
        if (!mapContainer) return;

        // 只有在按住空格键时才能拖动
        mapContainer.addEventListener('mousedown', (e) => {
            // 只在按住空格键时响应左键拖动
            if (e.button !== 0 || !this.isSpacePressed) return;
            
            // 如果点击的是地图节点，不动拖动
            if (e.target.closest('.map-node')) return;
            
            e.preventDefault();
            this.startDragging(e);
        });

        document.addEventListener('mousemove', (e) => {
            if (this.isDragging) {
                e.preventDefault();
                this.drag(e);
            }
        });

        document.addEventListener('mouseup', (e) => {
            if (this.isDragging) {
                this.stopDragging(e);
                // 拖动束后重新居中
                requestAnimationFrame(() => {
                    this.centerOnCurrentNode();
                });
            }
        });
    }

    setupClickEvents() {
        //console.log('Setting up click events...');
        const mapGrid = document.querySelector('.map-grid');
        if (!mapGrid) {
            console.error('Map grid element not found!');
            return;
        }

        // 为每个节点添加点击件
        const nodes = mapGrid.querySelectorAll('.map-node');
        nodes.forEach(node => {
            node.addEventListener('click', (e) => {
                // 如果正在拖动，不处理点击
                if (this.isDragging) {
                    //console.log('Ignoring click due to drag');
                    return;
                }

                e.preventDefault();
                e.stopPropagation();

                const nodeId = node.dataset.nodeId;
                //console.log('Node clicked:', nodeId);

                const moveCheck = this.canMoveTo(nodeId);
                if (moveCheck.canMove) {
                    //console.log('Moving to node:', nodeId);
                    this.moveToNode(nodeId);
                } else {
                    //console.log('Cannot move to node:', nodeId, moveCheck.reason);
                    gameManager.showFloatingTip(moveCheck.reason, 'error');
                }
            });

            // 添加鼠标进入效果
            node.addEventListener('mouseenter', () => {
                if (node.classList.contains('connected')) {
                    node.style.cursor = 'pointer';
                }
            });

            // 添加鼠标离开效果
            node.addEventListener('mouseleave', () => {
                node.style.cursor = '';
            });
        });

        //console.log('Click events setup completed');
    }

    setupAllEvents() {
        //console.log('Setting up all events...');
        
        this.centerMap();
        this.setupClickEvents();
        this.setupDragEvents();
        this.setupKeyboardEvents();
        this.setupMapSwitchEvents();
        this.setupEntityClickEvents();
        this.setupLocationCloseEvent();
        this.setupAutoCombatEvents();
        
        //console.log('All events setup completed');
    }

    // 修改 centerOnCurrentNode 方法
    centerOnCurrentNode() {
        const container = document.querySelector('.map-container');
        const mapGrid = document.querySelector('.map-grid');
        const currentNodeElement = document.querySelector(`[data-node-id="${this.currentNode}"]`);
        
        if (!container || !mapGrid || !currentNodeElement) return;

        // 获取容器和节点的尺寸信息
        const containerRect = container.getBoundingClientRect();
        const nodeRect = currentNodeElement.getBoundingClientRect();
        const mapRect = mapGrid.getBoundingClientRect();

        // 计算节点相对于地图的位置
        const nodeOffsetX = nodeRect.left - mapRect.left;
        const nodeOffsetY = nodeRect.top - mapRect.top;

        // 计算需要的偏移量，使节点位于容器中心
        // 添加额外的垂直偏移以使节点位置更靠下
        const targetX = containerRect.width / 2 - (nodeOffsetX + nodeRect.width / 2);
        const targetY = containerRect.height * 0.7 - (nodeOffsetY + nodeRect.height / 2);

        // 应用偏移
        mapGrid.style.transition = 'transform 0.5s ease';
        this.currentTranslate = { x: targetX, y: targetY };
        this.previousTranslate = { ...this.currentTranslate };
        this.applyTransform();

        // 记录当前节点的位置，用于后续检查
        this.currentNodePosition = {
            x: nodeOffsetX + nodeRect.width / 2,
            y: nodeOffsetY + nodeRect.height / 2
        };
    }

    setupKeyboardEvents() {
        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                e.preventDefault(); // 阻止空格键的默认行为
                this.isSpacePressed = true;
                document.body.style.cursor = 'grab'; // 改变鼠标样式为抓取
            }
        });

        document.addEventListener('keyup', (e) => {
            if (e.code === 'Space') {
                this.isSpacePressed = false;
                document.body.style.cursor = ''; // 恢复默认鼠标样式
                
                // 如果正在拖动，停止拖动
                if (this.isDragging) {
                    this.stopDragging();
                }
            }
        });
    }

    // 添加地图切换事件处理方法
    setupMapSwitchEvents() {
        const mapSwitch = document.querySelector('.map-switch');
        if (!mapSwitch) return;

        const btn = mapSwitch.querySelector('.map-switch-btn');
        const list = mapSwitch.querySelector('.map-list');

        // 切换按钮点击事件
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            list.classList.toggle('show');
        });

        // 地图选项点击事件
        list.querySelectorAll('.map-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                const mapId = item.dataset.map;
                if (mapId && mapId !== this.currentMap) {
                    this.switchMap(mapId);
                }
                list.classList.remove('show');
            });
        });

        // 点击其他地方关闭列表
        document.addEventListener('click', () => {
            list.classList.remove('show');
        });
    }

    // 添加切换地图方法
    switchMap(mapId) {
        if (!this.maps[mapId]) return;
        
        this.currentMap = mapId;
        this.currentNode = this.maps[mapId].startNode;
        
        // 重置位置
        this.currentTranslate = { x: 0, y: 0 };
        this.previousTranslate = { x: 0, y: 0 };
        
        // 重新渲染地图
        this.renderMap();
        
        // 确保新地图的起始位置居中
        setTimeout(() => {
            this.centerOnCurrentNode();
            gameManager.showFloatingTip(`已传送至${this.maps[mapId].name}`, 'success');
        }, 100);
    }

    // 修改 setupEntityClickEvents 方法
    setupEntityClickEvents() {
        //console.log('Setting up entity click events...');
        const entityItems = document.querySelectorAll('.entity-item');
        
        entityItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                //console.log('Entity clicked');
                const entityType = item.dataset.entityType;
                const entityId = item.dataset.entityId;
                
                //console.log('Entity type:', entityType);
                //console.log('Entity ID:', entityId);
                
                const entityData = this.getEntityData(entityType, entityId);
                //console.log('Entity data:', entityData);
                
                if (entityData) {
                    this.showEntityDialog(entityData, entityType);
                }
            });
        });
        
        //console.log('Entity click events setup completed');
    }

    // 修改 getEntityData 方法
    getEntityData(type, id) {
        const currentMap = this.getCurrentMapData();
        const currentNode = currentMap.nodes[this.currentNode];

        //console.log('Getting entity data:', { type, id });
        //console.log('Current node:', currentNode);

        switch(type) {
            case 'npc':
                const npc = currentMap.npcs[id];
                //console.log('Found NPC:', npc);
                return npc;
            case 'monster':
                // 如果是数字索引，直接返回对应索引的怪物
                if (!isNaN(id)) {
                    const monster = currentNode.monsters[parseInt(id)];
                    //console.log('Found monster by index:', monster);
                    return monster;
                }
                // 否则通过id查
                const monster = currentNode.monsters.find(m => m.id === id);
                //console.log('Found monster by id:', monster);
                return monster;
            default:
                //console.log('Unknown entity type');
                return null;
        }
    }

    // 修改 showEntityDialog 方法
    showEntityDialog(entity, type) {
        const dialog = document.createElement('div');
        dialog.className = 'entity-dialog';
        
        const actions = this.getEntityActions(entity, type);
        
        dialog.innerHTML = `
            <div class="entity-dialog-content">
                <button class="close-dialog-btn" title="关闭">×</button>
                <div class="dialog-header">
                    <div class="dialog-title">
                        <span class="entity-icon">${entity.icon}</span>
                        <span class="entity-name">${entity.name}</span>
                        ${type === 'monster' ? `<span class="entity-level">Lv.${entity.level}</span>` : ''}
                    </div>
                </div>
                <div class="dialog-body">
                    <div class="entity-description">${entity.description}</div>
                    ${type === 'monster' ? `
                        <div class="monster-stats">   
                            <!-- 可以添加更多怪物属性 -->
                        </div>
                    ` : ''}
                </div>
                <div class="dialog-actions">
                    ${actions.map(action => `
                        <button class="action-btn ${action.type}" data-action="${action.type}">
                            <span class="action-icon">${action.icon}</span>
                            ${action.text}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;

        // 添加关闭按钮事件
        const closeBtn = dialog.querySelector('.close-dialog-btn');
        if (closeBtn) {
            closeBtn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                dialog.classList.add('fade-out');
                setTimeout(() => {
                    if (dialog.parentNode) {
                        dialog.parentNode.removeChild(dialog);
                    }
                }, 300);
            };
        }

        // 添加操作按钮事件
        actions.forEach(action => {
            const btn = dialog.querySelector(`[data-action="${action.type}"]`);
            if (btn) {
                btn.onclick = () => action.handler(entity);
            }
        });

        document.body.appendChild(dialog);
        // 添加淡入效果
        setTimeout(() => dialog.classList.add('show'), 10);
    }

    // 修改 getEntityActions 方法
    getEntityActions(entity, type) {
        const actions = [];

        if (type === 'monster') {
            actions.push({
                type: 'attack',
                text: '攻击',
                icon: '⚔️',
                handler: (monsterData) => {
                    //console.log('Starting combat with monster:', monsterData);
                    
                    // 关闭详情对话框
                    const dialog = document.querySelector('.entity-dialog');
                    if (dialog) {
                        dialog.parentNode.removeChild(dialog);
                    }

                    // 生成完整的怪物实例
                    const monster = entityGenerator.generateMonster({
                        type: monsterData.type, // 确保包含类型
                        name: monsterData.name,
                        icon: monsterData.icon,
                        level: monsterData.level,
                        description: monsterData.description,
                        mapId: this.currentMap,
                        nodeId: this.currentNode
                    });
                    
                    //console.log('Generated monster instance:', monster);

                    // 初始化战斗
                    if (monster) {
                        combatSystem.initiateCombat([monster]);
                    }
                }
            });
        } else if (type === 'npc') {
            // NPC的操作
            if (entity.dialog) {
                actions.push({
                    type: 'talk',
                    text: '对话',
                    icon: '💬',
                    handler: (npc) => this.startDialog(npc)
                });
            }
            
            if (entity.isShopkeeper) {
                actions.push({
                    type: 'shop',
                    text: '商店',
                    icon: '🏪',
                    handler: (npc) => this.openShop(npc)
                });
            }

            if (entity.quests) {
                actions.push({
                    type: 'quest',
                    text: '任务',
                    icon: '📜',
                    handler: (npc) => this.showQuests(npc)
                });
            }
        }

        return actions;
    }

    // 话系统
    startDialog(npc) {
        if (!npc.dialog || npc.dialog.length === 0) return;
        
        const dialogBox = document.createElement('div');
        dialogBox.className = 'dialog-box';
        
        let currentDialog = 0;
        
        const updateDialog = () => {
            dialogBox.innerHTML = `
                <div class="dialog-content">
                    <div class="dialog-speaker">
                        <span class="speaker-icon">${npc.icon}</span>
                        <span class="speaker-name">${npc.name}</span>
                    </div>
                    <div class="dialog-text">${npc.dialog[currentDialog]}</div>
                    <div class="dialog-controls">
                        ${currentDialog > 0 ? '<button class="prev-btn">◀ 上一句</button>' : ''}
                        ${currentDialog < npc.dialog.length - 1 ? 
                            '<button class="next-btn">下一句 ▶</button>' : 
                            '<button class="close-btn">结束对话</button>'}
                    </div>
                </div>
            `;

            // 添加按钮事件
            const prevBtn = dialogBox.querySelector('.prev-btn');
            const nextBtn = dialogBox.querySelector('.next-btn');
            const closeBtn = dialogBox.querySelector('.close-btn');

            if (prevBtn) prevBtn.onclick = () => {
                currentDialog--;
                updateDialog();
            };

            if (nextBtn) nextBtn.onclick = () => {
                currentDialog++;
                updateDialog();
            };

            if (closeBtn) closeBtn.onclick = () => {
                document.body.removeChild(dialogBox);
            };
        };

        updateDialog();
        document.body.appendChild(dialogBox);
    }

    // 添加新方
    setupLocationCloseEvent() {
        const closeBtn = document.querySelector('.close-location-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                const locationInfo = document.querySelector('.location-info');
                if (locationInfo) {
                    locationInfo.style.display = 'none';
                }
            });
        }
    }

    // 修改 MapSystem 类中的触发战斗方法
    triggerBattle(nodeMonsters) {
        if (!nodeMonsters || nodeMonsters.length === 0) return;

        // 选择一个怪物作为主要敌人
        const mainMonster = nodeMonsters[Math.floor(Math.random() * nodeMonsters.length)];
        
        // 使用 entityGenerator 生成完整的怪物数据
        const monsterData = {
            type: mainMonster.type, // 使用怪物类型
            name: mainMonster.name,
            icon: mainMonster.icon,
            level: mainMonster.level || 1,
            description: mainMonster.description,
            mapId: this.currentMap,
            nodeId: this.currentNode
        };

        console.log('生成怪物数据:', monsterData);

        // 生成完的怪物实例
        const monster = entityGenerator.generateMonster(monsterData);
        if (!monster) {
            console.error('生成怪物失败:', monsterData);
            return;
        }

        console.log('生成的怪物实例:', monster);

        // 初始化战斗
        if (monster) {
            combatSystem.initiateCombat([monster]);
        }
    }

    // 修改节点点击事件处理
    handleNodeClick(nodeId) {
        const node = this.maps[this.currentMap].nodes[nodeId];
        if (!node) return;

        // 如果节点有怪物，触发战斗
        if (node.monsters && node.monsters.length > 0) {
            // 确保每个怪物都有正确的类型
            const validMonsters = node.monsters.map(monster => {
                if (!monster.type) {
                    console.warn('怪物缺少类型:', monster);
                }
                return {
                    ...monster,
                    type: monster.type // 确保使用正确的类型
                };
            });

            console.log('处理的怪物数据:', validMonsters);
            this.triggerBattle(validMonsters);
        }
    }

    // 添加自动战斗相关方法
    setupAutoCombatEvents() {
        const autoCombatCheckbox = document.querySelector('.auto-combat-checkbox');
        const monsterSelect = document.querySelector('.monster-select');
        
        if (autoCombatCheckbox && monsterSelect) {
            autoCombatCheckbox.addEventListener('change', (e) => {
                if (e.target.checked) {
                    // 开启自动战斗时锁定选择框
                    monsterSelect.disabled = true;
                    this.startAutoCombat(monsterSelect.value);
                } else {
                    // 关闭自动战斗时解锁选择框
                    monsterSelect.disabled = false;
                    this.stopAutoCombat();
                }
            });

            monsterSelect.addEventListener('change', () => {
                if (autoCombatCheckbox.checked) {
                    this.startAutoCombat(monsterSelect.value);
                }
            });
        }
    }

    // 修改 startAutoCombat 方法
    startAutoCombat(monsterIndex) {
        const currentLocation = this.getCurrentMapData().nodes[this.currentNode];
        const selectedMonster = currentLocation.monsters[monsterIndex];
        
        if (!selectedMonster) return;
        
        this.autoCombatTarget = selectedMonster;

        // 显示准备开始的提示
        gameManager.showFloatingTip('2秒后开始自动战斗...', 'info');
        
        // 2秒后开始第一场战斗
        setTimeout(() => {
            if (this.autoCombatTarget) { // 确保在延迟期间没有关闭自动战斗
                this.startNextAutoCombat();
            }
        }, 2000);
    }

    // 修改 startNextAutoCombat 方法
    startNextAutoCombat() {
        if (!this.autoCombatTarget) return;

        // 检查玩家状态
        if (gameManager.currentPlayer.stats.hp <= 0) {
            gameManager.showFloatingTip('生命值不足，自动战斗已停止！', 'error');
            this.stopAutoCombat();
            // 关闭自动战斗开关
            const autoCombatCheckbox = document.querySelector('.auto-combat-checkbox');
            if (autoCombatCheckbox) {
                autoCombatCheckbox.checked = false;
            }
            return;
        }

        // 生成怪物实例
        const monster = entityGenerator.generateMonster({
            type: this.autoCombatTarget.type,
            name: this.autoCombatTarget.name,
            icon: this.autoCombatTarget.icon,
            level: this.autoCombatTarget.level,
            description: this.autoCombatTarget.description,
            mapId: this.currentMap,
            nodeId: this.currentNode
        });

        if (monster) {
            combatSystem.initiateCombat([monster]);
        }
    }

    // 修改 stopAutoCombat 方法
    stopAutoCombat() {
        if (this.autoCombatTarget) {
            gameManager.showFloatingTip('自动战斗已停止', 'info');
            this.autoCombatTarget = null;
            
            // 确保解锁选择框
            const monsterSelect = document.querySelector('.monster-select');
            if (monsterSelect) {
                monsterSelect.disabled = false;
            }
        }
    }
}

window.addEventListener('DOMContentLoaded', () => {
    if (!window.mapSystem) {
        window.mapSystem = new MapSystem();
    }
});