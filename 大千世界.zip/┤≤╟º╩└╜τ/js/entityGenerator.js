class EntityGenerator {
    constructor() {
        // 基础属性配置
        this.BASE_STATS = {
            hp: 100,
            mp: 50,
            attack: 10,
            defense: 5,
            speed: 10,
            crit: 5,
            critDmg: 150,
            magic: 10
        };

        // 怪物类型配置
        this.MONSTER_TYPES = {
            // 武庙怪物 - 新手区域
            WOODEN_DUMMY: {
                name: '木人桩',
                icon: '🪱',
                description: '用于练功的木人桩，偶尔会产生反应',
                baseExp: 35,
                baseGold: 7,
                baseStats: {
                    hp: 70,
                    mp: 70,
                    attack: 10,
                    defense: 14,
                    speed: 7,
                    crit: 7,
                    critDmg: 105,
                    hit: 60,
                    dodge: 7,
                    magic: 0,
                    drain: 0
                },
                growth: {
                    hp: 28,
                    mp: 10,
                    attack: 3.8,
                    defense: 2.8,
                    speed: 1.0,
                    crit: 0.4,
                    critDmg: 3.5,
                    hit: 2.1,
                    dodge: 0.4,
                    magic: 0,
                    drain: 0
                },
                skills: ['basic_attack', 'counter_attack'],
                drops: [
                    { id: 'wood_piece', chance: 0.8, name: '木块', type: 'material', value: 10 },
                    { id: 'training_manual', chance: 0.3, name: '练功秘籍', type: 'book', value: 50 },
                    { id: 'copper_coin', chance: 1, name: '铜钱', type: 'currency', count: [10, 30] }
                ]
            },
            IRON_DUMMY: {
                name: '铁人桩',
                icon: '⚔️',
                description: '坚固的铁制木人桩，具有更强的反击能力',
                baseExp: 56,
                baseGold: 10,
                baseStats: {
                    hp: 266,
                    mp: 105,
                    attack: 31,
                    defense: 28,
                    speed: 14,
                    crit: 8,
                    critDmg: 119,
                    hit: 63,
                    dodge: 8,
                    magic: 0,
                    drain: 0
                },
                growth: {
                    hp: 35,
                    mp: 14,
                    attack: 4.5,
                    defense: 4.2,
                    speed: 1.4,
                    crit: 0.6,
                    critDmg: 5.6,
                    hit: 2.8,
                    dodge: 0.6,
                    magic: 0,
                    drain: 0
                },
                skills: ['basic_attack', 'counter_attack', 'iron_defense'],
                drops: [
                    { id: 'iron_piece', chance: 0.7, name: '铁块', type: 'material', value: 30 },
                    { id: 'advanced_manual', chance: 0.2, name: '高级练功秘籍', type: 'book', value: 100 },
                    { id: 'iron_sword', chance: 0.1, name: '铁剑', type: 'weapon', value: 200 },
                    { id: 'copper_coin', chance: 1, name: '铜钱', type: 'currency', count: [30, 50] }
                ]
            },

            // 武街怪物 - 正式战斗区域
            STREET_THUG: {
                name: '街头混混',
                icon: '👤',
                description: '在武街闲逛的混混，喜欢挑衅路人',
                baseExp: 100,
                baseGold: 20,
                baseStats: {
                    hp: 420,           // 提高基础生命值
                    mp: 180,
                    attack: 55,        // 提高攻击力
                    defense: 35,
                    speed: 30,
                    crit: 20,
                    critDmg: 180,
                    hit: 95,
                    dodge: 25,
                    magic: 0,
                    drain: 8
                },
                growth: {
                    hp: 55,            // 提高生命值成长
                    mp: 25,
                    attack: 7.5,       // 提高攻击力成长
                    defense: 4.5,
                    speed: 3.0,
                    crit: 1.2,
                    critDmg: 10,
                    hit: 4.0,
                    dodge: 1.5,
                    magic: 0,
                    drain: 0.5
                },
                skills: ['basic_attack', 'intimidate', 'quick_strike'],
                drops: [
                    { id: 'thug_knife', chance: 0.4, name: '匕首', type: 'weapon', value: 150 },
                    { id: 'leather_armor', chance: 0.3, name: '皮甲', type: 'armor', value: 120 },
                    { id: 'healing_potion', chance: 0.5, name: '治疗药水', type: 'consumable', value: 50 },
                    { id: 'copper_coin', chance: 1, name: '铜钱', type: 'currency', count: [50, 100] }
                ]
            },

            // 武馆学徒
            MARTIAL_STUDENT: {
                name: '武馆学徒',
                icon: '🥋',
                description: '正在习武的学徒，掌握了基本的武学招式',
                baseExp: 120,
                baseGold: 25,
                baseStats: {
                    hp: 460,
                    mp: 200,
                    attack: 60,
                    defense: 45,
                    speed: 35,
                    crit: 25,
                    critDmg: 190,
                    hit: 100,
                    dodge: 30,
                    magic: 15,
                    drain: 10
                },
                growth: {
                    hp: 60,
                    mp: 30,
                    attack: 8.0,
                    defense: 5.5,
                    speed: 3.5,
                    crit: 1.5,
                    critDmg: 12,
                    hit: 4.5,
                    dodge: 2.0,
                    magic: 1.0,
                    drain: 0.6
                },
                skills: ['basic_attack', 'martial_arts', 'training_stance'],
                drops: [
                    { id: 'training_gear', chance: 0.6, name: '练功服', type: 'armor', value: 180 },
                    { id: 'basic_manual', chance: 0.4, name: '基础武学秘籍', type: 'book', value: 150 },
                    { id: 'energy_pill', chance: 0.3, name: '气力丹', type: 'consumable', value: 80 },
                    { id: 'copper_coin', chance: 1, name: '铜钱', type: 'currency', count: [80, 150] }
                ]
            },

            // 商队护卫
            MERCHANT_GUARD: {
                name: '商队护卫',
                icon: '💂',
                description: '保护商队的护卫，身手不错',
                baseExp: 150,
                baseGold: 30,
                baseStats: {
                    hp: 500,
                    mp: 220,
                    attack: 65,
                    defense: 50,
                    speed: 40,
                    crit: 30,
                    critDmg: 200,
                    hit: 105,
                    dodge: 35,
                    magic: 20,
                    drain: 12
                },
                growth: {
                    hp: 65,
                    mp: 35,
                    attack: 8.5,
                    defense: 6.0,
                    speed: 4.0,
                    crit: 1.8,
                    critDmg: 15,
                    hit: 5.0,
                    dodge: 2.5,
                    magic: 1.5,
                    drain: 0.8
                },
                skills: ['basic_attack', 'guard_stance', 'shield_bash'],
                drops: [
                    { id: 'guard_armor', chance: 0.5, name: '护卫铠甲', type: 'armor', value: 250 },
                    { id: 'steel_sword', chance: 0.3, name: '精钢剑', type: 'weapon', value: 300 },
                    { id: 'shield', chance: 0.4, name: '盾牌', type: 'shield', value: 200 },
                    { id: 'silver_coin', chance: 1, name: '银币', type: 'currency', count: [5, 15] }
                ]
            },

            // 见习巫师
            APPRENTICE_MAGE: {
                name: '见习巫师',
                icon: '🧙',
                description: '正在学习法术的巫师学徒',
                baseExp: 180,
                baseGold: 35,
                baseStats: {
                    hp: 90,
                    mp: 120,
                    attack: 8,
                    defense: 6,
                    speed: 9,
                    crit: 4,
                    critDmg: 130,
                    hit: 100,
                    dodge: 5,
                    magic: 15,
                    drain: 6
                },
                growth: {
                    hp: 18,
                    mp: 25,
                    attack: 2,
                    defense: 1.5,
                    speed: 0.9,
                    crit: 0.3,
                    critDmg: 2,
                    hit: 3,
                    dodge: 0.4,
                    magic: 4,
                    drain: 0.6
                },
                skills: ['basic_attack', 'magic_missile', 'mana_shield'],
                drops: [
                    { id: 'magic_scroll', chance: 0.7, name: '法术卷轴', type: 'consumable', value: 120 },
                    { id: 'mage_staff', chance: 0.3, name: '法杖', type: 'weapon', value: 280 },
                    { id: 'mana_crystal', chance: 0.4, name: '魔力水晶', type: 'material', value: 150 },
                    { id: 'mage_robe', chance: 0.3, name: '法师长袍', type: 'armor', value: 200 },
                    { id: 'silver_coin', chance: 1, name: '银币', type: 'currency', count: [8, 20] }
                ]
            },

            // 山贼
            MOUNTAIN_BANDIT: {
                name: '山贼',
                icon: '👤',
                description: '在山间劫掠的强盗',
                baseExp: 250,
                baseGold: 45,
                baseStats: {
                    hp: 850,
                    mp: 300,
                    attack: 115,
                    defense: 75,
                    speed: 65,
                    crit: 45,
                    critDmg: 250,
                    hit: 120,
                    dodge: 50,
                    magic: 35,
                    drain: 25
                },
                growth: {
                    hp: 85,
                    mp: 45,
                    attack: 11.5,
                    defense: 8.0,
                    speed: 6.5,
                    crit: 3.0,
                    critDmg: 22,
                    hit: 6.5,
                    dodge: 4.0,
                    magic: 3.0,
                    drain: 1.5
                },
                skills: ['basic_attack', 'quick_strike', 'intimidate'],
                drops: [
                    { id: 'bandit_sword', chance: 0.5, name: '山贼刀', type: 'weapon', value: 220 },
                    { id: 'stolen_goods', chance: 0.6, name: '赃物', type: 'material', value: 180 },
                    { id: 'treasure_map', chance: 0.1, name: '藏宝图', type: 'quest', value: 500 },
                    { id: 'bandit_armor', chance: 0.4, name: '山贼皮甲', type: 'armor', value: 240 },
                    { id: 'gold_coin', chance: 1, name: '金币', type: 'currency', count: [1, 5] }
                ]
            },

            ROCK_SPIDER: {
                name: '岩蛛',
                icon: '🕷️',
                description: '在峭壁上筑巢的巨型蜘蛛',
                baseExp: 230,
                baseGold: 40,
                baseStats: {
                    hp: 950,
                    mp: 300,
                    attack: 135,
                    defense: 95,
                    speed: 85,
                    crit: 55,
                    critDmg: 260,
                    hit: 130,
                    dodge: 50,
                    magic: 0,
                    drain: 35
                },
                growth: {
                    hp: 95,
                    mp: 30,
                    attack: 13.5,
                    defense: 10.0,
                    speed: 8.5,
                    crit: 4.0,
                    critDmg: 23,
                    hit: 6.5,
                    dodge: 4.0,
                    magic: 0,
                    drain: 3.0
                },
                skills: ['basic_attack', 'quick_strike', 'intimidate'],
                drops: [
                    { id: 'bandit_sword', chance: 0.5, name: '山贼刀', type: 'weapon', value: 220 },
                    { id: 'stolen_goods', chance: 0.6, name: '赃物', type: 'material', value: 180 },
                    { id: 'treasure_map', chance: 0.1, name: '藏宝图', type: 'quest', value: 500 },
                    { id: 'bandit_armor', chance: 0.4, name: '山贼皮甲', type: 'armor', value: 240 },
                    { id: 'gold_coin', chance: 1, name: '金币', type: 'currency', count: [1, 5] }
                ]
            },

            // 幽暗森林怪物
            WOLF: {
                name: '野狼',
                icon: '🐺',
                description: '常见的野生猛兽，成群结队地活动',
                baseExp: 220,
                baseGold: 35,
                baseStats: {
                    hp: 900,
                    mp: 200,
                    attack: 145,
                    defense: 75,
                    speed: 95,
                    crit: 45,
                    critDmg: 230,
                    hit: 110,
                    dodge: 55,
                    magic: 0,
                    drain: 25
                },
                growth: {
                    hp: 90,
                    mp: 20,
                    attack: 14.5,
                    defense: 7.5,
                    speed: 9.5,
                    crit: 3.5,
                    critDmg: 18,
                    hit: 5.5,
                    dodge: 4.5,
                    magic: 0,
                    drain: 2.0
                },
                skills: ['basic_attack', 'quick_strike', 'pack_tactics', 'savage_bite'],
                drops: [
                    { id: 'wolf_fang', chance: 0.7, name: '狼牙', type: 'material', value: 200 },
                    { id: 'wolf_pelt', chance: 0.6, name: '狼皮', type: 'material', value: 180 },
                    { id: 'silver_coin', chance: 1, name: '银币', type: 'currency', count: [5, 15] }
                ]
            },

            FOREST_SNAKE: {
                name: '森林巨蟒',
                icon: '🐍',
                description: '盘踞在树上的大蛇，动作敏捷',
                baseExp: 240,
                baseGold: 40,
                baseStats: {
                    hp: 820,
                    mp: 250,
                    attack: 155,
                    defense: 70,
                    speed: 100,
                    crit: 50,
                    critDmg: 250,
                    hit: 115,
                    dodge: 60,
                    magic: 50,
                    drain: 30
                },
                growth: {
                    hp: 85,
                    mp: 25,
                    attack: 15.5,
                    defense: 7.0,
                    speed: 10.0,
                    crit: 4.0,
                    critDmg: 20,
                    hit: 6.0,
                    dodge: 5.0,
                    magic: 4.0,
                    drain: 2.5
                },
                skills: ['basic_attack', 'poison_bite', 'constrict', 'venom_spit'],
                drops: [
                    { id: 'snake_skin', chance: 0.7, name: '蛇皮', type: 'material', value: 220 },
                    { id: 'venom_gland', chance: 0.5, name: '毒腺', type: 'material', value: 250 },
                    { id: 'silver_coin', chance: 1, name: '银币', type: 'currency', count: [8, 18] }
                ]
            },

            CLOUD_SPRITE: {
                name: '迷雾精灵',
                icon: '🧚',
                description: '由迷雾凝聚而成的神秘生物',
                baseExp: 260,
                baseGold: 45,
                baseStats: {
                    hp: 750,
                    mp: 500,
                    attack: 105,
                    defense: 80,
                    speed: 105,
                    crit: 45,
                    critDmg: 200,
                    hit: 125,
                    dodge: 65,
                    magic: 160,
                    drain: 35
                },
                growth: {
                    hp: 80,
                    mp: 55,
                    attack: 10.5,
                    defense: 8.0,
                    speed: 10.5,
                    crit: 3.5,
                    critDmg: 15,
                    hit: 6.5,
                    dodge: 5.5,
                    magic: 16.0,
                    drain: 3.0
                },
                skills: ['basic_attack', 'mist_veil', 'cloud_burst', 'spirit_drain'],
                drops: [
                    { id: 'cloud_essence', chance: 0.6, name: '云雾精华', type: 'material', value: 280 },
                    { id: 'spirit_crystal', chance: 0.4, name: '精灵水晶', type: 'material', value: 300 },
                    { id: 'silver_coin', chance: 1, name: '银币', type: 'currency', count: [10, 20] }
                ]
            },

            // 云顶山脉怪物
            MOUNTAIN_EAGLE: {
                name: '山鹰',
                icon: '🦅',
                description: '在悬崖间盘旋的猛禽',
                baseExp: 200,
                baseGold: 45,
                baseStats: {
                    hp: 580,
                    mp: 200,
                    attack: 78,
                    defense: 52,
                    speed: 70,
                    crit: 40,
                    critDmg: 220,
                    hit: 115,
                    dodge: 50,
                    magic: 0,
                    drain: 15
                },
                growth: {
                    hp: 65,
                    mp: 25,
                    attack: 8.5,
                    defense: 5.5,
                    speed: 7.0,
                    crit: 2.5,
                    critDmg: 15,
                    hit: 5.5,
                    dodge: 4.0,
                    magic: 0,
                    drain: 1.0
                },
                skills: ['basic_attack', 'dive_attack', 'wind_slash'],
                drops: [
                    { id: 'eagle_feather', chance: 0.6, name: '鹰羽', type: 'material', value: 320 },
                    { id: 'sharp_talon', chance: 0.4, name: '利爪', type: 'material', value: 280 },
                    { id: 'gold_coin', chance: 1, name: '金币', type: 'currency', count: [2, 6] }
                ]
            },

            CAVE_BAT: {
                name: '洞穴蝙蝠',
                icon: '🦇',
                description: '成群结队的蝙蝠',
                baseExp: 160,
                baseGold: 45,
                baseStats: {
                    hp: 420,
                    mp: 160,
                    attack: 65,
                    defense: 45,
                    speed: 65,
                    crit: 35,
                    critDmg: 180,
                    hit: 105,
                    dodge: 45,
                    magic: 0,
                    drain: 25
                },
                growth: {
                    hp: 52,
                    mp: 20,
                    attack: 7.2,
                    defense: 4.8,
                    speed: 6.5,
                    crit: 2.2,
                    critDmg: 12,
                    hit: 5.0,
                    dodge: 3.5,
                    magic: 0,
                    drain: 1.5
                },
                skills: ['basic_attack', 'sonic_wave', 'blood_drain'],
                drops: [
                    { id: 'bat_wing', chance: 0.7, name: '蝠翼', type: 'material', value: 220 },
                    { id: 'dark_essence', chance: 0.3, name: '暗影精华', type: 'material', value: 300 },
                    { id: 'silver_coin', chance: 1, name: '银币', type: 'currency', count: [15, 30] }
                ]
            },

            ROCK_GOLEM: {
                name: '岩石怪',
                icon: '🪨',
                description: '由岩石构成的奇怪生物',
                baseExp: 190,
                baseGold: 45,
                baseStats: {
                    hp: 680,
                    mp: 150,
                    attack: 70,
                    defense: 75,
                    speed: 35,
                    crit: 20,
                    critDmg: 160,
                    hit: 90,
                    dodge: 25,
                    magic: 0,
                    drain: 0
                },
                growth: {
                    hp: 75,
                    mp: 18,
                    attack: 7.5,
                    defense: 8.0,
                    speed: 3.5,
                    crit: 1.2,
                    critDmg: 8,
                    hit: 4.0,
                    dodge: 1.5,
                    magic: 0,
                    drain: 0
                },
                skills: ['basic_attack', 'rock_throw', 'stone_skin'],
                drops: [
                    { id: 'rock_core', chance: 0.5, name: '岩石核心', type: 'material', value: 350 },
                    { id: 'mineral_shard', chance: 0.6, name: '矿物碎片', type: 'material', value: 280 },
                    { id: 'gold_coin', chance: 1, name: '金币', type: 'currency', count: [3, 8] }
                ]
            },

            CLOUD_SPRITE: {
                name: '云雾精灵',
                icon: '🧚',
                description: '云雾中生存的神秘生物',
                baseExp: 220,
                baseGold: 45,
                baseStats: {
                    hp: 520,
                    mp: 350,
                    attack: 60,
                    defense: 55,
                    speed: 65,
                    crit: 30,
                    critDmg: 180,
                    hit: 120,
                    dodge: 55,
                    magic: 85,
                    drain: 20
                },
                growth: {
                    hp: 58,
                    mp: 40,
                    attack: 6.5,
                    defense: 5.8,
                    speed: 6.5,
                    crit: 1.8,
                    critDmg: 10,
                    hit: 6.0,
                    dodge: 4.5,
                    magic: 9.0,
                    drain: 1.5
                },
                skills: ['basic_attack', 'mist_veil', 'cloud_burst'],
                drops: [
                    { id: 'cloud_essence', chance: 0.5, name: '云雾精华', type: 'material', value: 400 },
                    { id: 'spirit_dust', chance: 0.4, name: '灵尘', type: 'material', value: 350 },
                    { id: 'gold_coin', chance: 1, name: '金币', type: 'currency', count: [4, 10] }
                ]
            },

            STONE_STATUE: {
                name: '石像怪',
                icon: '🗿',
                description: '栩栩如生的石像突然活了过来',
                baseExp: 200,
                baseGold: 45,
                baseStats: {
                    hp: 650,
                    mp: 180,
                    attack: 72,
                    defense: 80,       // 超高防御
                    speed: 30,         // 较低速度
                    crit: 15,
                    critDmg: 150,
                    hit: 95,
                    dodge: 20,
                    magic: 40,
                    drain: 0
                },
                growth: {
                    hp: 70,
                    mp: 22,
                    attack: 7.8,
                    defense: 8.5,      // 高防御成长
                    speed: 2.5,
                    crit: 1.0,
                    critDmg: 8,
                    hit: 4.2,
                    dodge: 1.2,
                    magic: 3.5,
                    drain: 0
                },
                skills: ['basic_attack', 'stone_smash', 'petrify'],
                drops: [
                    { id: 'ancient_stone', chance: 0.6, name: '远古石块', type: 'material', value: 300 },
                    { id: 'statue_core', chance: 0.4, name: '石像核心', type: 'material', value: 400 },
                    { id: 'gold_coin', chance: 1, name: '金币', type: 'currency', count: [3, 7] }
                ]
            },

            // 沙漠怪物
            DESERT_LIZARD: {
                name: '沙蜥',
                icon: '🦎',
                description: '适应沙漠环境的大型蜥蜴',
                baseExp: 200,
                baseGold: 30,
                baseStats: {
                    hp: 580,
                    mp: 150,
                    attack: 75,
                    defense: 65,
                    speed: 70,
                    crit: 25,
                    critDmg: 180,
                    hit: 95,
                    dodge: 40,
                    magic: 0,
                    drain: 10
                },
                growth: {
                    hp: 65,
                    mp: 15,
                    attack: 8.0,
                    defense: 6.5,
                    speed: 7.0,
                    crit: 1.5,
                    critDmg: 10,
                    hit: 4.0,
                    dodge: 3.0,
                    magic: 0,
                    drain: 0.5
                },
                skills: ['basic_attack', 'quick_strike', 'sand_armor'],
                drops: [
                    { id: 'lizard_scale', chance: 0.7, name: '蜥蜴鳞片', type: 'material', value: 280 },
                    { id: 'desert_essence', chance: 0.3, name: '沙漠精华', type: 'material', value: 350 }
                ]
            },

            SAND_WORM: {
                name: '沙虫',
                icon: '🪱',
                description: '潜伏在沙下的巨型虫类',
                baseExp: 220,
                baseGold: 35,
                baseStats: {
                    hp: 650,
                    mp: 180,
                    attack: 85,
                    defense: 60,
                    speed: 45,
                    crit: 20,
                    critDmg: 170,
                    hit: 90,
                    dodge: 30,
                    magic: 0,
                    drain: 15
                },
                growth: {
                    hp: 70,
                    mp: 20,
                    attack: 9.0,
                    defense: 6.0,
                    speed: 4.5,
                    crit: 1.2,
                    critDmg: 8,
                    hit: 3.5,
                    dodge: 2.0,
                    magic: 0,
                    drain: 1.0
                },
                skills: ['basic_attack', 'burrow', 'sand_blast'],
                drops: [
                    { id: 'worm_segment', chance: 0.6, name: '虫体节段', type: 'material', value: 300 },
                    { id: 'sand_crystal', chance: 0.4, name: '沙晶', type: 'material', value: 380 }
                ]
            },

            DESERT_BANDIT: {
                name: '沙匪',
                icon: '👥',
                description: '在沙漠中劫掠商队的强盗',
                baseExp: 230,
                baseGold: 40,
                baseStats: {
                    hp: 600,
                    mp: 200,
                    attack: 90,
                    defense: 55,
                    speed: 75,
                    crit: 35,
                    critDmg: 200,
                    hit: 100,
                    dodge: 45,
                    magic: 0,
                    drain: 10
                },
                growth: {
                    hp: 65,
                    mp: 25,
                    attack: 9.5,
                    defense: 5.5,
                    speed: 7.5,
                    crit: 2.5,
                    critDmg: 12,
                    hit: 5.0,
                    dodge: 3.5,
                    magic: 0,
                    drain: 0.5
                },
                skills: ['basic_attack', 'quick_strike', 'sand_throw'],
                drops: [
                    { id: 'desert_blade', chance: 0.5, name: '沙漠弯刀', type: 'weapon', value: 400 },
                    { id: 'bandit_map', chance: 0.3, name: '强盗地图', type: 'quest', value: 300 }
                ]
            },

            DESERT_MAGE: {
                name: '遗迹法师',
                icon: '🧙',
                description: '研究古代魔法的法师',
                baseExp: 250,
                baseGold: 45,
                baseStats: {
                    hp: 520,
                    mp: 400,
                    attack: 60,
                    defense: 50,
                    speed: 60,
                    crit: 25,
                    critDmg: 160,
                    hit: 110,
                    dodge: 35,
                    magic: 95,
                    drain: 20
                },
                growth: {
                    hp: 55,
                    mp: 45,
                    attack: 6.0,
                    defense: 5.0,
                    speed: 6.0,
                    crit: 1.5,
                    critDmg: 8,
                    hit: 5.5,
                    dodge: 2.5,
                    magic: 10.0,
                    drain: 1.5
                },
                skills: ['basic_attack', 'sand_storm', 'ancient_curse'],
                drops: [
                    { id: 'magic_scroll', chance: 0.6, name: '古代卷轴', type: 'material', value: 450 },
                    { id: 'desert_staff', chance: 0.4, name: '沙漠法杖', type: 'weapon', value: 500 }
                ]
            },

            // 地下迷宫怪物
            STONE_GOLEM: {
                name: '石像鬼',
                icon: '👹',
                description: '守护入口的魔物',
                baseExp: 300,
                baseGold: 50,
                baseStats: {
                    hp: 800,
                    mp: 200,
                    attack: 100,
                    defense: 90,
                    speed: 40,
                    crit: 15,
                    critDmg: 150,
                    hit: 85,
                    dodge: 20,
                    magic: 40,
                    drain: 0
                },
                growth: {
                    hp: 85,
                    mp: 25,
                    attack: 10.0,
                    defense: 9.5,
                    speed: 4.0,
                    crit: 1.0,
                    critDmg: 5,
                    hit: 3.5,
                    dodge: 1.5,
                    magic: 4.0,
                    drain: 0
                },
                skills: ['basic_attack', 'stone_smash', 'rock_armor'],
                drops: [
                    { id: 'golem_core', chance: 0.5, name: '魔像核心', type: 'material', value: 500 },
                    { id: 'ancient_stone', chance: 0.6, name: '远古石块', type: 'material', value: 450 },
                ]
            },

            MIMIC: {
                name: '宝箱怪',
                icon: '📦',
                description: '伪装成宝箱的危险魔物',
                baseExp: 320,
                baseGold: 55,
                baseStats: {
                    hp: 700,
                    mp: 250,
                    attack: 110,
                    defense: 70,
                    speed: 65,
                    crit: 40,
                    critDmg: 220,
                    hit: 95,
                    dodge: 35,
                    magic: 0,
                    drain: 25
                },
                growth: {
                    hp: 75,
                    mp: 30,
                    attack: 11.5,
                    defense: 7.0,
                    speed: 6.5,
                    crit: 3.0,
                    critDmg: 15,
                    hit: 4.5,
                    dodge: 2.5,
                    magic: 0,
                    drain: 2.0
                },
                skills: ['basic_attack', 'surprise_attack', 'devour'],
                drops: [
                    { id: 'treasure_fragment', chance: 0.7, name: '宝物碎片', type: 'material', value: 550 },
                    { id: 'mimic_tooth', chance: 0.4, name: '怪物獠牙', type: 'material', value: 480 },
                ]
            },

            DARK_PRIEST: {
                name: '黑暗祭司',
                icon: '👻',
                description: '执行黑暗仪式的亡灵',
                baseExp: 350,
                baseGold: 60,
                baseStats: {
                    hp: 600,
                    mp: 500,
                    attack: 70,
                    defense: 60,
                    speed: 55,
                    crit: 30,
                    critDmg: 180,
                    hit: 115,
                    dodge: 40,
                    magic: 120,
                    drain: 30
                },
                growth: {
                    hp: 65,
                    mp: 55,
                    attack: 7.0,
                    defense: 6.0,
                    speed: 5.5,
                    crit: 2.0,
                    critDmg: 10,
                    hit: 5.5,
                    dodge: 3.0,
                    magic: 12.5,
                    drain: 2.5
                },
                skills: ['basic_attack', 'dark_ritual', 'soul_drain', 'curse'],
                drops: [
                    { id: 'dark_crystal', chance: 0.6, name: '暗影水晶', type: 'material', value: 600 },
                    { id: 'ritual_staff', chance: 0.4, name: '祭祀法杖', type: 'weapon', value: 650 },
                ]
            },

            DUNGEON_LORD: {
                name: '迷宫之主',
                icon: '👑',
                description: '统治地下迷宫的最终boss',
                baseExp: 500,
                baseGold: 1000,
                baseStats: {
                    hp: 1200,
                    mp: 600,
                    attack: 150,
                    defense: 120,
                    speed: 80,
                    crit: 45,
                    critDmg: 250,
                    hit: 120,
                    dodge: 50,
                    magic: 150,
                    drain: 40
                },
                growth: {
                    hp: 100,
                    mp: 65,
                    attack: 15.0,
                    defense: 12.0,
                    speed: 8.0,
                    crit: 4.0,
                    critDmg: 20,
                    hit: 6.0,
                    dodge: 4.0,
                    magic: 15.0,
                    drain: 3.0
                },
                skills: ['basic_attack', 'dungeon_mastery', 'ancient_power', 'death_curse'],
                drops: [
                    { id: 'dungeon_crown', chance: 1.0, name: '迷宫王冠', type: 'equipment', value: 2000 },
                    { id: 'boss_core', chance: 0.8, name: 'Boss核心', type: 'material', value: 1500 },
                    { id: 'ancient_scroll', chance: 0.6, name: '远古卷轴', type: 'book', value: 1000 }
                ]
            },

            WATER_SPRITE: {
                name: '水灵',
                icon: '💧',
                description: '由水汽凝聚而成的精灵',
                baseExp: 220,
                baseGold: 40,
                baseStats: {
                    hp: 480,           // 较低生命值
                    mp: 350,           // 高魔法值
                    attack: 65,        // 中等物理攻击
                    defense: 45,       // 较低防御
                    speed: 80,         // 高速度
                    crit: 20,
                    critDmg: 160,
                    hit: 100,
                    dodge: 45,         // 高闪避
                    magic: 100,        // 高魔法攻击
                    drain: 25          // 较高吸血
                },
                growth: {
                    hp: 52,
                    mp: 40,            // 高魔法值成长
                    attack: 6.5,
                    defense: 4.5,
                    speed: 8.0,        // 高速度成长
                    crit: 1.5,
                    critDmg: 8,
                    hit: 5.0,
                    dodge: 4.0,        // 高闪避成长
                    magic: 10.0,       // 高魔法成长
                    drain: 2.0
                },
                skills: ['basic_attack', 'water_blast', 'healing_mist', 'water_shield', 'tidal_force'],
                drops: [
                    { id: 'water_essence', chance: 0.7, name: '水之精华', type: 'material', value: 280 },
                    { id: 'spirit_pearl', chance: 0.4, name: '灵珠', type: 'material', value: 300 },
                    { id: 'aqua_crystal', chance: 0.3, name: '水晶', type: 'material', value: 350 },
                ]
            }
        };

        // 技能配置
        this.MONSTER_SKILLS = {
            basic_attack: {
                name: '普通攻击',
                type: 'physical',
                damageMultiplier: 1.2,     // 提升基础攻击伤害
                mpCost: 0,
                cooldown: 0
            },
            counter_attack: {
                name: '反击',
                type: 'physical',
                damageMultiplier: 1.5,     // 提升反击伤害
                mpCost: 15,
                cooldown: 3,
                description: '受到攻击后进行反击'
            },
            iron_defense: {
                name: '铁壁',
                type: 'buff',
                effect: { defense: 1.5 },
                duration: 3,
                mpCost: 20,
                cooldown: 5
            },
            intimidate: {
                name: '威吓',
                type: 'debuff',
                effect: { attack: 0.8 },
                duration: 2,
                mpCost: 10,
                cooldown: 4
            },
            quick_strike: {
                name: '快速打击',
                type: 'physical',
                damageMultiplier: 1.0,     // 提升快速打击单次伤害
                hitCount: 2,               // 保持两次攻击
                mpCost: 15,
                cooldown: 3
            },
            martial_arts: {
                name: '武学招式',
                type: 'physical',
                damageMultiplier: 1.3,
                mpCost: 20,
                cooldown: 4
            },
            guard_stance: {
                name: '防御姿态',
                type: 'buff',
                effect: { defense: 2.0 },
                duration: 2,
                mpCost: 25,
                cooldown: 5
            },
            magic_missile: {
                name: '魔法飞弹',
                type: 'magical',
                damageMultiplier: 1.5,
                mpCost: 30,
                cooldown: 3
            },
            pack_tactics: {
                name: '狼群战术',
                type: 'buff',
                effect: { attack: 1.3, crit: 1.5 },
                duration: 3,
                mpCost: 25,
                cooldown: 5
            },
            poison_bite: {
                name: '毒牙',
                type: 'physical',
                damageMultiplier: 1.3,
                effect: { poison: 15 },
                duration: 3,
                mpCost: 20,
                cooldown: 4
            },
            constrict: {
                name: '缠绕',
                type: 'physical',
                damageMultiplier: 1.2,
                effect: { speed: 0.7 },
                duration: 2,
                mpCost: 15,
                cooldown: 4
            },
            water_blast: {
                name: '水流冲击',
                type: 'magical',
                damageMultiplier: 1.6,
                mpCost: 30,
                cooldown: 3
            },
            healing_mist: {
                name: '治愈之雾',
                type: 'heal',
                healAmount: 80,
                mpCost: 40,
                cooldown: 5
            },
            dive_attack: {
                name: '俯冲攻击',
                type: 'physical',
                damageMultiplier: 1.8,
                mpCost: 25,
                cooldown: 4
            },
            wind_slash: {
                name: '风刃',
                type: 'physical',
                damageMultiplier: 1.4,
                hitCount: 2,
                mpCost: 20,
                cooldown: 3
            },
            sonic_wave: {
                name: '音波',
                type: 'magical',
                damageMultiplier: 1.3,
                effect: { hit: 0.8 },
                duration: 2,
                mpCost: 15,
                cooldown: 4
            },
            blood_drain: {
                name: '吸血',
                type: 'physical',
                damageMultiplier: 1.2,
                drainMultiplier: 0.5,
                mpCost: 20,
                cooldown: 4
            },
            rock_throw: {
                name: '投石',
                type: 'physical',
                damageMultiplier: 1.5,
                mpCost: 15,
                cooldown: 3
            },
            stone_skin: {
                name: '石肤',
                type: 'buff',
                effect: { defense: 1.8 },
                duration: 3,
                mpCost: 30,
                cooldown: 5
            },
            mist_veil: {
                name: '迷雾帷幕',
                type: 'buff',
                effect: { dodge: 1.5, defense: 1.3 },
                duration: 3,
                mpCost: 35,
                cooldown: 5
            },
            cloud_burst: {
                name: '云爆',
                type: 'magical',
                damageMultiplier: 1.7,
                areaEffect: true,
                mpCost: 45,
                cooldown: 6
            },
            stone_smash: {
                name: '碎岩击',
                type: 'physical',
                damageMultiplier: 1.6,
                mpCost: 25,
                cooldown: 4,
                effect: {
                    type: 'stun',
                    chance: 0.3,
                    duration: 1
                }
            },
            petrify: {
                name: '石化',
                type: 'magical',
                mpCost: 40,
                cooldown: 8,
                effect: {
                    type: 'petrify',
                    duration: 2,
                    defenseReduction: 0.3
                }
            },
            sand_armor: {
                name: '沙甲',
                type: 'buff',
                effect: { defense: 1.5 },
                duration: 3,
                mpCost: 25,
                cooldown: 5
            },
            burrow: {
                name: '遁地',
                type: 'buff',
                effect: { dodge: 2.0 },
                duration: 2,
                mpCost: 30,
                cooldown: 6
            },
            sand_blast: {
                name: '沙暴喷射',
                type: 'physical',
                damageMultiplier: 1.8,
                mpCost: 35,
                cooldown: 4
            },
            sand_storm: {
                name: '沙尘暴',
                type: 'magical',
                damageMultiplier: 2.0,
                areaEffect: true,
                mpCost: 45,
                cooldown: 6
            },
            ancient_curse: {
                name: '远古诅咒',
                type: 'magical',
                damageMultiplier: 1.6,
                effect: {
                    type: 'curse',
                    duration: 3,
                    statReduction: 0.3
                },
                mpCost: 40,
                cooldown: 5
            },
            surprise_attack: {
                name: '突袭',
                type: 'physical',
                damageMultiplier: 2.5,
                critRateBonus: 50,
                mpCost: 30,
                cooldown: 4
            },
            dark_ritual: {
                name: '暗影仪式',
                type: 'magical',
                damageMultiplier: 2.0,
                effect: {
                    type: 'dot',
                    duration: 3,
                    damagePerTurn: 50
                },
                mpCost: 45,
                cooldown: 5
            },
            dungeon_mastery: {
                name: '迷宫掌控',
                type: 'buff',
                effect: {
                    attack: 1.5,
                    defense: 1.5,
                    speed: 1.5
                },
                duration: 3,
                mpCost: 60,
                cooldown: 8
            },
            savage_bite: {
                name: '野性撕咬',
                type: 'physical',
                damageMultiplier: 1.8,
                effect: {
                    type: 'bleed',
                    duration: 3,
                    damagePerTurn: 30
                },
                mpCost: 25,
                cooldown: 4
            },
            venom_spit: {
                name: '毒液喷射',
                type: 'magical',
                damageMultiplier: 1.6,
                effect: {
                    type: 'poison',
                    duration: 4,
                    damagePerTurn: 40
                },
                mpCost: 30,
                cooldown: 5
            },
            spirit_drain: {
                name: '精魂汲取',
                type: 'magical',
                damageMultiplier: 1.5,
                effect: {
                    type: 'mp_drain',
                    amount: 50
                },
                mpCost: 40,
                cooldown: 6
            },
            water_shield: {
                name: '水盾',
                type: 'buff',
                effect: {
                    defense: 1.4,
                    magic: 1.3
                },
                duration: 3,
                mpCost: 40,
                cooldown: 5
            },
            tidal_force: {
                name: '潮汐之力',
                type: 'magical',
                damageMultiplier: 2.0,
                effect: {
                    type: 'knockback',
                    chance: 0.5,   // 50%击退概率
                    distance: 2
                },
                mpCost: 50,
                cooldown: 7
            }
        };

        // 基础金币奖励配置
        this.BASE_GOLD_REWARD = {
            baseAmount: 5,     // 基础金币奖励
            levelMultiplier: 2 // 每级增加的金币奖励
        };

        // 掉落物效果配置
        this.DROP_EFFECTS = {
            // 武庙掉落物
            wood_piece: {
                name: '木块',
                description: '普通的木块，可以出售获得一些铜钱',
                type: 'material',
                value: 10
            },
            training_manual: {
                name: '练功秘籍',
                description: '记载着基础武学心得，阅读后可获得少量经验值',
                type: 'book',
                value: 50,
                effect: {
                    type: 'exp_gain',
                    value: 100
                }
            },
            iron_piece: {
                name: '铁块',
                description: '品质不错的铁块，可以出售获得银钱',
                type: 'material',
                value: 30
            },
            advanced_manual: {
                name: '高级练功秘籍',
                description: '记载着进阶武学心得，阅读后可获得可观经验值',
                type: 'book',
                value: 100,
                effect: {
                    type: 'exp_gain',
                    value: 250
                }
            },

            // 武街掉落物
            thug_knife: {
                name: '匕首',
                description: '锋利的匕首，增加使用者的攻击速度',
                type: 'weapon',
                value: 150,
                effect: {
                    type: 'equip',
                    stats: {
                        attack: 15,
                        speed: 10
                    }
                }
            },
            leather_armor: {
                name: '皮甲',
                description: '轻便的皮甲，提供基础防护',
                type: 'armor',
                value: 120,
                effect: {
                    type: 'equip',
                    stats: {
                        defense: 12,
                        dodge: 5
                    }
                }
            },
            healing_potion: {
                name: '治疗药水',
                description: '恢复100点生命值',
                type: 'consumable',
                value: 50,
                effect: {
                    type: 'heal',
                    value: 100
                }
            },

            // 武馆掉落物
            training_gear: {
                name: '练功服',
                description: '适合练功的服装，提升修炼效率',
                type: 'armor',
                value: 180,
                effect: {
                    type: 'equip',
                    stats: {
                        defense: 15,
                        exp_bonus: 10 // 获得经验值+10%
                    }
                }
            },
            basic_manual: {
                name: '基础武学秘籍',
                description: '记载着系统的武学基础，阅读后获得经验值',
                type: 'book',
                value: 150,
                effect: {
                    type: 'exp_gain',
                    value: 300
                }
            },
            energy_pill: {
                name: '气力丹',
                description: '恢复50点法力值',
                type: 'consumable',
                value: 80,
                effect: {
                    type: 'restore_mp',
                    value: 50
                }
            },

            // 商队护卫掉落物
            guard_armor: {
                name: '护卫铠甲',
                description: '结实的铠甲，提供优秀的防护能力',
                type: 'armor',
                value: 250,
                effect: {
                    type: 'equip',
                    stats: {
                        defense: 25,
                        hp: 100
                    }
                }
            },
            steel_sword: {
                name: '精钢剑',
                description: '用精钢打造的利剑，提供可观的攻击力',
                type: 'weapon',
                value: 300,
                effect: {
                    type: 'equip',
                    stats: {
                        attack: 30,
                        critRate: 5
                    }
                }
            },
            shield: {
                name: '盾牌',
                description: '坚固的盾牌，大幅提升防御力',
                type: 'shield',
                value: 200,
                effect: {
                    type: 'equip',
                    stats: {
                        defense: 20,
                        block_rate: 10 // 10%概率格挡伤害
                    }
                }
            },

            // 巫师掉落物
            magic_scroll: {
                name: '法术卷轴',
                description: '记载着法术要诀，阅读后获得经验值',
                type: 'consumable',
                value: 120,
                effect: {
                    type: 'exp_gain',
                    value: 200
                }
            },
            mage_staff: {
                name: '法杖',
                description: '增强法术威力的法杖',
                type: 'weapon',
                value: 280,
                effect: {
                    type: 'equip',
                    stats: {
                        magic: 25,
                        mp: 50
                    }
                }
            },
            mana_crystal: {
                name: '魔力水晶',
                description: '蕴含魔力的水晶，可以用来强化装备',
                type: 'material',
                value: 150,
                effect: {
                    type: 'enhance',
                    success_rate: 20 // 20%概强化成功
                }
            },
            mage_robe: {
                name: '法师长袍',
                description: '提升法术威力的长袍',
                type: 'armor',
                value: 200,
                effect: {
                    type: 'equip',
                    stats: {
                        magic: 15,
                        mp: 100,
                        mp_regen: 2
                    }
                }
            },

            // 山贼掉落物
            bandit_sword: {
                name: '山贼刀',
                description: '锋利的弯刀，增加暴击率',
                type: 'weapon',
                value: 220,
                effect: {
                    type: 'equip',
                    stats: {
                        attack: 25,
                        critRate: 8
                    }
                }
            },
            stolen_goods: {
                name: '赃物',
                description: '可以出售获得不少金钱',
                type: 'material',
                value: 180
            },
            treasure_map: {
                name: '藏宝图',
                description: '记载着宝藏位置的地图，或许能找到什么好东西',
                type: 'quest',
                value: 500,
                effect: {
                    type: 'quest_start',
                    quest_id: 'treasure_hunt'
                }
            },
            wolf_fang: {
                name: '狼牙',
                description: '锋利的狼牙，可用于制作武器',
                type: 'material',
                value: 200,
                effect: {
                    type: 'craft_material',
                    craftable: ['wolf_blade', 'beast_armor']
                }
            },
            wolf_pelt: {
                name: '狼皮',
                description: '结实的狼皮，可用于制作防具',
                type: 'material',
                value: 180,
                effect: {
                    type: 'craft_material',
                    craftable: ['wolf_cloak', 'beast_boots']
                }
            },
            snake_skin: {
                name: '蛇皮',
                description: '柔韧的蛇皮，可用于制作轻甲',
                type: 'material',
                value: 220,
                effect: {
                    type: 'craft_material',
                    craftable: ['snake_armor', 'swift_boots']
                }
            },
            venom_gland: {
                name: '毒腺',
                description: '蕴含剧毒的腺体，可用于制作毒药',
                type: 'material',
                value: 250,
                effect: {
                    type: 'craft_material',
                    craftable: ['venom_coating', 'poison_bomb']
                }
            },
            cloud_essence: {
                name: '云雾精华',
                description: '凝聚着迷雾能量的精华',
                type: 'material',
                value: 280,
                effect: {
                    type: 'craft_material',
                    craftable: ['mist_robe', 'cloud_staff']
                }
            },
            spirit_crystal: {
                name: '精灵水晶',
                description: '蕴含精灵力量的水晶',
                type: 'material',
                value: 300,
                effect: {
                    type: 'craft_material',
                    craftable: ['spirit_ring', 'fairy_wand']
                }
            },
            water_essence: {
                name: '水之精华',
                description: '蕴含纯净水元素力量的精华',
                type: 'material',
                value: 280,
                effect: {
                    type: 'craft_material',
                    craftable: ['water_staff', 'aqua_robe', 'spirit_ring']
                }
            },
            spirit_pearl: {
                name: '灵珠',
                description: '水灵凝聚的珍珠，散发着柔和的光芒',
                type: 'material',
                value: 300,
                effect: {
                    type: 'craft_material',
                    craftable: ['pearl_necklace', 'spirit_bracelet']
                }
            },
            aqua_crystal: {
                name: '水晶',
                description: '水元素结晶，可用于强化水系装备',
                type: 'material',
                value: 350,
                effect: {
                    type: 'enhance_material',
                    enhanceable: ['water_staff', 'aqua_robe', 'spirit_ring'],
                    bonus: {
                        magic: 10,
                        mp: 50
                    }
                }
            }
        };
    }

    // 生成怪物
    generateMonster(monsterData) {
        const { name, icon, level, description, mapId, nodeId } = monsterData;
        const monsterType = this.MONSTER_TYPES[monsterData.type];
        
        if (!monsterType) {
            console.error('未知的怪物类型:', monsterData.type);
            return null;
        }

        // 计算属性
        const stats = this.calculateMonsterStats(monsterType.baseStats, monsterType.growth, level);
        
        // 获取技能
        const skills = this.getMonsterSkills(monsterType.skills);

        // 计算基础金币奖励
        const goldReward = this.calculateGoldReward(level, monsterType.baseGold);

        // 生成掉落物(不包含金币)
        const drops = this.generateDrops(monsterType.drops);
        
        return {
            id: `monster_${Date.now()}`,
            name: monsterType.name,
            icon: monsterType.icon,
            level,
            description: monsterType.description,
            stats,
            skills,
            drops,
            baseExp: monsterType.baseExp,
            goldReward,    // 确保这里设置了goldReward
            type: 'enemy', // 明确设置type为enemy
            mapId,
            nodeId
        };
    }

    // 计算金币奖励
    calculateGoldReward(level, baseGold) {
        const levelBonus = Math.floor(level * 2); // 每级增加2金币
        
        // 添加随机波动 (±20%)
        const randomFactor = 0.8 + Math.random() * 0.4; // 0.8 到 1.2 之间
        return Math.max(1, Math.floor((baseGold + levelBonus) * randomFactor));
    }

    // 修改掉落生成方法(移除金币相关逻辑)
    generateDrops(dropTable) {
        return dropTable
            .filter(drop => drop.type !== 'currency' && Math.random() < drop.chance)
            .map(drop => ({
                ...drop,
                ...this.DROP_EFFECTS[drop.id], // 添加效果配置
                id: `${drop.id}_${Date.now()}`
            }));
    }

    // 计算怪物属性
    calculateMonsterStats(baseStats, growth, level) {
        const stats = {};
        const levelDiff = level - 1;

        // 计算每个属性
        for (const [stat, base] of Object.entries(baseStats)) {
            const growthRate = growth[stat] || 0;
            stats[stat] = Math.floor(base + (growthRate * levelDiff));
        }

        // 确保有最大值属性
        if (stats.hp) stats.maxHp = stats.hp;
        if (stats.mp) stats.maxMp = stats.mp;

        return stats;
    }

    // 获取怪物技能
    getMonsterSkills(skillIds) {
        return skillIds.map(id => {
            const skillTemplate = this.MONSTER_SKILLS[id];
            if (!skillTemplate) return null;

            return {
                ...skillTemplate,
                id,
                currentCooldown: 0
            };
        }).filter(skill => skill !== null);
    }
}

// 创建全局实例
const entityGenerator = new EntityGenerator();