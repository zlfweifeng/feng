class ItemGenerator {
    constructor() {
        // 装备品质配置
        this.QUALITY_CONFIG = {
            NORMAL: {
                name: '普通',
                color: '#A1A1A1',
                minStats: 1,
                maxStats: 2,
                statMultiplier: 1.0
            },
            RARE: {
                name: '稀有',
                color: '#4CAF50',
                minStats: 2,
                maxStats: 3,
                statMultiplier: 1.2
            },
            EPIC: {
                name: '史诗',
                color: '#2196F3',
                minStats: 3,
                maxStats: 4,
                statMultiplier: 1.5
            },
            LEGENDARY: {
                name: '传说',
                color: '#FFC107',
                minStats: 4,
                maxStats: 5,
                statMultiplier: 2.0
            },
            MYTHIC: {
                name: '神话',
                color: '#E91E63',
                minStats: 6,
                maxStats: 6,
                statMultiplier: 2.5
            }
        };

        // 装备类型配置
        this.EQUIPMENT_TYPES = {
            WEAPON: {
                name: '武器',
                icon: '⚔️',
                baseStats: ['attack', 'critRate', 'critDamage']
            },
            HEAD: {
                name: '头部',
                icon: '👒',
                baseStats: ['defense', 'hp', 'mpRegen']
            },
            BODY: {
                name: '衣服',
                icon: '👕',
                baseStats: ['defense', 'hp', 'dodge']
            },
            HANDS: {
                name: '手部',
                icon: '🧤',
                baseStats: ['attack', 'critRate', 'speed']
            },
            LEGS: {
                name: '裤子',
                icon: '👖',
                baseStats: ['defense', 'hp', 'speed']
            },
            FEET: {
                name: '鞋子',
                icon: '👞',
                baseStats: ['speed', 'dodge', 'defense']
            }
        };

        // 属性池配置
        this.STAT_POOL = {
            // 主属性 - 保持相对较高的数值
            attack: {
                name: '攻击',
                min: 8,
                max: 40,
                weight: 100,
                format: 'flat'
            },
            defense: {
                name: '防御',
                min: 6,
                max: 35,
                weight: 100,
                format: 'flat'
            },
            hp: {
                name: '生命',
                min: 40,
                max: 180,
                weight: 100,
                format: 'flat'
            },
            mp: {
                name: '法力',
                min: 25,
                max: 120,
                weight: 100,
                format: 'flat'
            },
            // 次要属性 - 降低百分比属性的数值
            critRate: {
                name: '暴击',
                min: 1,      // 从2降到1
                max: 8,      // 从15降到8
                weight: 70,  // 降低出现权重
                format: 'percentage'
            },
            critDamage: {
                name: '暴伤',
                min: 3,      // 从5降到3
                max: 20,     // 从30降到20
                weight: 70,
                format: 'percentage'
            },
            dodge: {
                name: '闪避',
                min: 1,      // 从2降到1
                max: 6,      // 从12降到6
                weight: 70,
                format: 'percentage'
            },
            speed: {
                name: '速度',
                min: 2,      // 从3降到2
                max: 8,      // 从15降到8
                weight: 70,
                format: 'flat'
            },
            // 特殊属性 - 进一步降低数值和出现概率
            lifeSteal: {
                name: '偷取',
                min: 0.5,    // 从1降到0.5
                max: 4,      // 从8降到4
                weight: 50,  // 进一步降低权重
                format: 'percentage'
            },
            mpRegen: {
                name: '恢复',
                min: 1,      // 从2降到1
                max: 6,      // 从10降到6
                weight: 50,
                format: 'flat'
            },
            skillDamage: {
                name: '技伤',
                min: 2,      // 从3降到2
                max: 12,     // 从20降到12
                weight: 50,
                format: 'percentage'
            },
            cooldownReduction: {
                name: '冷却',
                min: 1,      // 从2降到1
                max: 6,      // 从12降到6
                weight: 50,
                format: 'percentage'
            }
        };

        // 消耗品配置
        this.CONSUMABLE_CONFIG = {
            // 保留 BUFF药水
            STRENGTH_POTION: {
                name: '力量药水',
                icon: '🧪',
                description: '增加30%攻击力，持续300秒',
                type: 'buff',
                effect: {
                    type: 'buff_attack',
                    value: 30,
                    duration: 300
                },
                price: 200
            },
            DEFENSE_POTION: {
                name: '防御药水',
                icon: '🧪',
                description: '增加30%防御力，持续300秒',
                type: 'buff',
                effect: {
                    type: 'buff_defense',
                    value: 30,
                    duration: 300
                },
                price: 200
            },
            SPEED_POTION: {
                name: '敏捷药水',
                icon: '🧪',
                description: '增加20%速度，持续300秒',
                type: 'buff',
                effect: {
                    type: 'buff_speed',
                    value: 20,
                    duration: 300
                },
                price: 200
            },
            // 特殊道具
            RESURRECTION_SCROLL: {
                name: '复活卷轴',
                icon: '📜',
                description: '可以复活一名倒下的队友',
                type: 'special',
                effect: {
                    type: 'resurrection',
                    value: 30 // 复活后恢复30%血量
                },
                price: 1000
            },
            ENHANCEMENT_STONE: {
                name: '强化石',
                icon: '💎',
                description: '可以提升装备强化等级',
                type: 'special',
                effect: {
                    type: 'enhance',
                    successRate: 70 // 70%成功率
                },
                price: 500
            },
            REFORGE_SCROLL: {
                name: '洗练符',
                icon: '📜',
                description: '重新随机装备的属性',
                type: 'special',
                effect: {
                    type: 'reforge'
                },
                price: 300
            }
        };

        // 装备名称配置
        this.EQUIPMENT_NAME_CONFIG = {
            WEAPON: {
                prefix: ['破损的', '锈蚀的', '精制的', '锋利的', '远古的', '传说中的', '被诅咒的', '神圣的'],
                name: [
                    // 剑类
                    '青铜剑', '铁剑', '精钢剑', '玄铁剑', '龙骨剑', '霜寒剑', '陨铁剑', '血饮剑', '屠龙剑', '诸神黄昏',
                    // 刀类
                    '青铜刀', '铁刀', '大马士革刀', '龙纹刀', '鬼切', '斩月刀', '屠魔刀', '修罗刀',
                    // 斧类
                    '青铜斧', '铁斧', '战斧', '狂战斧', '符文斧', '毁灭之斧', '雷神之斧',
                    // 枪类
                    '青铜枪', '铁枪', '精钢枪', '龙纹枪', '破天枪', '方天画戟', '冥河之矛',
                    // 法杖类
                    '橡木法杖', '紫晶法杖', '寒冰法杖', '火焰权杖', '末日法杖', '混沌权杖', '永恒法杖'
                ]
            },
            HEAD: {
                prefix: ['破旧的', '陈旧的', '精良的', '华贵的', '神秘的', '传说的', '远古的'],
                name: [
                    // 头盔类
                    '铁盔', '精钢盔', '龙鳞盔', '符文头盔', '战神头盔', '永恒头盔',
                    // 帽子类
                    '布帽', '皮帽', '法师帽', '智者之冠', '贤者之冠', '永恒之冠',
                    // 头饰类
                    '银冠', '黄金冠', '王者之冠', '霸者头饰', '天使之冠'
                ]
            },
            BODY: {
                prefix: ['破损的', '陈旧的', '精良的', '华贵的', '神圣的', '传说的', '远古的'],
                name: [
                    // 重甲
                    '铁甲', '精钢甲', '玄铁甲', '黑曜甲', '龙鳞甲', '符文战甲', '永恒战甲',
                    // 轻甲
                    '布甲', '皮甲', '鹿皮甲', '轻羽甲', '影子战衣', '月光战衣',
                    // 法袍
                    '学徒法袍', '巫师法袍', '大法师袍', '贤者法袍', '星辰法袍', '永恒法袍'
                ]
            },
            HANDS: {
                prefix: ['破损的', '陈旧的', '精良的', '华贵的', '神秘的', '传说的'],
                name: [
                    // 手套类
                    '铁手套', '精钢护手', '龙鳞手套', '符文手套', '战神护手',
                    // 护腕类
                    '皮护腕', '铁护腕', '精钢护腕', '龙骨护腕', '符文护腕',
                    // 臂铠类
                    '铁臂铠', '精钢臂铠', '龙鳞臂铠', '符文臂铠', '永恒臂铠'
                ]
            },
            LEGS: {
                prefix: ['破损的', '陈旧的', '精良的', '华贵的', '神圣的', '传说的'],
                name: [
                    // 重型护腿
                    '铁护腿', '精钢护腿', '龙鳞护腿', '符文护腿', '永恒护腿',
                    // 轻型护腿
                    '布裤', '皮裤', '鹿皮护腿', '影纱护腿', '月影护腿',
                    // 法师护腿
                    '学徒长裤', '巫师护腿', '大法师护腿', '星辰护腿'
                ]
            },
            FEET: {
                prefix: ['破损的', '陈旧的', '精良的', '华贵的', '神秘的', '传说的'],
                name: [
                    // 重型靴子
                    '铁靴', '精钢战靴', '龙鳞战靴', '符文战靴', '永恒战靴',
                    // 轻型靴子
                    '布鞋', '皮靴', '鹿皮靴', '影袭之靴', '风行者之靴',
                    // 法师靴子
                    '学徒便鞋', '巫师之靴', '大法师之靴', '星辰之靴'
                ]
            }
        };
    }

    // 生成随机品质
    generateQuality(levelReq = 1) {
        const rand = Math.random() * 100;
        if (levelReq >= 50 && rand < 1) return 'MYTHIC';      // 1%
        if (levelReq >= 40 && rand < 5) return 'LEGENDARY';   // 4%
        if (levelReq >= 30 && rand < 15) return 'EPIC';       // 10%
        if (levelReq >= 20 && rand < 35) return 'RARE';       // 20%
        return 'NORMAL';                                      // 65%
    }

    // 根据等级计算属性值
    calculateStatValue(stat, level, quality) {
        const baseMin = this.STAT_POOL[stat].min;
        const baseMax = this.STAT_POOL[stat].max;
        const multiplier = this.QUALITY_CONFIG[quality].statMultiplier;
        const levelFactor = 1 + (level - 1) * 0.1;

        const min = Math.floor(baseMin * multiplier * levelFactor);
        const max = Math.floor(baseMax * multiplier * levelFactor);
        
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // 从属性池中选择随机属性
    selectRandomStat(excludeStats = []) {
        const availableStats = Object.entries(this.STAT_POOL)
            .filter(([key]) => !excludeStats.includes(key))
            .map(([key, value]) => ({
                key,
                weight: value.weight
            }));

        const totalWeight = availableStats.reduce((sum, stat) => sum + stat.weight, 0);
        let random = Math.random() * totalWeight;

        for (const stat of availableStats) {
            random -= stat.weight;
            if (random <= 0) return stat.key;
        }

        return availableStats[0].key;
    }

    // 生成装备
    generateEquipment(type, level = 1) {
        const equipType = this.EQUIPMENT_TYPES[type];
        const quality = this.generateQuality(level);
        const qualityConfig = this.QUALITY_CONFIG[quality];

        // 生成随机名称
        const nameConfig = this.EQUIPMENT_NAME_CONFIG[type];
        const prefix = nameConfig.prefix[Math.floor(Math.random() * nameConfig.prefix.length)];
        const baseName = nameConfig.name[Math.floor(Math.random() * nameConfig.name.length)];

        // 确定属性数量
        const numStats = Math.floor(Math.random() * 
            (qualityConfig.maxStats - qualityConfig.minStats + 1)) + 
            qualityConfig.minStats;

        // 生成基础属性
        const stats = {};
        equipType.baseStats.forEach(stat => {
            stats[stat] = this.calculateStatValue(stat, level, quality);
        });

        // 生成随机附加属性
        const usedStats = Object.keys(stats);
        for (let i = equipType.baseStats.length; i < numStats; i++) {
            const stat = this.selectRandomStat(usedStats);
            stats[stat] = this.calculateStatValue(stat, level, quality);
            usedStats.push(stat);
        }

        return {
            id: `equip_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: `${prefix}${baseName}`,
            type: type,
            icon: equipType.icon,
            level: level,
            quality: quality,
            stats: stats,
            description: this.generateEquipmentDescription(stats),
            price: this.calculatePrice(level, quality, numStats)
        };
    }

    // 生成装备描述
    generateEquipmentDescription(stats) {
        return Object.entries(stats).map(([key, value]) => {
            const statConfig = this.STAT_POOL[key];
            return `${statConfig.name}: +${value}${statConfig.format === 'percentage' ? '%' : ''}`;
        }).join('\n');
    }

    // 计算装备价格
    calculatePrice(level, quality, numStats) {
        const basePrice = 100;
        const qualityMultiplier = {
            NORMAL: 1,
            RARE: 2,
            EPIC: 5,
            LEGENDARY: 10,
            MYTHIC: 20
        }[quality];

        return Math.floor(basePrice * level * qualityMultiplier * (1 + (numStats - 1) * 0.5));
    }

    // 生成消耗品
    generateConsumable(itemKey) {
        const config = this.CONSUMABLE_CONFIG[itemKey];
        if (!config) return null;

        return {
            id: `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            ...config,
            stackable: true,
            maxStack: 99
        };
    }

    // 生成随机掉落
    generateRandomDrop(level) {
        const rand = Math.random() * 100;
        
        if (rand < 70) {  // 50% 概率掉落消耗品
            const consumableTypes = Object.entries(this.CONSUMABLE_CONFIG)
                .filter(([_, item]) => item.type === 'buff' || item.type === 'special')
                .map(([key]) => key);
            const randomType = consumableTypes[Math.floor(Math.random() * consumableTypes.length)];
            return this.generateConsumable(randomType);
        } else {  // 50% 概率掉落装备
            const equipTypes = Object.keys(this.EQUIPMENT_TYPES);
            const randomType = equipTypes[Math.floor(Math.random() * equipTypes.length)];
            return this.generateEquipment(randomType, level);
        }
    }

    // 生成战斗掉落物品
    generateCombatLoot(enemies, playerLevel) {
        let loot = [];
        
        enemies.forEach(enemy => {
            // 1. 基于怪物配置生成掉落
            if (enemy.drops) {
                enemy.drops.forEach(dropConfig => {
                    if (Math.random() < dropConfig.chance) {
                        const item = this.generateDropItem(dropConfig, enemy.level);
                        if (item) {
                            loot.push(item);
                        }
                    }
                });
            }

            // 2. 随机装备掉落
            if (Math.random() < this.calculateEquipmentDropRate(enemy.level, playerLevel)) {
                const equipment = this.generateRandomEquipment(enemy.level);
                if (equipment) {
                    loot.push(equipment);
                }
            }

            // 3. 材料掉落
            const materials = this.generateMaterialDrops(enemy);
            loot = loot.concat(materials);
        });

        return loot;
    }

    // 生成掉落物品
    generateDropItem(dropConfig, enemyLevel) {
        // 如果是装备类型，转换为大写
        if (dropConfig.type.toUpperCase() in this.EQUIPMENT_TYPES) {
            return this.generateEquipmentDrop({
                ...dropConfig,
                type: dropConfig.type.toUpperCase()
            }, enemyLevel);
        }

        switch(dropConfig.type) {
            case 'material':
                return this.generateMaterialDrop(dropConfig);
            case 'consumable':
                return this.generateConsumableDrop(dropConfig);
            case 'book':
                return this.generateBookDrop(dropConfig, enemyLevel);
            default:
                console.warn('未知的掉落类型:', dropConfig.type);
                return null;
        }
    }

    // 生成装备掉落
    generateEquipmentDrop(dropConfig, enemyLevel) {
        // 确保 dropConfig.type 是大写的装备类型
        const equipType = dropConfig.type.toUpperCase();
        
        // 计算品质
        const quality = this.calculateDropQuality(enemyLevel);
        const qualityConfig = this.QUALITY_CONFIG[quality];

        // 获取装备类型配置
        const typeConfig = this.EQUIPMENT_TYPES[equipType];
        if (!typeConfig) {
            console.warn('未知的装备类型:', equipType);
            return null;
        }

        // 生成随机名称
        const nameConfig = this.EQUIPMENT_NAME_CONFIG[equipType];
        if (!nameConfig) {
            console.warn('找不到装备名称配置:', equipType);
            return null;
        }

        const prefix = nameConfig.prefix[Math.floor(Math.random() * nameConfig.prefix.length)];
        const baseName = nameConfig.name[Math.floor(Math.random() * nameConfig.name.length)];

        // 确定属性数量
        const numStats = Math.floor(Math.random() * 
            (qualityConfig.maxStats - qualityConfig.minStats + 1)) + 
            qualityConfig.minStats;

        // 生成基础属性
        const stats = {};
        typeConfig.baseStats.forEach(stat => {
            stats[stat] = this.calculateStatValue(stat, enemyLevel, quality);
        });

        // 生成随机附加属性
        const usedStats = Object.keys(stats);
        for (let i = equipType.baseStats?.length || 0; i < numStats; i++) {
            const stat = this.selectRandomStat(usedStats);
            if (stat) {
                stats[stat] = this.calculateStatValue(stat, enemyLevel, quality);
                usedStats.push(stat);
            }
        }

        // 生成装备
        return {
            id: `equip_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: `${prefix}${baseName}`,
            type: equipType,
            icon: typeConfig.icon || '⚔️',
            level: enemyLevel,
            quality: quality,
            stats: stats,
            description: this.generateEquipmentDescription(stats),
            price: this.calculatePrice(enemyLevel, quality, numStats)
        };
    }

    // 计算装备掉落概率
    calculateEquipmentDropRate(enemyLevel, playerLevel) {
        const levelDiff = enemyLevel - playerLevel;
        let baseRate = 0.1; // 基础10%概率
        
        // 根据等级差异调整概率
        if (levelDiff > 0) {
            baseRate += levelDiff * 0.02; // 每级差异增加2%
        }
        
        // 根据怪物等级额外加成
        const levelBonus = Math.min(0.1, Math.floor(enemyLevel / 20) * 0.02); // 每20级增加2%,最多10%
        baseRate += levelBonus;
        
        // 限制最终概率范围
        return Math.min(0.3, Math.max(0.05, baseRate));
    }

    // 生成随机装备
    generateRandomEquipment(enemyLevel) {
        const types = Object.keys(this.EQUIPMENT_TYPES);
        const randomType = types[Math.floor(Math.random() * types.length)];
        
        return this.generateEquipment(randomType, Math.max(1, enemyLevel - 2));
    }

    // 生成材料掉落
    generateMaterialDrops(enemy) {
        const materials = [];
        const materialConfigs = entityGenerator.DROP_EFFECTS;
        
        // 根据怪物类型和等级生成对应材料
        if (enemy.type in materialConfigs) {
            const config = materialConfigs[enemy.type];
            if (Math.random() < config.chance) {
                materials.push({
                    id: `material_${Date.now()}`,
                    name: config.name,
                    type: 'material',
                    icon: config.icon || '📦',
                    description: config.description,
                    value: Math.floor(config.value * (1 + enemy.level * 0.1)),
                    count: Math.floor(Math.random() * 3) + 1 // 1-3个
                });
            }
        }

        return materials;
    }

    // 生成材料掉落
    generateMaterialDrop(dropConfig) {
        const count = dropConfig.count ? 
            (Array.isArray(dropConfig.count) ? 
                Math.floor(Math.random() * (dropConfig.count[1] - dropConfig.count[0] + 1)) + dropConfig.count[0] 
                : dropConfig.count)
            : 1;

        return {
            id: `${dropConfig.id}_${Date.now()}`,
            name: dropConfig.name,
            type: 'material',
            icon: dropConfig.icon || '📦',
            description: dropConfig.description || `${dropConfig.name}，可用于制作装备`,
            count: count,
            value: dropConfig.value || 10,
            stackable: true,
            maxStack: 99
        };
    }

    // 生成消耗品掉落
    generateConsumableDrop(dropConfig) {
        const consumableConfig = this.CONSUMABLE_CONFIG[dropConfig.id];
        if (!consumableConfig) return null;

        return {
            id: `${dropConfig.id}_${Date.now()}`,
            name: consumableConfig.name,
            type: 'consumable',
            icon: consumableConfig.icon,
            description: consumableConfig.description,
            effect: consumableConfig.effect,
            value: consumableConfig.price,
            stackable: true,
            maxStack: 99
        };
    }

    // 计算掉落品质
    calculateDropQuality(enemyLevel) {
        const rand = Math.random() * 100;
        
        // 根据怪物等级调整品质概率
        const levelBonus = Math.min(20, Math.floor(enemyLevel / 10) * 2); // 每10级增加2%概率,最多20%
        
        // 基础概率 + 等级加成
        if (enemyLevel >= 50 && rand < (1 + levelBonus * 0.1)) {
            return 'MYTHIC';      // 1% + 等级加成
        }
        if (enemyLevel >= 40 && rand < (5 + levelBonus * 0.2)) {
            return 'LEGENDARY';   // 4% + 等级加成
        }
        if (enemyLevel >= 30 && rand < (15 + levelBonus * 0.3)) {
            return 'EPIC';       // 10% + 等级加成
        }
        if (enemyLevel >= 20 && rand < (35 + levelBonus * 0.4)) {
            return 'RARE';       // 20% + 等级加成
        }
        return 'NORMAL';         // 剩余概率
    }

    // 生成基础属性
    generateBaseStats(type, level) {
        const equipType = this.EQUIPMENT_TYPES[type];
        if (!equipType) return {};

        const stats = {};
        equipType.baseStats.forEach(stat => {
            const statConfig = this.STAT_POOL[stat];
            if (!statConfig) return;

            const baseValue = Math.floor(
                (statConfig.min + Math.random() * (statConfig.max - statConfig.min)) * 
                (1 + (level - 1) * 0.1)
            );
            stats[stat] = baseValue;
        });

        return stats;
    }

    // 应用品质加成
    applyQualityBonus(stats, quality) {
        const qualityConfig = this.QUALITY_CONFIG[quality];
        const multiplier = qualityConfig.statMultiplier;

        const finalStats = {};
        for (const [stat, value] of Object.entries(stats)) {
            finalStats[stat] = Math.floor(value * multiplier);
        }

        return finalStats;
    }

    // 添加生成书籍掉落的方法
    generateBookDrop(dropConfig, enemyLevel) {
        return {
            id: `${dropConfig.id}_${Date.now()}`,
            name: dropConfig.name || '神秘书籍',
            type: 'book',
            icon: dropConfig.icon || '📚',
            description: dropConfig.description || '一本神秘的书籍，似乎蕴含着某种力量',
            value: dropConfig.value || Math.floor(50 * (1 + enemyLevel * 0.1)), // 基础价值50，随等级提升
            level: enemyLevel,
            effect: dropConfig.effect || {
                type: 'skill_book',
                skillId: dropConfig.skillId
            },
            stackable: false, // 书籍通常不可堆叠
            quality: dropConfig.quality || this.calculateDropQuality(enemyLevel) // 使用掉落品质计算
        };
    }
}

// 创建全局物品生成器实例
const itemGenerator = new ItemGenerator();